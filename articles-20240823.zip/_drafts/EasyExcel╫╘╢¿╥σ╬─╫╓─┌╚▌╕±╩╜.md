---
title: EasyExcel自定义文字内容格式
tags: []
category_bar: true
archive: false
abbrlink: 73
description:
banner_img:
index_img:
category:
password:
---

# 一、自定义日期格式

我们在前面使用链式调用时导出了一张Excel表，最后一列的生日格式是这样的：

![](https://source.icode504.com/images/image-20240318164534312.png)

我想大家清晰记得自己的出生日期，但是不一定能准确记得自己是几时几分出生的吧。所以，我们能否使用EasyExcel对这一列的内容重新改造，让导出的日期格式是这样的：yyyy年MM月dd日。例如：1996年05月28日。

如果不使用EasyExcel的方式，我相信大部分人会想到使用SimpleDateFormat类或者是Java8的DateTimeFormat类，这里我以SimpleDateFormat类为例，我们需要对原有的实体类作一点点改动：

-   在实体类Employee中再定义一个String类型属性birthdayFormat，在这个属性上标记`@ExcelProperty`注解。
-   实体类Employee原有属性birthday不再输出到Excel表中，因此需要在该属性上添加一个`@ExcelIgnore`注解。
-   在工具类EmployeeUtils的`getDataList`方法中使用SimpleDateFormat类并指定上述案例的格式，并调用format方法将日期转换成规定格式的字符串。
-   通过链式调用方式将数据列表输出到Excel文件中。

以下是上述思路的代码实现：

改动后的Employee类：

```java
package com.icode504.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import lombok.*;

import java.util.Date;

/**
 * 员工--实体类
 *
 * @author iCode504
 * @date 2024-03-18
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {

    // 序号
    @ExcelProperty("序号")
    private Integer id;

    // 员工号
    @ExcelProperty("员工号")
    private String employeeId;

    // 员工姓名
    @ExcelProperty("员工姓名")
    private String employeeName;

    // 年龄
    @ExcelProperty("年龄")
    private Integer age;

    // 性别（男/女）
    @ExcelProperty("性别")
    private String gender;

    // 生日
    @ExcelIgnore
    @ExcelProperty("生日")
    private Date birthday;

    // 生日（格式化输出）
    @ExcelProperty("生日")
    private String birthdayFormat;

    // 构造器、getter、setter已省略...
}
```

改动后的`EmployeeUtils.getDataList`方法：

```java
/**
 * 获取员工列表数据
 */
public static List<Employee> getDataList() {
    // 按照案例要求，使用SimpleDateFormat指定时间格式：yyyy年MM月dd日
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy年MM月dd日");
    List<Employee> employeeList = new ArrayList<>();
    Random random = new Random();
    Calendar calendar = Calendar.getInstance();
    for (int i = 0; i < employeeArray.length; i++) {
        Employee employee = new Employee();
        employee.setId(i + 1);
        employee.setEmployeeId(UUID.randomUUID().toString());
        employee.setEmployeeName(employeeArray[i]);
        // 随机生成1995~2002年的生日
        calendar.set(random.nextInt(8) + 1995,
                random.nextInt(12) + 1,
                random.nextInt(28) + 1);
        // employee.setBirthday(calendar.getTime());
        // 给employee对象的birthdayFormat属性赋值（新日期格式）
        employee.setBirthdayFormat(dateFormat.format(calendar.getTime()));
        // 根据上述生日计算年龄
        employee.setAge(Calendar.getInstance().get(Calendar.YEAR) - calendar.get(Calendar.YEAR));
        // 随机生成性别
        employee.setGender(random.nextInt(2) == 1 ? "男" : "女");
        employeeList.add(employee);
    }
    return employeeList;
}
```

EasyExcel链式调用将数据输出到Excel表格中：

```java
@Test
public void testDateTimeFormat() {
    String filePath = EmployeeUtils.getFilePath();
    EasyExcel.write(filePath, Employee.class).sheet(0, "测试工具表").doWrite(EmployeeUtils.getDataList());
    System.out.println("数据已写入到Excel文件中");
}
```

运行这段代码，生成的Excel文件内容确实符合案例中的要求，但是我们需要改动的代码确实有点过多了，这并不是一个很好的方案。

![](https://source.icode504.com/images/image-20240606133540510.png)

如果换成EasyExcel处理，那么我们几乎不需要修改任何代码。只需要在birthday字段上添加一个`@DateTimeFormat`注解，我们只需要配置这个注解的value属性值即可，指定我们想要的日期输出格式：yyyy年MM月dd日。实体类Employee改动后的代码如下：

```java
package com.icode504.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.*;

import java.util.Date;

/**
 * 员工--实体类
 *
 * @author iCode504
 * @date 2024-03-18
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {

    // 序号
    @ExcelProperty("序号")
    private Integer id;

    // 员工号
    @ExcelProperty("员工号")
    private String employeeId;

    // 员工姓名
    @ExcelProperty("员工姓名")
    private String employeeName;

    // 年龄
    @ExcelProperty("年龄")
    private Integer age;

    // 性别（男/女）
    @ExcelProperty("性别")
    private String gender;

    // 生日
    @ExcelProperty("生日")
    // 在生日字段上添加@DateTimeFormat注解，在这个注解下配置指定的日期格式：yyyy年MM月dd日
    @DateTimeFormat(value = "yyyy年MM月dd日")
    private Date birthday;

    // 构造器、getter、setter已省略...
}
```

再次运行前面的测试代码，我们发现输出的Excel表格内容中“生日”列的日期格式和前一种方式完全相同：

![](https://source.icode504.com/images/image-20240606133647570.png)

# 二、自定义数字格式

>   案例：假设你们公司的人事小姐姐统计5月份研发部人员的出勤率（保留两位小数，这里不需要考虑四舍五入的情况），她想导出的Excel表格如下：
>
>   实体类Employee：
>
>   ```java
>   
>   ```
>
>   工具类EmployeeUtils（出勤率随机生成，生成范围在80%~100%）：
>
>   ```java
>   
>   ```

如果我们使用EasyExcel调用，输出内容虽然有出勤率，但是小数点后面的数字较多，不太符合要求：

```java
@Test
public void testNumberFormat() {
    String filePath = EmployeeUtils.getFilePath();
    EasyExcel.write(filePath, Employee.class).sheet(0, "五月份研发部出勤表").doWrite(EmployeeUtils.getAttendanceList());
    System.out.println("数据已写入到Excel文件中");
}
```

此时输出的Excel文件虽然有小数点，但是并不符合我们的要求（因为我们需要保留两位小数）：

![](https://source.icode504.com/images/image-20240624222730425.png)

在没讲解EasyExcel新注解之前，我们先使用原生的方式让这个出勤率既可以保留两位小数并且后面可以保留百分号。以下是我的实现思路：

-   在Employee实体类上再添加一个String类型的属性`attendtionRateValue`，这个属性的作用就是将源出勤率字段作进一步处理的。要想让这个属性中对应的值写入Excel文件中，我们需要将`@ExcelProperty`注解标记在这个属性上。在原来的属性`attendtionRate`上再标记一个`@ExcelIgnore`注解，不需要将这个属性对应的值写入到Excel文件中。
-   在EmployeeUtils的`getAttendanceList`方法中定义DecimalFormat对象，指定的参数就是我们想要的格式。按照案例的要求，我们指定的参数格式是`#.##%`。
-   在上述方法中重新循环这个列表，将原来的`attendtionRate`对应的值转换成上述格式并赋值给新属性`attendtionRateValue`。
-   在测试方法中使用链式调用，将数据写入到Excel文件。

以下是实现代码：

```java
package com.icode504.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.*;

import java.util.Date;

/**
 * 员工--实体类
 *
 * @author iCode504
 * @date 2024-03-18
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {

    // 序号
    @ExcelProperty("序号")
    private Integer id;

    // 员工号
    @ExcelProperty("员工号")
    private String employeeId;

    // 员工姓名
    @ExcelProperty("员工姓名")
    private String employeeName;

    // 年龄
    @ExcelProperty("年龄")
    private Integer age;

    // 性别（男/女）
    @ExcelProperty("性别")
    private String gender;

    // 生日
    @ExcelProperty("生日")
    // 在生日字段上添加@DateTimeFormat注解，在这个注解下配置指定的日期格式：yyyy年MM月dd日
    @DateTimeFormat(value = "yyyy年MM月dd日")
    private Date birthday;

    // 让该属性对应的值不写入到Excel文件中
    @ExcelIgnore
    @ExcelProperty("出勤率")
    private Double attendanceRate;

    // 处理后的出勤率，写入到Excel文件中
    @ExcelProperty("出勤率")
    private String attendanceRateValue;
    // 构造器、getter、setter已省略...
}
```

```java
/**
 * 改造后的列表方法
 *
 * @return 列表
 */
public static List<Employee> getAttendanceList() {
    List<Employee> dataList = getDataList();
    // 创建一个DecimalFormat对象，参数设置成我们想要的格式：#.##%
    DecimalFormat format = new DecimalFormat("#.##%");
    Random random = new Random();
    for (Employee employee : dataList) {
        double attendanceRate = random.nextDouble();
        String attendanceRateValue = format.format(attendanceRate);
        employee.setAttendanceRateValue(attendanceRateValue);
    }
    return dataList;
}
```

再次运行上述的测试方法，我们发现此时Excel表格中的出勤率这一列中的内容符合我们的预期：

![](https://source.icode504.com/images/image-20240624224557818.png)

虽然这样确实已经符合了我们的要求，但是我们修改了实体类和对应的列表方法，总归不是一个好办法。

这里我也就不卖关子了，嘿嘿。

EasyExcel提供了一个注解`@NumbericFormat`，这个注解专门标记在实体类的属性上，你可以在这个属性中指定你想要的参数。按照上述要求，我们只需要在`attendenceRate`属性上添加`@NumbericFormat`注解并配置格式即可，其他什么都不需要改变。

以下是示例代码：

```java
package com.icode504.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.format.NumberFormat;
import lombok.*;

import java.util.Date;

/**
 * 员工--实体类
 *
 * @author iCode504
 * @date 2024-03-18
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {

    // 序号
    @ExcelProperty("序号")
    private Integer id;

    // 员工号
    @ExcelProperty("员工号")
    private String employeeId;

    // 员工姓名
    @ExcelProperty("员工姓名")
    private String employeeName;

    // 年龄
    @ExcelProperty("年龄")
    private Integer age;

    // 性别（男/女）
    @ExcelProperty("性别")
    private String gender;

    // 生日
    @ExcelProperty("生日")
    // 在生日字段上添加@DateTimeFormat注解，在这个注解下配置指定的日期格式：yyyy年MM月dd日
    @DateTimeFormat(value = "yyyy年MM月dd日")
    private Date birthday;

    // 出勤率指定为#.##%，就不需要再另外添加属性和对列表方法进行改动了
    @NumberFormat("#.##%")
    @ExcelProperty("出勤率")
    private Double attendanceRate;

    // 构造器、getter、setter已省略...
}
```

在测试方法中运行测试得到的Excel文件实现效果和前面的方式一模一样的：

![](https://source.icode504.com/images/image-20240624225314636.png)

# 三、自定义其他格式

>   你们公司的人事小姐姐看了表格表示很满意，但是她想让年龄这里一列中每一个数值后面加上“岁”，例如：26岁、28岁等等。处理效果如下图所示：
>
>   
>
>   如何使用EasyExcel来处理呢？

在不使用EasyExcel的情况下，我的实现思路是这样的：

1.   我们需要在实体类中再添加一个String类型属性`ageContent`，用于存储特定格式的年龄（）
2.   对`EmployeeUtils.getDataList()`方法中对属性`ageContent`进行赋值，格式为：xx岁。
3.   使用EasyExcel相关方法，将符合条件的数据输出到Excel文件中。

以下是上述思路的代码实现：

实体类Employee添加了`ageContent`属性和getter/setter方法：

```java
package com.icode504.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.format.NumberFormat;
import com.icode504.converter.MyCustomStringConverter;
import lombok.*;

import java.util.Date;

/**
 * 员工--实体类
 *
 * @author iCode504
 * @date 2024-03-18
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {

    // 序号
    @ExcelProperty(value = "序号", converter = MyCustomStringConverter.class)
    private Integer id;

    // 员工号
    @ExcelProperty("员工号")
    private String employeeId;

    // 员工姓名
    @ExcelProperty("员工姓名")
    private String employeeName;

    // 年龄
    // 将原来的age属性上标注@ExcelIngore注解，避免EasyExcel输出这一列的内容
    @ExcelProperty("年龄")
    @ExcelIgnore
    private Integer age;

    // 在实体类中再添加一个ageContent，用于存储特定的年龄格式
    @ExcelProperty("年龄")
    private String ageContent;

    // 性别（男/女）
    @ExcelProperty("性别")
    private String gender;

    // 生日
    @ExcelProperty("生日")
    // 在生日字段上添加@DateTimeFormat注解，在这个注解下配置指定的日期格式：yyyy年MM月dd日
    @DateTimeFormat(value = "yyyy年MM月dd日")
    private Date birthday;

    // 构造器、getter、setter已省略...
}
```

改造后的`Employee.getDataList()`方法的改造：

```java
/**
 * 获取员工列表数据
 */
public static List<Employee> getDataList() {
    List<Employee> employeeList = new ArrayList<>();
    Random random = new Random();
    Calendar calendar = Calendar.getInstance();
    for (int i = 0; i < employeeArray.length; i++) {
        Employee employee = new Employee();
        employee.setId(i + 1);
        employee.setEmployeeId(UUID.randomUUID().toString());
        employee.setEmployeeName(employeeArray[i]);
        // 随机生成1995~2002年的生日
        calendar.set(random.nextInt(8) + 1995,
                random.nextInt(12) + 1,
                random.nextInt(28) + 1);
        employee.setBirthday(calendar.getTime());
        // 根据上述生日计算年龄
        int age = Calendar.getInstance().get(Calendar.YEAR) - calendar.get(Calendar.YEAR);
        employee.setAge(age);
        // 按照规定格式输出年龄
        String ageContent = age + "岁";
        employee.setAgeContent(ageContent);
        // 随机生成性别
        employee.setGender(random.nextInt(2) == 1 ? "男" : "女");
        employeeList.add(employee);
    }
    return employeeList;
}

/**
 * 改造后的列表方法
 *
 * @return 列表
 */
public static List<Employee> getAttendanceList() {
    List<Employee> dataList = getDataList();
    Random random = new Random();
    for (Employee employee : dataList) {
        double attendanceRate = random.nextDouble();
        employee.setAttendanceRate(attendanceRate);
    }
    return dataList;
}
```

编写测试方法，使用EasyExcel将数据输出到Excel文件中：

```java
@Test
public void testCustomFormat() {
    String filePath = EmployeeUtils.getFilePath();
    EasyExcel.write(filePath, Employee.class).sheet(0, "五月份研发部人员出勤表").doWrite(EmployeeUtils.getDataList());
    System.out.println("数据已写入到Excel文件中");
}
```

此时生成的文件中“年龄”这一列符合要求：

![](https://source.icode504.com/images/image-20240715230732303.png)

以下是使用EasyExcel的实现思路：

1.   创建一个转换器，需要实现`Converter<String>`接口；
2.   在实体类所对应的属性上的`@ExcelProperty`注解配置`conterver`属性，值是转换器类字节码；
3.   使用EasyExcel相关方法，将符合条件的数据输出到Excel文件中

以下是上述思路的代码实现：

自定义转换器MyCustomStringConverter，实现`Converter<String>`接口，并且需要重写`converToExcelData`方法，以下两种实现方法任选其一：

-   方式一：重写`convertToExcelData(WriterConverterContext)`方法：

```java
package com.icode504.converter;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.converters.WriteConverterContext;
import com.alibaba.excel.metadata.data.WriteCellData;

/**
 * 自定义转换器
 *
 * @author iCode504
 * @date 2024-07-03
 */
public class MyCustomStringConverter implements Converter<Integer> {
    
    @Override
    public WriteCellData<?> convertToExcelData(WriteConverterContext<Integer> context) {
        return new WriteCellData<>(context.getValue() + "岁");
    }

}
```

-   方式二：重写`convertToExcelData(String, ExcelContentProperty, GlobalConfiguration)`方法：

```java
package com.icode504.converter;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.converters.WriteConverterContext;
import com.alibaba.excel.metadata.GlobalConfiguration;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.metadata.property.ExcelContentProperty;

/**
 * 自定义转换器
 *
 * @author iCode504
 * @date 2024-07-03
 */
public class MyCustomStringConverter implements Converter<String> {

    @Override
    public WriteCellData<?> convertToExcelData(String value, ExcelContentProperty contentProperty, GlobalConfiguration globalConfiguration) throws Exception {
        return new WriteCellData<>(value + "岁");
    }
}
```

实体类Employee处理：在需要自定义格式的属性对应的`@ExcelProperty`添加`converter`属性，值是上述类的字节码。删除前面添加`ageContent`属性（因为后续没有存在的必要了）：

```java
package com.icode504.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.format.NumberFormat;
import com.icode504.converter.MyCustomStringConverter;
import lombok.*;

import java.util.Date;

/**
 * 员工--实体类
 *
 * @author iCode504
 * @date 2024-03-18
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {

    // 序号
    @ExcelProperty(value = "序号")
    private Integer id;

    // 员工号
    @ExcelProperty("员工号")
    private String employeeId;

    // 员工姓名
    @ExcelProperty("员工姓名")
    private String employeeName;

    // 年龄
    // 在@ExcelProperty注解上添加converter属性，对应的值就是前面添加的自定义转换器的字节码
    @ExcelProperty(value = "年龄", converter = MyCustomStringConverter.class)
    private Integer age;

    // 性别（男/女）
    @ExcelProperty("性别")
    private String gender;

    // 生日
    @ExcelProperty("生日")
    // 在生日字段上添加@DateTimeFormat注解，在这个注解下配置指定的日期格式：yyyy年MM月dd日
    @DateTimeFormat(value = "yyyy年MM月dd日")
    private Date birthday;

    // 出勤率指定为#.##%，就不需要再另外添加属性和对列表方法进行改动了
    @NumberFormat("#.##%")
    @ExcelProperty("出勤率")
    private Double attendanceRate;

    // 构造器、getter、setter已省略...
}
```

此时再执行此时方法，输出的Excel文件和不使用自定义转换器的方式一模一样：

```java
@Test
public void testCustomFormat() {
    String filePath = EmployeeUtils.getFilePath();
    EasyExcel.write(filePath, Employee.class).sheet(0, "五月份研发部人员出勤表").doWrite(EmployeeUtils.getDataList());
    System.out.println("数据已写入到Excel文件中");
}
```

![](https://source.icode504.com/images/image-20240716224943653.png)
