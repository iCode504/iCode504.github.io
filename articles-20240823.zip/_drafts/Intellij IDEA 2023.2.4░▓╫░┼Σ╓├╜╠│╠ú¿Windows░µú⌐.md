> Intellij IDEA（简称IDEA）是Java语言的集成开发环境，在业界公认为是一款优秀的Java开发工具。分为Community社区版（免费）和Untimate终极版（付费）。
>
> IDEA是一款智能编译器。它可以进行智能代码补全、提供问题工具窗口、代码上下文检查操作、实时模板、项目级别代码重构、重复代码检测等功能。
>
> IDEA终极版为现代应用程序和Java相关微服务开发框架提供了一流的支持。IDEA对SpringBoot、Jakata EE、JPA等框架提供一流的支持。
>
> 其内部支持很多的内置工具，例如：调试器、数据库工具、终端、反编译器、WEB开发、版本控制（Git）、导航和搜索功能等。

下面就来介绍一下Windows版的Intellij IDEA 2023如何安装和使用。

# 一、安装Intellij IDEA

1\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，进入命令行窗口后输入`systeminfo`，查看系统类型，这里我的电脑是x64的：

![](https://source.icode504.com/images/image-20240107124636208.png)

2\. 进入IDEA的官方下载页面，[点我查看](https://www.jetbrains.com.cn/idea/download/other.html)。这里我下载的是2023.2.4版本（事实上，要下载的版本和最新版本使用Java编写代码的差异并不大）

![](https://source.icode504.com/images/image-20240103083852889.png)

3\. 根据电脑的系统类型下载安装包：

![](https://source.icode504.com/images/image-20240103085004362.png)

3\. 双击打开安装包，出现IDEA欢迎界面后，点击**Next**：

![](https://source.icode504.com/images/image-20240103085446363.png)

5\. 点击**Browse**，选择安装路径，建议安装在除C盘外的其他位置，这里我安装在了D盘，完成后点击Next：

![](https://source.icode504.com/images/image-20240103085606093.png)

![](https://source.icode504.com/images/image-20240103085725550.png)

![](https://source.icode504.com/images/image-20240103085922906.png)

6\. 安装选项按照下图所示勾选即可：

![](https://source.icode504.com/images/image-20240103090130221.png)

7\. 点击`Install`：

![](https://source.icode504.com/images/image-20231026112118222.png)

8\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20231026112159702.png)

9\. 点击`Finish`完成安装：

![](https://source.icode504.com/images/image-20231026112731774.png)

# 二、激活Intellij IDEA

一共有三种方式：购买正版、学生认证、个人破解。任选一种方式激活即可。

## 方式一：官网正版购买（土豪/真爱党专属）

1\. 点击右侧链接进入正版IDEA购买页面（支持微信/支付宝，购买时需要提供个人邮箱）：[点我购买](https://www.jetbrains.com.cn/idea/buy/?section=personal&billing=yearly)

2\. 以下是个人使用的收费说明：

- 个人按年购买IDEA1400元，第二年1120元，第三年以后是840元。
- 个人按月购买IDEA140元，连续购买12个月以后，第二年连续订阅打八折，第三年连续订阅打六折。

![](https://source.icode504.com/images/image-20240103092358786.png)

## 方式二：个人破解（适用于平民党）

<font color='#EE0000' size=24>注意：仅供学习使用！仅供学习使用！仅供学习使用！重要的事情说三遍！</font>

> 个人破解这一部分参考了犬小哈老师的教程，感兴趣的小伙伴可以查看原作者编写的教程，写的非常好！[点我查看原文](https://www.quanxiaoha.com/idea-pojie/idea-pojie-202323.html)

1\. 点击右侧链接，下载破解补丁：[点我下载](https://icode504.lanzouw.com/i0gSs1k1f0wf)

2\. 将下载的压缩包解压到一个**纯英文路径**中，这里我放到了D盘的Crack文件夹中：

![](https://source.icode504.com/images/image-20240104214916216.png)

3\. 打开`scripts`文件夹，双击打开`install-current-user.vbs`破解脚本

![image-20240104215124208](https://source.icode504.com/images/image-20240104215124208.png)

4\. 出现提示窗口后，点击**确定**：

![](https://source.icode504.com/images/image-20240104215254540.png)

5\. 耐心等待一段时间后，出现完成窗口，点击确定。

![](https://source.icode504.com/images/image-20240104215346705.png)

6\. 复制下面的激活码：

```
6G5NXCPJZB-eyJsaWNlbnNlSWQiOiI2RzVOWENQSlpCIiwibGljZW5zZWVOYW1lIjoic2lnbnVwIHNjb290ZXIiLCJhc3NpZ25lZU5hbWUiOiIiLCJhc3NpZ25lZUVtYWlsIjoiIiwibGljZW5zZVJlc3RyaWN0aW9uIjoiIiwiY2hlY2tDb25jdXJyZW50VXNlIjpmYWxzZSwicHJvZHVjdHMiOlt7ImNvZGUiOiJQU0kiLCJmYWxsYmFja0RhdGUiOiIyMDI1LTA4LTAxIiwicGFpZFVwVG8iOiIyMDI1LTA4LTAxIiwiZXh0ZW5kZWQiOnRydWV9LHsiY29kZSI6IlBEQiIsImZhbGxiYWNrRGF0ZSI6IjIwMjUtMDgtMDEiLCJwYWlkVXBUbyI6IjIwMjUtMDgtMDEiLCJleHRlbmRlZCI6dHJ1ZX0seyJjb2RlIjoiSUkiLCJmYWxsYmFja0RhdGUiOiIyMDI1LTA4LTAxIiwicGFpZFVwVG8iOiIyMDI1LTA4LTAxIiwiZXh0ZW5kZWQiOmZhbHNlfSx7ImNvZGUiOiJQUEMiLCJmYWxsYmFja0RhdGUiOiIyMDI1LTA4LTAxIiwicGFpZFVwVG8iOiIyMDI1LTA4LTAxIiwiZXh0ZW5kZWQiOnRydWV9LHsiY29kZSI6IlBHTyIsImZhbGxiYWNrRGF0ZSI6IjIwMjUtMDgtMDEiLCJwYWlkVXBUbyI6IjIwMjUtMDgtMDEiLCJleHRlbmRlZCI6dHJ1ZX0seyJjb2RlIjoiUFNXIiwiZmFsbGJhY2tEYXRlIjoiMjAyNS0wOC0wMSIsInBhaWRVcFRvIjoiMjAyNS0wOC0wMSIsImV4dGVuZGVkIjp0cnVlfSx7ImNvZGUiOiJQV1MiLCJmYWxsYmFja0RhdGUiOiIyMDI1LTA4LTAxIiwicGFpZFVwVG8iOiIyMDI1LTA4LTAxIiwiZXh0ZW5kZWQiOnRydWV9LHsiY29kZSI6IlBQUyIsImZhbGxiYWNrRGF0ZSI6IjIwMjUtMDgtMDEiLCJwYWlkVXBUbyI6IjIwMjUtMDgtMDEiLCJleHRlbmRlZCI6dHJ1ZX0seyJjb2RlIjoiUFJCIiwiZmFsbGJhY2tEYXRlIjoiMjAyNS0wOC0wMSIsInBhaWRVcFRvIjoiMjAyNS0wOC0wMSIsImV4dGVuZGVkIjp0cnVlfSx7ImNvZGUiOiJQQ1dNUCIsImZhbGxiYWNrRGF0ZSI6IjIwMjUtMDgtMDEiLCJwYWlkVXBUbyI6IjIwMjUtMDgtMDEiLCJleHRlbmRlZCI6dHJ1ZX1dLCJtZXRhZGF0YSI6IjAxMjAyMjA5MDJQU0FOMDAwMDA1IiwiaGFzaCI6IlRSSUFMOi0xMDc4MzkwNTY4IiwiZ3JhY2VQZXJpb2REYXlzIjo3LCJhdXRvUHJvbG9uZ2F0ZWQiOmZhbHNlLCJpc0F1dG9Qcm9sb25nYXRlZCI6ZmFsc2V9-SnRVlQQR1/9nxZ2AXsQ0seYwU5OjaiUMXrnQIIdNRvykzqQ0Q+vjXlmO7iAUwhwlsyfoMrLuvmLYwoD7fV8Mpz9Gs2gsTR8DfSHuAdvZlFENlIuFoIqyO8BneM9paD0yLxiqxy/WWuOqW6c1v9ubbfdT6z9UnzSUjPKlsjXfq9J2gcDALrv9E0RPTOZqKfnsg7PF0wNQ0/d00dy1k3zI+zJyTRpDxkCaGgijlY/LZ/wqd/kRfcbQuRzdJ/JXa3nj26rACqykKXaBH5thuvkTyySOpZwZMJVJyW7B7ro/hkFCljZug3K+bTw5VwySzJtDcQ9tDYuu0zSAeXrcv2qrOg==-MIIETDCCAjSgAwIBAgIBDTANBgkqhkiG9w0BAQsFADAYMRYwFAYDVQQDDA1KZXRQcm9maWxlIENBMB4XDTIwMTAxOTA5MDU1M1oXDTIyMTAyMTA5MDU1M1owHzEdMBsGA1UEAwwUcHJvZDJ5LWZyb20tMjAyMDEwMTkwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCUlaUFc1wf+CfY9wzFWEL2euKQ5nswqb57V8QZG7d7RoR6rwYUIXseTOAFq210oMEe++LCjzKDuqwDfsyhgDNTgZBPAaC4vUU2oy+XR+Fq8nBixWIsH668HeOnRK6RRhsr0rJzRB95aZ3EAPzBuQ2qPaNGm17pAX0Rd6MPRgjp75IWwI9eA6aMEdPQEVN7uyOtM5zSsjoj79Lbu1fjShOnQZuJcsV8tqnayeFkNzv2LTOlofU/Tbx502Ro073gGjoeRzNvrynAP03pL486P3KCAyiNPhDs2z8/COMrxRlZW5mfzo0xsK0dQGNH3UoG/9RVwHG4eS8LFpMTR9oetHZBAgMBAAGjgZkwgZYwCQYDVR0TBAIwADAdBgNVHQ4EFgQUJNoRIpb1hUHAk0foMSNM9MCEAv8wSAYDVR0jBEEwP4AUo562SGdCEjZBvW3gubSgUouX8bOhHKQaMBgxFjAUBgNVBAMMDUpldFByb2ZpbGUgQ0GCCQDSbLGDsoN54TATBgNVHSUEDDAKBggrBgEFBQcDATALBgNVHQ8EBAMCBaAwDQYJKoZIhvcNAQELBQADggIBABqRoNGxAQct9dQUFK8xqhiZaYPd30TlmCmSAaGJ0eBpvkVeqA2jGYhAQRqFiAlFC63JKvWvRZO1iRuWCEfUMkdqQ9VQPXziE/BlsOIgrL6RlJfuFcEZ8TK3syIfIGQZNCxYhLLUuet2HE6LJYPQ5c0jH4kDooRpcVZ4rBxNwddpctUO2te9UU5/FjhioZQsPvd92qOTsV+8Cyl2fvNhNKD1Uu9ff5AkVIQn4JU23ozdB/R5oUlebwaTE6WZNBs+TA/qPj+5/we9NH71WRB0hqUoLI2AKKyiPw++FtN4Su1vsdDlrAzDj9ILjpjJKA1ImuVcG329/WTYIKysZ1CWK3zATg9BeCUPAV1pQy8ToXOq+RSYen6winZ2OO93eyHv2Iw5kbn1dqfBw1BuTE29V2FJKicJSu8iEOpfoafwJISXmz1wnnWL3V/0NxTulfWsXugOoLfv0ZIBP1xH9kmf22jjQ2JiHhQZP7ZDsreRrOeIQ/c4yR8IQvMLfC0WKQqrHu5ZzXTH4NO3CwGWSlTY74kE91zXB5mwWAx1jig+UXYc2w4RkVhy0//lOmVya/PEepuuTTI4+UJwC7qbVlh5zfhj8oTNUXgN0AOc+Q0/WFPl1aw5VV/VrO8FCoB15lFVlpKaQ1Yh+DVU8ke+rt9Th0BCHXe0uZOEmH0nOnH/0onD
```

7\. 打开IDEA，会出现一个用户协议窗口，勾选协议，完成后点击**Continue**：

![](https://source.icode504.com/images/image-20240104215643194.png)

8\. 数据共享，点击**Don't Send**，不发送任何数据：

![](https://source.icode504.com/images/image-20240104215809730.png)

9\. 按照下图操作，激活IDEA：

![](https://source.icode504.com/images/image-20240104220110149.png)

10\. 激活成功，点击Continue之后就可以编写代码了：

![](https://source.icode504.com/images/image-20240104220232208.png)

11\. 如果出现下面的反馈窗口，点击**No Thanks**即可：

![](https://source.icode504.com/images/image-20240104220327436.png)

# 三、使用Intellij IDEA创建Java项目

1\. 请确保本地已经安装了JDK，如果没有安装的，查看此文章一步一步安装即可：[点我查看](https://zhuanlan.zhihu.com/p/626465440)。

2\. 输入`java -version`命令表示电脑上已经成功安装并配置了JDK：

![img](https://source.icode504.com/images/v2-64aba410fcb514b6ab24c746db122258_r.jpg)

3\. 创建项目：点击左侧`Projects`，然后点击`New Project`创建一个新项目：

![](https://source.icode504.com/images/image-20240104220601317.png)

4\. 自定义项目名称、项目存储路径、语言选择Java，构建系统选择Intellij，JDK选择1.8（如果你的电脑中安装了多个版本的JDK，可以在IDEA中选择），全部配置完成后点击**Create**就创建了一个Java项目：

![](https://source.icode504.com/images/image-20240104221542661.png)

# 四、创建Java文件并运行程序

1\. 成功创建Java项目后，IDEA会弹出一个每日提示的窗口，勾选**Don't show tips on startup**不再提示，再点击右下角的**Close**关闭：

![](https://source.icode504.com/images/image-20240107112521924.png)

2\. **鼠标右键点击src**文件夹，点击**New**，选择第一个**Java Class**创建Java文件：

![](https://source.icode504.com/images/image-20240107113044739.png)

3\. 创建Java文件，自定义Java文件名（类名），命名要符合[标识符命名规范](https://www.icode504.com/posts/3.html#%E6%A0%87%E8%AF%86%E7%AC%A6)：

![](https://source.icode504.com/images/image-20240107113345699.png)

4\. 输入`psvm`或者`main`，即可生成`main`方法：

![输入psvm，回车后就可以生成main方法](https://source.icode504.com/images/240107001.gif)

![输入psvm，回车后就可以生成main方法](https://source.icode504.com/images/240107002.gif)

5\. 在`main`方法中输入`sout`，即可生成一个换行输出的`System.out.println();`语句：

![输入sout，即可生成一个换行输出的语句](https://source.icode504.com/images/240107003.gif)

6\. 这里我写了一个简单的Java程序：

```java
public class Demo01 {
	public static void main(String[] args) {
    	System.out.println("昔人已乘黄鹤去，此地空余黄鹤楼。");
        System.out.println("黄鹤一去不复返，白云千载空悠悠。");
        System.out.println("晴川历历汉阳树，芳草萋萋鹦鹉洲。");
        System.out.println("日暮乡关何处是？烟波江上使人愁。");
    }
}
```

效果图如下：

![](https://source.icode504.com/images/image-20240107115557009.png)

7\. 运行Java程序，鼠标右键点击代码，点击**Run xxx.main()**（或者直接按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>F10</kbd>）即可运行这个Java程序：

![](https://source.icode504.com/images/image-20240107115702587.png)

8\. 此时控制台就会输出内容，Java程序成功运行：

![](https://source.icode504.com/images/image-20240107120119389.png)

# 五、Intellij IDEA的卸载（可选）

1\. 在桌面上鼠标右键点击IDEA，选择**打开文件所在的位置**：

![](https://source.icode504.com/images/image-20240107123129271.png)

2\. 此时会IDEA的安装目录，找到**Uninstall.exe**开始卸载：

![](https://source.icode504.com/images/image-20240107123308045.png)

3\. 将下面两个框进行勾选。然后点击**Uninstall**：

![](https://source.icode504.com/images/image-20240107123407085.png)

3\. 卸载中，请耐心等待：

![](https://source.icode504.com/images/image-20240107123427560.png)

4\. 卸载完成，点击**Close**：

![](https://source.icode504.com/images/image-20231019145621728.png)
