---
title: MySQL 8.0安装、配置与卸载教程（Linux通用版）
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

需要在虚拟机安装Linux系统的小伙伴，请点击下方任意一个链接查看安装配置教程：

|          |                       CentOS                       |                       Ubuntu                       |                       Debian                       |
| :------: | :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: |
| 安装教程 | [点我查看](https://www.icode504.com/posts/48.html) | [点我查看](https://www.icode504.com/posts/51.html) | [点我查看](https://www.icode504.com/posts/52.html) |

MySQL是一个关系型数据库管理系统，目前为Oracle旗下产品，它具有开源、体积小、速度快的优点，许多网站使用的都是MySQL数据库。

简单而言，MySQL数据库核心功能就是用来存储数据的。

MySQL数据库分为社区版和商业版，以下介绍社区版的安装教程：

# 一、安装前检查（Linux端）

1\. 检查Linux发行版本信息，执行如下命令：

```bash
uname -a
```

这里我使用的是Ubuntu，x64指令集：

![](https://source.icode504.com/images/image-20240310222707920.png)

2\. MySQL需要依赖`libaio`的库，如果此库未在Linux本地安装，则数据目录初始化和随后的服务器启动步骤将失败。因此我们需要安装一下这个库：

**Ubuntu/Debian**

查看这个库相关的信息：

```bash
apt-cache search libaio
```

![](https://source.icode504.com/images/image-20240327232333231.png)

安装`libaio`：

```bash
apt-get install libaio1
```

这里我已经安装了这个库：

![](https://source.icode504.com/images/image-20240327232431247.png)

**CentOS：**

查看这个库相关信息：

```bash
yum search libaio
```

安装`libaio`：

```bash
yum -y install libaio
```

3\. （首次安装的小伙伴请忽略这一条内容跳转到下一步）如果你之前在Linux中通过`yum`或者`apt`方式安装了MySQL，那么下面的安装可能会产生问题。请确保电脑中已经成功卸载了MySQL并且将残留文件（例如使用MySQL过程中产生的数据文件）也清理干净。另外配置文件`/etc/my.cnf`和配置目录`/etc/mysql`也需要删除。

4\. 安装多线程下载工具`axel`，可以加快后续下载安装包的速度。

- CentOS

```bash
yum -y install axel
```

- Ubuntu

```bash
apt -y install axel
```

# 二、下载MySQL安装包（Windows端）

1\. 打开MySQL官网下载链接：[点我查看](https://downloads.mysql.com/archives/community/)

2\. 按照下图所示操作选择相应的MySQL版本下载，这里我选择的MySQL 8.0.30版本：

![](https://source.icode504.com/images/image-20240328085310766.png)

3\. 打开Neat Download Manager，点击New URL，将上一步复制的链接粘贴到输入框中，点击**Download**下载：

![](https://source.icode504.com/images/image-20240328085446398.png)

![](https://source.icode504.com/images/image-20240328085622715.png)

4\. 下载中，请耐心等待：

![](https://source.icode504.com/images/image-20240328085759219.png)

4\. 下载完成后，点击**Open Folder**，找到安装包所在的文件夹：

![](https://source.icode504.com/images/image-20240328085844815.png)

5\. 点击文件夹上方的**查看**，然后勾选**文件扩展名**：

![](https://source.icode504.com/images/image-20240328085958582.png)

6\. 选中我们刚刚下载好的文件，按<kbd>F2</kbd>键，将文件名后缀名改为`tar.xz`，如下图所示：

![](https://source.icode504.com/images/image-20240328090150316.png)

7\. 此时弹出一个提示窗口，点击**是**即可完成修改：

![](https://source.icode504.com/images/image-20240328090209990.png)

# 三、安装并启动MySQL

1\. 将前面下载好的MySQL安装包使用SFTP工具（这里我使用的是Eleterm）由Windows端传输到Linux端（请先确保Windows本身已经通过SSH方式连接到Linux）：

![](https://source.icode504.com/images/image-20240224172925751.png)

2\. 在左侧Windows端找到下载好的安装包：

![](https://source.icode504.com/images/image-20240328083652105.png)

3\. 在右侧Linux端设置安装包存放路径，这里我将安装包存放在`/usr/local`下：

![](https://source.icode504.com/images/image-20240328083941250.png)

6\. 按照下图所示操作，将MySQL安装包传到Linux端的`/usr/local`目录下：

![](https://source.icode504.com/images/240103280001.gif)

7\. 等待一段时间后，此时Linux端的`/usr/local`目录下已经存放了刚才我们传输的文件：

![](https://source.icode504.com/images/image-20240328090540818.png)

8\. 此时我们切换回命令行，执行如下命令切换到`/usr/local`目录下：

```bash
cd /usr/local
```

9\. 创建名为`mysql`的用户组，执行如下命令：

```bash
groupadd mysql
```

10\. 在上面的用户组下创建一个系统用户`mysql`，设置成不能登录状态（因为MySQL服务不需要登录shell，设置成系统用户可以增加安全性）。执行如下命令：

```bash
useradd -r -g mysql -s /bin/false mysql
```

11\. 将前面传输过来的安装包解压，执行如下命令：

```bash
tar xvf mysql-8.0.30-linux-glibc2.12-x86_64.tar.xz
```

12\. 等待一段时间后，压缩包成功解压。我们创建一个符号链接`mysql`，让这个符号链接指向解压后的路径（类似Windows端创建快捷方式），后续我们只需要访问这个符号链接即可，不需要输入完整的路径。执行如下命令：

```bash
ln -s mysql-8.0.30-linux-glibc2.12-x86_64 mysql
```

13\. 切换到解压后的路径：

```bash
cd mysql
```

执行`ls`可以查看当前目录下内容：

![](https://source.icode504.com/images/image-20240328092541371.png)

14\. 在当前目录下创建一个`mysql-files`文件夹：

```bash
mkdir mysql-files
```

15\. 为这个文件夹分配组`mysql`和用户`mysql`：

```bash
chown mysql:mysql mysql-files
```

16\. 将这个文件夹设置权限：拥有者可以读写和执行，所属组`mysql`的成员可以读和执行，其他用户没有任何权限。执行如下命令：

```bash
chmod 750 mysql-files
```

17\. 指定`mysql`用户启动MySQL服务器并执行初始化，执行如下命令：

```bash
bin/mysqld --initialize --user=mysql
```

初始化过程中会为MySQL服务器的`root`用户（注意这个用户并不是Linux最高权限的用户）创建一个临时的初始密码，这里我们建议将生成密码**截图**保存一下：

![](https://source.icode504.com/images/image-20240328094051612.png)

18\. 生成SSL/TLS所需的RSA密钥对和证书文件，这些文件通常用于MySQL服务器和客户端之间建立安全的加密连接。执行如下命令：

```bash
bin/mysql_ssl_rsa_setup
```

> 备注：`mysql_ssl_rsa_setup`功能在MySQL 8.0.34及之后的版本已经过时，不需要再执行上述操作。

19\. 将服务文件添加到

```bash
cp support-files/mysql.server /etc/init.d/mysql.server
```

