---
abbrlink: null
archive: false
banner_img: null
categories: []
category:
- 软件安装
category_bar: true
date: '2024-08-22T10:33:31.309+08:00'
description: null
index_img: null
order: ''
password: null
tags:
- PostgreSQL
- Linux
title: PostgreSQL安装和配置教程（Linux版）
updated: '2024-08-22T15:44:51.641+08:00'
---
PostgreSQL是基于[POSTGRES 4.2](https://dsf.berkeley.edu/postgres.html)版本的对象-关系型数据库，由加州大学伯克利分校计算机系研发。POSTGRES开创了许多先进理念，这些概念后来才在一些数据库系统中出现（他们的[官网](https://www.postgresql.org/)标题宣传的是世界上最先进的开源关系型数据库）。

PostgreSQL是原伯克利代码的后代，它是开源的，支持大部分SQL标准并提供很多现代化特性：复杂查询、外键、触发器、更新视图等。

此外，用户能以多种方式扩展PostgreSQL，例如可以添加新数据类型、新函数、新操作符等。由于自由的许可，PostgreSQL可以被任何人使用、修改、发布。

以下是Linux环境下PostgreSQL的安装、配置与卸载教程：

# 一、安装前操作

1\. 需要安装Liunx操作系统的小伙伴，点击下面任意一个链接查看安装教程：


|                       CentOS                       |                       Ubuntu                       |                       Debian                       |
| :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: |
| [点我查看](https://www.icode504.com/posts/94.html) | [点我查看](https://www.icode504.com/posts/51.html) | [点我查看](https://www.icode504.com/posts/52.html) |

2\. 本文使用数据库管理软件DBeaver，需要安装的小伙伴根据自己的操作系统查看安装教程：


|                      Windows                      |                       macOS                       |
| :------------------------------------------------: | :------------------------------------------------: |
| [点我查看](https://www.icode504.com/posts/77.html) | [点我查看](https://www.icode504.com/posts/81.html) |

3\. 根据操作系统安装如下依赖：

- CentOS

```bash
yum -y install gcc g++ make vim tar wget bzip2
```

- Ubuntu/Debian

```bash
apt-get -y install gcc g++ make vim tar wget
```

# 二、下载PostgreSQL安装包

1\. 这里我使用`wget`命令下载的是15.4版本的源码安装包，存储到`/usr/local`目录下：

```bash
wget -P /usr/local https://mirrors.tuna.tsinghua.edu.cn/postgresql/source/v15.4/postgresql-15.4.tar.bz2
```

> 说明：需要安装其他版本的源码安装包，请点击右侧链接：[点我查看](https://mirrors.tuna.tsinghua.edu.cn/postgresql/source/)
>
> ![](https://source.icode504.com/images/image-c59e9bc588b5ff21a3842f619e87dbe5.png)
>
> ![](https://source.icode504.com/images/image-99c1be94cbaff0ba534532dd5d04b0a5.png)

2\. 下载完成后，切换到`/usr/local`目录下：

```bash
cd /usr/local
```

3\. 下载完成后，执行`ls`命令，出现PostgreSQL安装包：

![](https://source.icode504.com/images/image-08bd0dad21aefc6665db4d351034dbef.png)

# 三、安装PostgreSQL

1\. 将下载好的安装解压，执行如下命令：

```bash
tar xf postgresql-15.4.tar.bz2
```

2\. 进入解压后的文件夹，执行如下命令：

```bash
cd postgresql-15.4
```

3\. 安装前检测系统环境（不适用readline和zlib检查），生成适合该环境的Makefile：

```bash
./configure --without-readline --without-zlib
```

此时执行`ls`命令可以看到生成的Makefile文件：

![](https://source.icode504.com/images/image-83f940f794070438cf23340d5f04dddc.png)

4\. 根据`Makefile`编译源代码，生成可执行文件和其他相关文件（编译需要较长时间，请耐心等待）：

```bash
make
```

5\. 切换到`root`用户（可能需要输入密码）：

```bash
su
```

6\. 将编译好的文件复制到指定目录下（默认是`/usr/local/pgsql`目录）：

```bash
make install
```

7\. 创建一个名为`postgres`的用户（密码自定义，为了方便记忆，这里我将其设置为123456）：

```bash
adduser postgres
```

8\. 创建一个存储数据文件的目录`/usr/local/pgsql/data`：

```bash
mkdir -p /usr/local/pgsql/data
```

9\. 将`/usr/local/pgsql/data`目录所有权变更为`postgres`用户：

```bash
chown postgres /usr/local/pgsql/data
```

10\. 切换到`postgres`用户：

```bash
su - postgres
```

11\. 初始化PostgreSQL数据库，创建数据库目录结构和默认配置：

```bash
/usr/local/pgsql/bin/initdb -D /usr/local/pgsql/data
```

出现下面提示说明PostgreSQL初始化成功：

![](https://source.icode504.com/images/image-1b55f9f51950879f3d20d4023baad38c.png)

# 四、为PostgreSQL设置环境变量

> 为了方便后续在命令行中使用PostgreSQL相关命令，建议为PostgreSQL设置环境变量。

1\. 点击Electerm上方点击加号，再打开一个命令行窗口（登录的是`root`用户）：

![](https://source.icode504.com/images/image-7d2a04bc5d166688e7e03bc8e4dc91c8.png)

2\. 使用vim命令编辑环境变量文件`/etc/profile`：

```bash
vim /etc/profile
```

3\. 复制下面内容：

```bash
PATH=/usr/local/pgsql/bin:$PATH
export PATH
```

4\. 进入vim编辑器后，按<kbd>i</kbd>键进入编辑模式，将光标移动到文件末尾，按<kbd>Shift</kbd><kbd>Insert</kbd>键将上一步复制的内容粘贴到此处：

![](https://source.icode504.com/images/image-3551750e88aa1f8d3938562c187090e5.png)

5\. 按<kbd>Esc</kbd>键退出编辑，输入`:wq`保存并退出。

6\. 使用`source`命令让配置文件生效：

```bash
source /etc/profile
```

7\. 这里我们来检查一下上述配置是否生效，执行如下命令可以查看当前PostgreSQL版本信息：

```bash
psql --version
```

![](https://source.icode504.com/images/image-354de070ea930868ec883b0d8ccc782a.png)

# 五、启动PostgreSQL服务并设置为开机自启动

1\. （当前登录的是`root`用户）使用vim命令在创建一个PostgreSQL服务文件：

```bash
vim /etc/systemd/system/postgresql.service
```

2\. 复制下方内容：

```shell
[Unit]
Description=PostgreSQL database server
Documentation=man:postgres(1)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=postgres
ExecStart=/usr/local/pgsql/bin/postgres -D /usr/local/pgsql/data
ExecReload=/bin/kill -HUP $MAINPID
KillMode=mixed
KillSignal=SIGINT
TimeoutSec=infinity

[Install]
WantedBy=multi-user.target
```

3\. 进入vim编辑器后，按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd><kbd>Insert</kbd>键将上一步复制的内容粘贴到此处：

![](https://source.icode504.com/images/image-e84abc457e86aececadbdf8450ed094b.png)

4\. 按<kbd>Esc</kbd>键退出编辑，输入`:wq`保存并退出。

5\. 执行如下命令重新加载配置文件：

```bash
systemctl daemon-reload
```

6\. 重启PostgreSQL服务：

```bash
systemctl restart postgresql && systemctl enable postgresql
```

7\. 执行如下命令可以查看PostgreSQL服务状态：

```bash
systemctl status postgresql
```

此时PostgreSQL正常运行，退出查看请按<kbd>Q</kbd>键：

![](https://source.icode504.com/images/image-87e85fad694709a3404e59fcc213e097.png)

8\. 如果您希望PostgreSQL开机自启动，执行如下命令即可：

```bash
systemctl enable postgresql
```

# 六、远程连接PostgreSQL

上述内容如果你已经配置好，你就可以在命令行使用PostgreSQL了：

```bash
psql -h localhost -p 5432 -U postgres
```

此时我们只需要填写前面配置`postgres`用户密码，即可正常使用：

![](https://source.icode504.com/images/image-4c97cf4917e197950ecff1da3ebda146.png)

但是更多的情况下，我们使用的是第三方客户端（例如：Navicat、DBeaver等）远程连接PostgreSQL服务器，并且默认情况下系统没有开放PostgreSQL默认端口5432，并且PostgreSQL默认只开放本机访问，其他远程访问默认是拒绝的。

以下是解决上述问题的方案：

1\. 使用vim命令编辑`/usr/local/pgsql/data`目录下的`postgresql.conf`文件：

```bash
vim /usr/local/pgsql/data/postgresql.conf
```

2\. 进入vim的命令模式后，依次执行如下命令：

```bash
:set nu
/localhost
```

3\. 按<kbd>i</kbd>键将第60行修改成所有IP都可以访问，效果图如下：

![](https://source.icode504.com/images/image-be16766ee4a0a6748c8fdc3804ce54a8.png)

4\. 按<kbd>Esc</kbd>退出编辑模式，输入`:wq`保存并退出。

5\. 使用vim命令编辑`/usr/local/pgsql/data`目录下`pg_hba.conf`文件：

```bash
vim /usr/local/pgsql/data/pg_hba.conf
```

6\. 进入vim的命令模式后，依次执行如下命令：

```bash
:set nu
/127.0.0.1
```

7\. 在第91行末尾换行，添加如下内容，所有IP访问都需要密码，效果图如下：

![](https://source.icode504.com/images/image-dbe866a9fb8784f56bbe5bc873c342df.png)

8\. 按<kbd>Esc</kbd>退出编辑模式，输入`:wq`保存并退出。

9\. 重启PostgreSQL服务：

```bash
systemctl restart postgresql
```

10\. 开放5432端口（PostgreSQL默认使用端口），这里我是用的是`ufw`命令：

```bash
ufw allow 5432/tcp
```

此时使用`ufw status`命令可以看到5432端口已经开放访问：

![](https://source.icode504.com/images/image-2932443f8796aa076bb4727a37d0cd43.png)

11\. 打开DBeaver，按照下图所示操作选择PostgreSQL：

![](https://source.icode504.com/images/image-dd7e6ba7685ea9860a4c0eb6417eea74.png)

![](https://source.icode504.com/images/image-2b8d13cf57b37207cf97a4c91ed22427.png)12\.

12\. 按照下图所示操作配置数据库连接信息

![](https://source.icode504.com/images/image-6a91dc025c054b98e91d03551eeb19e9.png)

13\. 点击测试连接的小伙伴需要下载数据驱动文件，点击下载即可：

![](https://source.icode504.com/images/image-5e4328f5185df7a30cd3c6dd0eec9878.png)

14\. 等待一段时间后，驱动下载完成，点击取消关闭下载驱动界面：

![](https://source.icode504.com/images/image-abbf41c68dca2c1a3d8676780d65987c.png)







15\.
