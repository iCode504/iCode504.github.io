---
title: Todo-list案例
tags: [Vue]
category_bar: true
archive: true
abbrlink:
description:
banner_img:
index_img:
category: [Vue, TodoList案例]
password: 123456
---

# 一、组件化编码流程

1\. 拆分静态组件：组件要按照功能点分，命名不要和HTML中的元素发生冲突。

2\. 实现静态组件：考虑好数据的存放位置，数据是一个组件再用，还是一些组件在用。

- 一个组件在用：放在组件自身即可。
- 一些组件在用：放在他们共同的父组件上（状态提升）。

3\. 实现交互：从绑定事件开始。

# 二、props适用范围

1\. 父组件 ==> 子组件 通信

2\. 子组件 ==> 父组件 通信（要求父先给子一个函数）

3\. 使用`v-model`时要切记：`v-model`绑定的值不能是`props`传过来的值，因为`props`是不可以修改的！

4\. `props`传过来的若是对象类型的值，修改对象中的属性时Vue不会报错，但是不推荐这样做。

# 一、使用Vue脚手架创建模块

1\. 找一个合适位置创建模块，这里我将模块名称设置为todo-list，执行如下代码：

```bash
vue create todo-list
```

2\. 使用Vue 2的语法来创建

![](https://source.icode504.com/images/image-20240222103410734.png)

3\. 创建中，请耐心等待：

![](https://source.icode504.com/images/image-20240222103516590.png)

4\. 创建完成，切换到`todo-list`文件夹：

```bash
cd todo-list
```

5\. 将`src\components`目录下的HelloWorld.vue文件删除：

![](https://source.icode504.com/images/image-20240323090439725.png)

6\. 将App.vue中所有和HelloWorld组件全部清空，代码如下：

```vue
<template>
  <div id="app">
    
  </div>
</template>

<script>


export default {
  name: 'App',
  components: {
    
  }
}
</script>

<style>

</style>
```

# 二、将页面中的内容拆分成组件

我们需要将页面中的内容拆分成组件：

![](https://source.icode504.com/images/image-20240323085837044.png)

可以拆分成四部分：头部（TodoHeader）、列表（TodoList）、列表项（TodoItem）、底部（TodoFooter）。我们在`src\components`目录下分别创建这四个文件：

![](https://source.icode504.com/images/image-20240323090737944.png)

将原来页面HTML代码和CSS样式根据实际情况拆分到这四个组件和App组件中，拆分后具体代码如下：

- TodoHeader.vue

```vue
<template>
  <div class="todo-header">
    <input type="text" placeholder="请输入你的任务名称，按回车键确认" />
  </div>
</template>

<script>
export default {
  name: "TodoHeader",
};
</script>

<style scoped>
/*header*/
.todo-header input {
  width: 560px;
  height: 28px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 4px 7px;
}

.todo-header input:focus {
  outline: none;
  border-color: rgba(82, 168, 236, 0.8);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075),
    0 0 8px rgba(82, 168, 236, 0.6);
}
</style>
```

- TodoFooter.vue

```vue
<template>
  <div class="todo-footer">
    <label>
      <input type="checkbox" />
    </label>
    <span> <span>已完成0</span> / 全部2 </span>
    <button class="btn btn-danger">清除已完成任务</button>
  </div>
</template>

<script>
export default {
  name: "TodoFooter",
};
</script>

<style scoped>
/*footer*/
.todo-footer {
  height: 40px;
  line-height: 40px;
  padding-left: 6px;
  margin-top: 5px;
}

.todo-footer label {
  display: inline-block;
  margin-right: 20px;
  cursor: pointer;
}

.todo-footer label input {
  position: relative;
  top: -1px;
  vertical-align: middle;
  margin-right: 5px;
}

.todo-footer button {
  float: right;
  margin-top: 5px;
}
</style>
```

- TodoItem.vue

```vue
<template>
  <li>
    <label>
      <input type="checkbox" />
      <span>xxxxx</span>
    </label>
    <button class="btn btn-danger">删除</button>
  </li>
</template>

<script>
export default {
  name: "TodoItem",
};
</script>

<style scoped>
/*item*/
li {
  list-style: none;
  height: 36px;
  line-height: 36px;
  padding: 0 5px;
  border-bottom: 1px solid #ddd;
}

li label {
  float: left;
  cursor: pointer;
}

li label li input {
  vertical-align: middle;
  margin-right: 6px;
  position: relative;
  top: -1px;
}

li button {
  float: right;
  display: none;
  margin-top: 3px;
}

li:before {
  content: initial;
}

li:last-child {
  border-bottom: none;
}
</style>
```

- TodoList.vue：该组件后续需要遍历TodoItem组件内容

```vue
<template>
  <ul class="todo-main">

  </ul>
</template>

<script>
export default {
  name: "TodoList",
};
</script>

<style scoped>
/*main*/
.todo-main {
  margin-left: 0px;
  border: 1px solid #ddd;
  border-radius: 2px;
  padding: 0px;
}

.todo-empty {
  height: 40px;
  line-height: 40px;
  border: 1px solid #ddd;
  border-radius: 2px;
  padding-left: 5px;
  margin-top: 10px;
}
</style>
```

- App.vue的作用就是将上述四个组件整合起来：

```vue
<template>
  <div id="root">
    <div class="todo-container">
      <div class="todo-wrap">
        <TodoHeader />
        <TodoList />
        <TodoFooter />
      </div>
    </div>
  </div>
</template>

<script>
import TodoHeader from "./components/TodoHeader.vue";
import TodoList from "./components/TodoList.vue";
import TodoFooter from "./components/TodoFooter.vue";

export default {
  name: "App",
  components: { TodoHeader, TodoList, TodoFooter },
};
</script>

<style>
/*base*/
body {
  background: #fff;
}

.btn {
  display: inline-block;
  padding: 4px 12px;
  margin-bottom: 0;
  font-size: 14px;
  line-height: 20px;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2),
    0 1px 2px rgba(0, 0, 0, 0.05);
  border-radius: 4px;
}

.btn-danger {
  color: #fff;
  background-color: #da4f49;
  border: 1px solid #bd362f;
}

.btn-danger:hover {
  color: #fff;
  background-color: #bd362f;
}

.btn:focus {
  outline: none;
}

.todo-container {
  width: 600px;
  margin: 0 auto;
}
.todo-container .todo-wrap {
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
}
</style>
```

执行`npm run serve`，此时页面和原页面完全相同。说明我们将页面上的内容拆分到各个组件中。

![](https://source.icode504.com/images/image-20240323093213906.png)

# 三、定义数据结构

> 说明：从这一部分起，为了方便显示Vue组件代码，除了有特殊说明，Vue组件中不显示CSS样式代码。

对于每一个todo事项，需要有如下三个属性：`id`（唯一标识）、`content`（事项内容）、`completed`（是否完成）。存储每一个todo事项需要使用数组来存储。如果想让每一个todo事项正常显示，需要将数据定义在TodoList组件中。

以下是在TodoList组件中定义的数据内容：

```javascript
data() {
  return {
    todos: [
      {id: '0001', content: '吃饭', completed: true},
      {id: '0002', content: '睡觉', completed: false},
      {id: '0003', content: '敲代码', completed: true},
    ],
  };
},
```

由于`todos`是数组，我们需要将todos在页面中进行遍历，并将每一个数据对象传输给TodoItem组件。在TodoLIst组件页面代码需要做如下改动：

```vue
<template>
  <ul class="todo-main">
    <!-- 遍历todos需要使用到v-for，使用对象中的id作为唯一标识 -->
    <TodoItem v-for="todoObj in todos" :key="todoObj.id" :todoObj="todoObj" />
  </ul>
</template>
```

TodoItem组件使用`props`属性来接收到TodoList传输数据对象`todoObj`：

- `content`属性以对象名.属性以插值表达式显示。
- 勾选框我们需要使用到`:checked`实现和`completed`属性绑定。

```vue
<template>
  <li>
    <label>
      <input type="checkbox" :checked="todoObj.completed"/>
      <span>{{ todoObj.content }}</span>
    </label>
    <button class="btn btn-danger" style="display: none">删除</button>
  </li>
</template>

<script>
export default {
  name: "TodoItem",
  // 使用props接收数据对象todoObj
  props: ["todoObj"],
};
</script>
```

再次运行`npm run serve`命令，我们发现数据已经显示在每一个TodoItem中：

![](https://source.icode504.com/images/image-20240323102841672.png)

# 四、添加todo数据对象

要想实现添加todo事项，我们需要在输入框中输入内容，输入完成后按一下回车<kbd>Enter</kbd>将数据添加到数组`todos`中。todo数据对象中的`id`需要保证是唯一的，添加过程中`completed`默认值是false。

要想使用唯一标识作为id，这里我们需要使用npm工具来安装nanoid依赖来生成唯一的uuid，执行如下命令：

```shell
npm i nanoid
```

我们需要在TodoHeader的输入框添加一个键盘事件和对应的函数`addTodo`：

```vue
<template>
  <div class="todo-header">
    <input
      type="text"
      placeholder="请输入你的任务名称，按回车键确认"
      @keyup.enter="addTodo"
    />
  </div>
</template>

<script>
export default {
  name: "TodoHeader",
  methods: {
    add() {
      console.log("addTodo方法被调用了！");
    },
  },
};
</script>
```

此时在输入完成后按一下回车就可以触发`addTodo`函数：

![](https://source.icode504.com/images/240323001.gif)

要想获取到输入框中的内容，只需要在`addTodo`中获取即可：

```javascript
add(e) {
  console.log("addTodo方法被调用了！");
  // 获取输入框中的内容
  console.log(e.target.value);
},
```

但是此时还存在一个非常棘手的问题，数组`todos`在TodoList组件中，而我们现在在输入框中操作的数据在TodoHeader组件中，这两个组件并没有建立联系。下图显示各个组件之间的关系：

![](https://source.icode504.com/images/image-20240323104529886.png)

上图中TodoHeader和TodoList是兄弟关系，但是它们拥有共同的父组件App，要想让TodoHeader组件能获取到数据，我们需要将TodoList组件中的数据项交给App组件去管理，改动后App组件的代码如下：

```vue
<template>
  <div id="root">
    <div class="todo-container">
      <div class="todo-wrap">
        <TodoHeader />
        <TodoList :todos="todos" />
        <TodoFooter />
      </div>
    </div>
  </div>
</template>

<script>
import TodoHeader from "./components/TodoHeader.vue";
import TodoList from "./components/TodoList.vue";
import TodoFooter from "./components/TodoFooter.vue";

export default {
  name: "App",
  components: { TodoHeader, TodoList, TodoFooter },
  data() {
    return {
      todos: [
        { id: "0001", content: "吃饭", completed: true },
        { id: "0002", content: "睡觉", completed: false },
        { id: "0003", content: "敲代码", completed: true },
      ],
    };
  },
};
</script>
```

在App组件中定义一个添加todo数据对象的方法，并将这个方法通过`props`方式传递给TodoHeader组件：

```vue
<template>
  <div id="root">
    <div class="todo-container">
      <div class="todo-wrap">
        <TodoHeader :addTodo="addTodo" />
        <TodoList :todos="todos" />
        <TodoFooter />
      </div>
    </div>
  </div>
</template>

<script>
// 引入nanoid
import { nanoid } from "nanoid";

import TodoHeader from "./components/TodoHeader.vue";
import TodoList from "./components/TodoList.vue";
import TodoFooter from "./components/TodoFooter.vue";

export default {
  name: "App",
  components: { TodoHeader, TodoList, TodoFooter },
  data() {
    return {
      todos: [
        { id: "0001", content: "吃饭", completed: true },
        { id: "0002", content: "睡觉", completed: false },
        { id: "0003", content: "敲代码", completed: true },
      ],
    };
  },
  methods: {
    // 添加一个todo数据对象
    addTodo(value) {
      var todoObj = { id: nanoid(), content: value, completed: false };
      this.todos.unshift(todoObj);
    },
  },
};
</script>
```

TodoHeader组件接收后，直接在其内部的`add`函数中使用App组件的`addTodo`函数，修改后的代码如下：

```vue
<template>
  <div class="todo-header">
    <input
      type="text"
      placeholder="请输入你的任务名称，按回车键确认"
      @keyup.enter="add"
    />
  </div>
</template>

<script>
export default {
  name: "TodoHeader",
  props: ["addTodo"],
  methods: {
    add(e) {
      this.addTodo(e.target.value);
    },
  },
};
</script>
```

此时在输入框中添加内容就可以添加到数组`todos`中了：

![](https://source.icode504.com/images/240323002.gif)

但是此时还有一个小问题，就是我们将数据添加完成后，输入框不应该保留数据，这里我们可以在TodoHeader数据定义一个属性用来接收输入框中的内容，使用`v-model`实现双向数据绑定：

```vue
<template>
  <div class="todo-header">
    <input
      type="text"
      placeholder="请输入你的任务名称，按回车键确认"
      @keyup.enter="add"
      v-model="content"
    />
  </div>
</template>

<script>
export default {
  name: "TodoHeader",
  props: ["addTodo"],
  data() {
    return {
      // 定义content属性用来接收输入框中的内容
      content: "",
    };
  },
  methods: {
    add() {
      this.addTodo(this.content);
      // 按完回车后，需要将输入框内容清空
      this.content = "";
    },
  },
};
</script>
```

此时上述问题成功解决，输入完成后按一下回车，输入框中的内容消失：

![](https://source.icode504.com/images/240323003.gif)
