---
title: Vue UI组件库
tags: [Vue]
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category: [Vue, Vue UI组件库]
password:
---

# 一、按需安装ElementUI

npm安装ElementUI：

```shell
npm i element-ui
```

借助 babel-plugin-component，我们可以只引入需要的组件，以达到减小项目体积的目的。

npm安装babel-plugin-component：

```shell
npm i babel-plugin-component
```

修改babel.config.js`文件：

```js
module.exports = {
  presets: [
    "@vue/cli-plugin-babel/preset",
    ["@babel/preset-env", { modules: false }],
  ],
  plugins: [
    [
      "component",
      {
        libraryName: "element-ui",
        styleLibraryName: "theme-chalk",
      },
    ],
  ],
};
```

