---
title: Vuex
tags: [Vue]
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category: [Vue]
password: 123456
---

# 一、Vuex相关概念

1\. Vuex的概念：在Vue中实现集中式状态（数据）管理的一个Vue插件，对Vue应用中多个组件的共享状态进行集中式的管理（读/写），也是一种组件间通信的方式，且适用于任意组件间通信。

2\. 使用场景：多个组件需要共享数据时。

# 二、搭建Vuex环境

1\. 安装Vuex：

- 使用Vue 2.x

```shell
npm i vuex@3
```

- 使用Vue 3.x

```shell
npm i vuex
```

2\. 创建文件：`src/store/index.js`，并按照下面步骤配置：

```js
// 1. 引入Vue核心库
import Vue from "vue";
// 2. 引入Vuex
import Vuex from "vuex";

// 3. 应用Vuex插件
Vue.use(Vuex);

// 4. 准备actions对象——相应组件中用户的动作
const actions = {};

// 5. 准备mutations对象——修改state中的数据
const mutations = {};

// 6. 准备state对象——保存具体的数据
const state = {};

// 7. 创建并暴露store
export default new Vuex.Store({ actions, mutations, state });
```

3\. 在`main.js`中创建vm时传入`store`配置项：

```js
......
// 引入store
import store from "./store";
......

// 创建vm时传入store
new Vue({
  render: (h) => h(App),
  store,
}).$mount("#app");
```

# 三、Vuex的基本使用

1\. 初始化数据，配置`actions`、配置`mutations`、操作文件`store.js`

```js
import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

const actions = {
  // 响应组件中加的动作
  add(context, value) {
    context.commit("ADD", value);
  },
};

const mutations = {
  // 执行加的操作
  ADD(state, value) {
    state.sum += value;
  },
};

// state对象——保存具体的数据
const state = {
  sum: 0,
};

export default new Vuex.Store({ actions, mutations, state });
```

2\. 在组件中读取Vuex中的数据：`$store.state.sum`

3\. 组件中修改Vuex中的数据：`$store.dispatch('actions中的方法名', 数据)`或者`$store.commit('mutations中的方法名', 数据)`

> 备注：如果没有网络请求或其他业务逻辑，组件中也可以越过actions，即不写`dispatch`，直接写`commit`

# 四、getters的使用

1\. 概念：当state中的数据需要经过加工后再使用时，可以使用getters加工。

2\. 在`store.js`中追加getters配置：

```js
......

const getters = {
  bigSum(state) {
    return state.sum * 10;
  },
};

// 创建并暴露store
export default new Vuex.Store({ actions, mutations, state, getters });
```

3\. 在组件中读取数据：`$store.getters.bigSum`

# 五、四个map方法的使用

首先在要使用的组件中引入Vuex中映射组件map：

```shell
import { mapState, mapGetters, mapMutations, mapActions } from "vuex";
```

1\. **mapState方法**：用于帮助我们映射`state`中的数据为计算属性。

```javascript
computed: {
  // 方式一：借助mapState生成计算属性，sum、name、province（对象写法）
  ...mapState({ sum: "sum", name: "name", province: "province" }),
  
  // 方式二：借助mapState生成计算属性，sum、name、province（对象写法）
  ...mapState(["sum", "name", "province"]),
},
```

2\. **mapGetters方法**：用于帮助我们映射`getters`中的数据为计算属性。

```javascript
computed: {
  // 方式一：借助mapGetters生成计算属性: bigSum（对象写法）
  ...mapGetters({ bigSum: "bigSum" }),
  
  // 方式二：借助mapGetters生成计算属性: bigSum（数组写法）
  ...mapGetters(["bigSum"]),
},
```

3\. **mapActions方法**：用于帮助我们生成与`actions`对话的方法，即包含`$store.dispatch(xxx)`的函数。

```javascript
methods: {
  // 借助mapMutations生成对应的方法，方法中会调用commit去联系mutations（对象写法）
  ...mapMutations({addNumber: 'ADD', subNumber: 'SUB'}),
  
  // 借助mapMutations生成对应的方法，方法中会调用commit去联系mutations（数组写法）
  ...mapMutations(["ADD", "SUB"]),
},
```

4\. **mapMutations方法**：用于帮助我们生成与`mutations`对话的方法，即包含`$store.commit(xxx)`的函数。

```javascript
methods: {
  // 借助mapActions生成对应的方法，方法中会调用dispatch去联系actions（对象写法）
  ...mapActions({addOddNumber: "addOddNumber", addNumberAndWait: "addNumberAndWait"}),
  
  // 借助mapActions生成对应的方法，方法中会调用dispatch去联系actions（数组写法）
  ...mapActions(["addOddNumber", "addNumberAndWait"]),
},
```

> 备注：mapActions与mapMutations使用时，若需要传递参数，需要在模板中绑定事件时传递好参数，否则参数是事件对象。

# 六、模块化+命名空间

1\. 目的：让代码更好维护，让多种数据分类更加明确。

2\. 修改`store.js`：

```javascript
const countAbout = {
  // 开启命名空间
  namespaced: true,
  actions: { ... },
  mutations: { ... },
  state: { ... },
  getters: {
    bigSum(state) {
      return state.sum * 10;
    },
  },
};

const personAbout = {
  // 开启命名空间
  namespaced: true,
  actions: { ... },
  mutations: { ... },
  state: { ... },
};
              
export default new Vuex.Store({
  modules: { countAbout, personAbout },
});
```

3\. 开启命名空间后，组件中读取state数据：

```javascript
// 方式一：通过链式调用直接获取state中的数据
this.$store.state.personAbout.personList;

// 方式二：借助mapState读取state中的数据
...mapState("countAbout", ["sum", "name", "province"]),
...mapState("personAbout", ["personList"]),
```

4\. 开启命名空间后，组件中读取getters数据：

```javascript
// 方式一：自己直接获取
this.$store.getters["personAbout/getPersonInfo"];

// 方式二：借助mapGetters读取
...mapGetters("countAbout", ["bigSum"]),
```

5\. 开启命名空间后，组件中读取dispatch数据：

```javascript
// 方式一：自己直接dispatch
this.$store.dispatch("personAbout/addPersonWang", personName);

// 方式二：借助mapActions
...mapActions("countAbout", ["addOddNumber", "addNumberAndWait"])
```

6\. 开启命名空间后，组件中读取commit数据：

```javascript
// 方式一：自己直接commit
this.$store.commit('personAbout/addPerson', person);

// 方式二：借助mapMutations
...mapMutations('countAbout', ['addNumber', 'subNumber'])
```
