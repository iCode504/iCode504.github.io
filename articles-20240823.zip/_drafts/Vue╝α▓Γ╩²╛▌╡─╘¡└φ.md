---
title: Vue监测数据的原理
tags: [Vue]
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category: [Vue, Vue基础知识]
password:
---

# 一、更新数据时出现的问题

以下面代码为例，如果我点击了更新数据按钮，此时Vue并不会检测到data中数组发生的变化：

```html
<div id="app">
  <button @click="editPerson()">点我修改人物信息</button>
  <ul>
    <li v-for="(person, index) in personList" :key="person.id">
      {{person.name}}--{{person.age}}--{{person.gender}}
    </li>
  </ul>
</div>
<script>
  new Vue({
    el: "#app",
    data() {
      return {
        personList: [
          { id: "002", name: "温兆伦", age: 32, gender: "男" },
          { id: "004", name: "马冬梅", age: 28, gender: "女" },
          { id: "001", name: "周杰伦", age: 34, gender: "男" },
          { id: "003", name: "周冬雨", age: 30, gender: "女" },
        ],
        content: "",
        sortType: 0, // 0原始顺序 1降序 2升序
      };
    },
    methods: {
      editPerson() {
        this.personList[1] = {
          id: "004",
          name: "老马",
          age: 29,
          gender: "男",
        };
      },
    },
  });
</script>
```

点击按钮发现数组内部数据并没有发生变化：

![](https://source.icode504.com/images/240229003.gif)

