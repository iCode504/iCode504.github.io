---
title: 浏览器下载安装Vue3开发者工具插件
tags: [Vue, Vue开发者工具]
category_bar: true
archive: false
abbrlink: 
description: 
banner_img:
index_img:
category: [Vue, Vue3, Vue开发者工具]
password: 123456
---

以下是谷歌浏览器、Edge浏览器、火狐浏览器Vue 3开发者工具插件的安装配置操作，大家根据自身具体情况安装即可：

# 一、谷歌（Chrome）浏览器下载安装Vue开发者工具

## 1.1 设置安全模式

1\. 在谷歌浏览器最上方输入如下内容并回车，进入浏览器设置：

```http
chrome://settings/
```

2\. 在左侧菜单栏点击**隐私与安全**，然后点击下方的**安全**：

![](https://source.icode504.com/images/image-20240331221317105.png)

3\. 安全浏览默认是标准保护，为了保证后续顺利安装上插件，这里我们选择**不保护（不建议）**：

![](https://source.icode504.com/images/image-20240331221441580.png)

4\. 此时弹出一个提示，点击**关闭**即可：

![](https://source.icode504.com/images/image-20240331221557774.png)

## 1.2 下载并安装Vue开发者工具

1\. 下载Vue开发者工具插件：[点我下载]()

2\. 打开谷歌浏览器，按照下图所示打开管理扩展程序：

![](https://source.icode504.com/images/image-20231127152259082.png)

3\. 在浏览器右上角打开开发者模式：

![](https://source.icode504.com/images/image-20231127152522395.png)

4\. 将下载好的Vue开发者工具拖入浏览器的扩展程序中，如果开关打开，就说明Vue开发者工具已经安装成功了。

![](https://source.icode504.com/images/240103310001.gif)

# 二、Edge浏览器下载安装Vue开发者工具

1\. 按照下图所示操作，打开插件商店：

![](https://source.icode504.com/images/image-20240206091431073.png)

![](https://source.icode504.com/images/image-20240206091525131.png)

![](https://source.icode504.com/images/image-20240206091640189.png)

2\. 在插件商店搜索`Vue Developer Tools`并回车，搜索结果第一个就是我们要下载安装的插件，点击**获取**：
