---
title: Golang安装、配置和卸载教程（Windows版）
tags:
  - Golang
  - Go
  - Windows
category_bar: true
abbrlink: 32
description: >-
  本教程简要介绍了在Windows操作系统上安装、配置和卸载Go语言（Golang）的步骤。涵盖了安装程序、环境变量配置和卸载过程，为初学者提供了简单易懂的指导。
banner_img: https://source.icode504.com/images/Golang安装、配置、卸载教程（Windows版）.png
index_img: https://source.icode504.com/images/Golang安装、配置、卸载教程（Windows版）.png
category: 
  - 软件安装
  - Windows
  - 编程语言
  - Golang
password:
date: 2024-01-29 13:47:58
---


Golang，也称为Go语言，是由Google开发的一种静态类型、编译型的编程语言。以下是关于Go语言的一些重要特点和特性：

1. **简洁易读：** Go语言设计简洁，语法清晰，易于阅读和学习。它借鉴了C语言的部分特性，但去除了一些复杂的特性和语法，使得代码更加简洁明了。

2. **并发支持：** Go语言内置了轻量级的并发支持，通过goroutine和channel来实现并发编程。这使得编写并发程序变得更加简单和高效。

3. **垃圾回收：** Go语言拥有自动垃圾回收机制，可以帮助程序员管理内存，减少内存泄漏问题。

4. **静态类型：** Go语言是一种静态类型语言，变量在编译时需要声明其类型，这有助于提高代码的可读性和稳定性。

5. **快速编译：** Go语言的编译速度非常快，可以快速生成可执行文件，适合于快速开发和部署应用程序。

6. **跨平台支持：** Go语言提供了良好的跨平台支持，可以在不同的操作系统上进行开发和部署，包括Windows、Linux和MacOS等。

7. **丰富的标准库：** Go语言拥有丰富的标准库，涵盖了网络、文件操作、并发等各个领域，使得开发者可以更加高效地编写各种类型的应用程序。

Golang主要应用于Web开发、云计算、区块链等领域。

Windows安装Golang有两种方式：直接安装、ZIP解压缩安装（需要配置环境变量）。两种方式**二选一**即可。

# 方式一：直接安装

## 一、下载Golang安装包

1\. 打开右侧链接，进入Go语言官网下载页面：[点我查看](https://golang.google.cn/dl/)

![](https://source.icode504.com/images/image-20231017111013563.png)

2\. 在下方**Stable versions**（稳定版本），选择相应的操作系统对应的安装包下载。这里我使用的是Windows 64位，直接下载下图的安装包即可。

![](https://source.icode504.com/images/image-20240129110522537.png)

## 二、安装Golang

1\. 双击打开安装包：

![](https://source.icode504.com/images/image-20231017112220938.png)

2\. 如果弹出安全警告，直接勾选下面选项，然后点击**运行**即可（没有此弹窗的直接跳转到下一步）。

![](https://source.icode504.com/images/image-20231017112356575.png)

3\. 进入安装欢迎页面以后，点击**Next**：

![](https://source.icode504.com/images/image-20231017112444322.png)

4\. 在协议下方勾选**I accept the terms in the Lincense Agreement**，然后点击**Next**：

![](https://source.icode504.com/images/image-20231017112652583.png)

5\. 点击**Change**选择安装路径，建议安装在除C盘外的路径，路径中建议只包含英文（避免后续使用过程中出现各种各样未知的bug），这里我安装在了D盘：

![](https://source.icode504.com/images/image-20231017113238490.png)

6\. 点击**Install**：

![](https://source.icode504.com/images/image-20231017113305680.png)

7\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20231017113326710.png)

8\. 点击**Finish**，Golang安装完成：

![](https://source.icode504.com/images/image-20231017113409596.png)

9\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，进入命令提示行页面后，输入`go version`，如果出现下方的界面就说明你的Golang安装成功并且可以正常使用了：

![](https://source.icode504.com/images/image-20231017113724236.png)

## 三、卸载Golang（可选）

{% note danger %}
这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！
{% endnote %}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Uninstaller，找到`Go Programming Language amd64 go.xxx`，鼠标右键，点击卸载：

![](https://source.icode504.com/images/image-20240127160904157.png)

2\. 此时弹出一个窗口，选择**是**：

![](https://source.icode504.com/images/image-20240127160943100.png)

3\. 卸载中，请耐心等待：

![](https://source.icode504.com/images/image-20240127161051126.png)

4\. 卸载完毕，Golang程序卸载完成。

# 方式二：ZIP解压缩安装并配置

## 一、下载Golang安装包

1\. 打开右侧链接，进入Go语言官网下载页面：[点我查看](https://golang.google.cn/dl/)

![](https://source.icode504.com/images/image-20240127161816194.png)

2\. 在下方**Stable versions**（稳定版本），选择相应的操作系统对应的安装包下载。这里我使用的是Windows 64位，直接下载下图的zip压缩包即可。

![](https://source.icode504.com/images/image-20240129115224186.png)

## 二、安装并配置Golang

1\. 将下载好的压缩包解压到一个你熟悉的位置（建议是全英文路径），这里我解压到了D盘：

![](https://source.icode504.com/images/image-20240127162207325.png)

![](https://source.icode504.com/images/image-20240127162317618.png)

2\. 接下来我们为Golang配置一下环境变量。找到Golang的安装路径，出现api、bin、doc等文件夹，点击上方路径，**鼠标右键**点击**复制**：

![](https://source.icode504.com/images/image-20240127162639860.png)

3\. 打开文件夹，在左侧此电脑**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

4\. 点击**高级系统设置**：

![](https://source.icode504.com/images/image-20240101010932039.png)

> Windows 10的高级系统设置在右侧：
>
> ![](https://source.icode504.com/images/image-20240101011132186.png)

5\. 点击**环境变量**：

![](https://source.icode504.com/images/image-20240101002218161.png)

6\. 在下方系统变量，点击**新建**：

![](https://source.icode504.com/images/image-20240101002302057.png)

7\. 配置系统变量，按照图示操作即可：

![](https://source.icode504.com/images/image-20240127163059204.png)

8\. 双击Path进入：

![](https://source.icode504.com/images/image-20240101002655185.png)

9\. 按照图示操作即可，然后**一路点击确定**：

![](https://source.icode504.com/images/image-20240129115523661.png)

9\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，进入命令提示行页面后，输入`go version`，如果出现下方的界面就说明你的Golang安装成功并且可以正常使用了：

![](https://source.icode504.com/images/image-20240127163412787.png)

## 三、卸载Golang（可选）

{% note danger %}
这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！
{% endnote %}

1\. 找到go的安装路径，按<kbd>Shift</kbd><kbd>Delete</kbd>彻底删除：

![](https://source.icode504.com/images/image-20240127163842351.png)

2\. 删除环境变量：打开文件夹，在左侧此电脑**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

3\. 点击**高级系统设置**：

![](https://source.icode504.com/images/image-20240101010932039.png)

> Windows 10的高级系统设置在右侧：
>
> ![](https://source.icode504.com/images/image-20240101011132186.png)

4\. 点击**环境变量**：

![](https://source.icode504.com/images/image-20240101002218161.png)

5\. 在下方系统变量中，找到`GO_HOME`并选中，点击右下角**删除**：

![](https://source.icode504.com/images/image-20240127164226369.png)

6\. 双击**Path**进入：

![](https://source.icode504.com/images/image-20240101002655185.png)

7\. 找到下方配置的`%GO_HOME%\bin`并选中，点击右上角的**删除**，完成后**一路点击确定**。至此，Golang卸载完成。

![](https://source.icode504.com/images/image-20240129115642752.png)
