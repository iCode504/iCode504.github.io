---
title: Groovy安装、配置与卸载教程（Windows版）
tags:
  - Groovy
  - Windows
category_bar: true
abbrlink: 34
description: 本文详细介绍了在Windows系统上安装、配置Groovy的步骤，帮助用户快速上手这一动态脚本语言。
banner_img: https://source.icode504.com/images/Groovy安装配置教程（Windows版）.png
index_img: https://source.icode504.com/images/Groovy安装配置教程（Windows版）.png
category: 
  - 软件安装
  - Windows
  - 编程语言
  - Groovy
date: 2024-01-29 14:13:00
password:
---

Groovy是一种基于JVM（Java 虚拟机）的动态脚本语言，它结合了Python、Ruby等语言的特性，旨在提供一种更简洁、更灵活的编程方式。以下是 Groovy 的一主要特点：

1. **动态性：** Groovy是一种动态类型的语言，不需要在编写代码时指定变量的类型，可以根据上下文自动推断类型。

2. **与Java互操作性：** Groovy可以与Java无缝互操作，可以直接调用Java类库和代码，并且可以被 Java 代码调用。

3. **闭包支持：**Groovy 支持闭包（Closures），可以轻松实现函数式编程的特性，简化代码结构。

4. **简化语法：**Groovy提供了简洁的语法，例如支持点操作符、集合操作、字符串插值等，使得代码更加清晰易读。

5. **元编程特性：**Groovy具有强大的元编程特性，包括运行时元编程和编译时元编程，使得可以在运行时动态修改类和对象的行为。

6. **脚本语言特性：**Groovy可以作为脚本语言使用，不需要显式的类和方法定义，可以直接编写执行代码。

7. **丰富的标准库：**Groovy提供了丰富的标准库，包括文件操作、XML/JSON 处理、数据库访问等功能，可以满足各种开发需求。

Groovy适用于开发 Web 应用、脚本编写、测试自动化等各种场景。它可以充分发挥 Java 平台的优势，同时提供更加便捷的编程体验。

# 一、安装前准备

安装Groovy前请确保电脑本机安装了JDK，没有安装的小伙伴，请点击下方任意一个链接查看安装教程（这里我安装的是JDK 8版本的）：

| [JDK 8安装教程](https://www.icode504.com/posts/1.html) | [JDK 11安装教程](https://www.icode504.com/posts/28.html) | [JDK 17安装教程](https://www.icode504.com/posts/26.html) |
| :----------------------------------------------------: | :------------------------------------------------------: | :------------------------------------------------------: |

JDK安装完成后，按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，进入控制台，输入`java -version`，如果出现如下内容，就说明JDK已经安装成功了。

![](https://source.icode504.com/images/image-20230314140629530.png)

由于我们要安装的是4.0版本的Groovy，需要保证JDK版本至少在8以上。以下是官网对不同版本的Groovy安装要求：

![官网对不同的Groovy版本所需的JVM版本要求](https://source.icode504.com/images/image-20231226172918718.png)

# 二、下载Groovy

> 推荐使用NDM（Neat Download Manager）下载文件，可以加快下载速度。如需使用此款软件的小伙伴，可以查看这篇教程：[下载神器NDM（Neat Download Manager）安装配置教程（适用于Windows和MacOS）](https://www.icode504.com/posts/24.html)

1\. 打开Groovy官网下载链接：[点我查看](https://groovy.apache.org/download.html)。向下找到各个版本的下载页：

![](https://source.icode504.com/images/image-20240129144559883.png)

2\. 笔者在撰写这篇文章的时候，Groovy最新稳定版本是4.0版本，我们下载SDK bundle安装包：

![](https://source.icode504.com/images/image-20240129144815996.png)

# 三、安装配置Groovy

1\. 将下载好的安装包解压到一个你熟悉的位置，这里我解压到了D盘：

![](https://source.icode504.com/images/image-20240129150722591.png)

![](https://source.icode504.com/images/image-20240129150612519.png)

2\. 接下来我们为Groovy来配置环境变量。找到Groovy安装路径，直到出现bin、conf、doc等文件夹。点击上方路径，**鼠标右键**点击**复制**：

![](https://source.icode504.com/images/image-20240129151122757.png)

3\. 打开文件夹，在左侧此电脑**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

4\. 点击**高级系统设置**：

![](https://source.icode504.com/images/image-20240101010932039.png)

> Windows 10的高级系统设置在右侧：
>
> ![](https://source.icode504.com/images/image-20240101011132186.png)

5\. 点击**环境变量**：

![](https://source.icode504.com/images/image-20240101002218161.png)

6\. 在下方系统变量，点击**新建**：

![](https://source.icode504.com/images/image-20240101002302057.png)

7\. 配置系统变量，按照图示操作即可：

![](https://source.icode504.com/images/image-20240129151523312.png)

8\. 双击Path进入：

![](https://source.icode504.com/images/image-20240101002655185.png)

9\. 按照图示操作即可，然后**一路点击确定**：

![](https://source.icode504.com/images/image-20240129151715260.png)

10\. 检查Groovy环境变量是否配置成功：按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，进入命令行窗口。输入`groovy -v`或者`groovy -version`，下方出现版本信息就说明Groovy安装成功：

![](https://source.icode504.com/images/image-20240129152111794.png)

# 四、卸载Groovy

1\. 找到Groovy安装目录，按<kbd>Shift</kbd><kbd>Delete</kbd>彻底删除：

![](https://source.icode504.com/images/image-20240129145348459.png)

2\. 删除环境变量：打开文件夹，在左侧此电脑**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

3\. 点击**高级系统设置**：

![](https://source.icode504.com/images/image-20240101010932039.png)

> Windows 10的高级系统设置在右侧：
>
> ![](https://source.icode504.com/images/image-20240101011132186.png)

4\. 点击**环境变量**：

![](https://source.icode504.com/images/image-20240101002218161.png)

5\. 在下方系统变量中，找到`GROOVY_HOME`并选中，点击右下角**删除**：

![](https://source.icode504.com/images/image-20240129145751651.png)

6\. 双击**Path**进入：

![](https://source.icode504.com/images/image-20240101002655185.png)

7\. 找到下方配置的`%GROOVY_HOME%\bin`并选中，点击右上角的**删除**，完成后**一路点击确定**。至此，Groovy卸载完成。

![](https://source.icode504.com/images/image-20240129150138239.png)
