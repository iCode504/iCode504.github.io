---
title: >-
  Intellij IDEA启动Java程序或项目报错【java: Compilation failed: internal java compiler
  error】的解决办法
tags:
  - Intellij IDEA
  - Java
category_bar: true
archive: false
abbrlink: 65
category:
  - Intellij IDEA
  - Bug
  - Java
date: 2024-04-16 15:29:13
description: >-
  解决IDEA运行Java程序时出现的错误信息java: Compilication failed: internal java compiler error
banner_img:
index_img:
password:
---


# 一、问题复现

在IDEA里面写Java测试代码时，运行Java程序，控制台出现了如下报错信息：

<font color="#ff000">java: Compilation failed: internal java compiler error</font>

![](https://source.icode504.com/images/image-20240409163108373.png)

以下是解决上述错误信息的方案（这里我使用的时JDK 8）。

# 二、解决方案

1\. 按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Alt</kbd><kbd>S</kbd>，进入项目结构设置。

2\. 将**Project SDK**和**Project language level**设置成当前JDK的版本：

![](https://source.icode504.com/images/image-20240409164655756.png)

3\. 点击左侧的**Modules**，按照下图操作将**Language Level**设置成当前JDK版本：

![](https://source.icode504.com/images/image-20240409172912312.png)

4\. 点击右侧的**Dependencies**，检查当前Module SDK是否和当前JDK版本保持一致，如果不一致，需要和当前JDK版本保持一致：

![](https://source.icode504.com/images/image-20240409173119559.png)

5\. 如果上述四步全都修改无误后，仍然无法启动，还有解决方案。在左侧项目中找到`.idea`文件夹，在这个文件夹中找到`compiler.xml`文件，双击打开：

![](https://source.icode504.com/images/image-20240416150311983.png)

6\. 将倒数第4行target属性值改成你所使用JDK版本，由于我使用的是JDK 8，因此target属性值需要改成1.8，修改后的代码如下图所示：

![](https://source.icode504.com/images/image-20240416150558475.png)

7\. 此时再次运行Java程序就不会出现上述问题了：

![](https://source.icode504.com/images/240416001.gif)
