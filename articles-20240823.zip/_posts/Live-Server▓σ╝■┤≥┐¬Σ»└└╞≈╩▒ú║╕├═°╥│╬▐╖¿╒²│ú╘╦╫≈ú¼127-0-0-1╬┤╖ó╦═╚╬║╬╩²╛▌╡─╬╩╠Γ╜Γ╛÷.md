---
title: Live Server插件打开浏览器时：该网页无法正常运作，127.0.0.1未发送任何数据的问题解决
date: 2023-12-10 17:02:06
tags: [VS Code, Live Server]
description: Live Server插件打开浏览器时：该网页无法正常运作，127.0.0.1未发送任何数据的问题解决
category: [VS Code bug]
abbrlink: 33
index_img: https://source.icode504.com/images/3183310-20231127114246977-809296701.png
banner_img: https://source.icode504.com/images/3183310-20231127114246977-809296701.png
---

# 一、问题复现

今天使用Vs Code写HTML代码时，使用Live Server打开预览时，发现浏览器显示“该网页无法正常运作，127.0.0.1未发送任何数据”的问题。

![](https://source.icode504.com/images/image-20231127110434914.png)

# 二、解决办法

1\. 在左侧工具栏找到扩展商店，找到Live Server，然后点击对应的小齿轮，进入插件设置。

![](https://source.icode504.com/images/image-20231127111656933.png)

2\. 选择`Extension Settings`

![](https://source.icode504.com/images/image-20231127111808544.png)

3\. 进入设置以后，在最下方有一个`Use Local Ip`的一个设置，将`Use local IP as host`勾选即可。

![](https://source.icode504.com/images/image-20231127112103103.png)

4\. 此时在HTML文件中鼠标右键点击`Open with Live Server`，再次弹出浏览器，此时Live Server就正常工作了。

![](https://source.icode504.com/images/231127001.gif)

