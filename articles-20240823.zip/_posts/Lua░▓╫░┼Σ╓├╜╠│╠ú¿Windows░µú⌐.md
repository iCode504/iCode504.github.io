---
abbrlink: '95'
banner_img: https://source.icode504.com/images/Lua安装配置教程（Windows版）.png
categories:
- 软件安装
- Windows
- 编程语言
- Lua
date: '2024-08-12T15:07:12.131397+08:00'
description: 本教程介绍了在Windows上安装Lua的步骤，包括从官网下载安装包、解压并配置环境变量。完成后，可在命令提示符中通过输入`lua`来验证安装是否成功。并在VS
  Code、Intellij IDEA演示了如何配置Lua并运行。
index_img: https://source.icode504.com/images/Lua安装配置教程（Windows版）.png
order: ''
tags:
- Lua
- Windows
title: Lua安装配置教程（Windows版）
updated: '2024-08-13T23:11:13.137+08:00'
---
Lua是一种轻量级、嵌入式的编程语言，最初在巴西开发。它的设计目标是简单易用，特别适合嵌入到其他软件中，作为脚本语言使用。Lua语法简洁，执行速度快，广泛应用于游戏开发、配置管理、数据处理等场景。因为它小巧且灵活，所以特别适合需要高效、易于集成的项目。

以下是Windows环境下Lua安装和配置教程：

# 一、安装前检查

1\. 推荐安装如下软件：


| 软件名称                     | 安装教程                                           | 说明                                                             |
| ---------------------------- | -------------------------------------------------- | ---------------------------------------------------------------- |
| NDM（Neat Download Manager） | [点我查看](https://www.icode504.com/posts/24.html) | 推荐使用NDM（Neat Download Manager）下载文件，可以加快下载速度。 |

2\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`进入命令行界面，执行如下命令查看当前操作系统信息：

这里我的电脑是Windows操作系统，使用的是x64指令集：

![](https://source.icode504.com/images/image-42448e12a41218868a6c13ecb9bb4fac.png)

# 二、下载Lua

1\. 点击右侧链接进入Lua官网下载页：[点我查看](https://luabinaries.sourceforge.net/download.html)

2\. 这里我下载的是5.4.2版本的安装包，如下图所示：

![](https://source.icode504.com/images/image-61659c1a5b1556130b377625c9fb639c.png)

# 三、安装Lua并配置环境变量

1\. 将下载好的安装包解压到你熟悉的位置，推荐解压到C盘外，且路径是英文路径，这里我解压到了D盘：

![](https://source.icode504.com/images/image-54b05d14bbb77e1d398394f7a8884f76.png)

2\. 为了方便演示，除了lua54.dll以外，这里我将其他文件名中包含54的全部改掉，效果如下图：

![](https://source.icode504.com/images/image-3c32bd19c78b76de3688c98351d732ed.png)

3\. 选中上方路径，鼠标右键点击复制：

![](https://source.icode504.com/images/image-755ca9150bcb8f2b4c7c7ee127211d81.png)

4\. 打开文件夹，在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

5\. 点击**高级系统设置**：


| Windows 11     | ![](https://source.icode504.com/images/image-20240101010932039.png) |
| -------------- | ----------------------------------------------------------------------------- |
| **Windows 10** | ![](https://source.icode504.com/images/image-20240101011132186.png) |

6\. 点击**环境变量**：

![](https://source.icode504.com/images/image-20230314134716166.png)

7\. 在下方系统变量中，找到**Path**，双击进入：

![](https://source.icode504.com/images/image-20230314135756989.png)

8\. 按照图示操作即可，然后一路点击确定。

![](https://source.icode504.com/images/image-a3a9a29b004c9309979ed48d201ac6f8.png)

9\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，点击确定：

![](https://source.icode504.com/images/image-20230314140351859.png)

10\. 在命令行输入如下命令：

```powershell
lua -v
```

出现如下提示就说明上述环境变量配置生效：

![](https://source.icode504.com/images/image-7afd42b33f620107f00daa61fc0aa99e.png)

# 四、VS Code编写并运行Lua

需要安装VS Code的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/38.html)

1\. 打开VS Code，在左侧找到插件商店，依次安装如下三个插件：Lua、Lua Debug、Code Runner

![](https://source.icode504.com/images/image-f8397fedb6746ca655dde38f5e1dc75f.png)

![](https://source.icode504.com/images/image-74f66d8a6a870f94da3e0a8863ebdf6c.png)

![](https://source.icode504.com/images/image-c27df1a3798c01a6207f51d84e447d02.png)

2\. 安装完成，找到Code Runner，点击齿轮图标，选择**扩展设置**：

![](https://source.icode504.com/images/image-a25e5f8ea2e6a1fb46a1aa46e7053a7f.png)

3\. 进入扩展设置页面，点击下方任意一个**在settings.json中编辑**：

![](https://source.icode504.com/images/image-15abf67fb4f714111f4368a76ae32f97.png)

4\. 在`"code-runner.executorMap"`中找到Lua，把Lua安装目录和执行文件名粘贴到此处，效果图如下：

![](https://source.icode504.com/images/image-7636c3f81ea2cc566f49aa9194e26aa7.png)

5\. 按<kbd>Ctrl</kbd>和<kbd>S</kbd>键保存配置文件！

6\. 找一个你经常写代码的位置，这里我选择在E盘编写Lua代码：

![](https://source.icode504.com/images/image-1d6b4f7c59783d513524fbc0a483a88b.png)

7\. 在左侧新建一个Lua文件（文件后缀名为.lua）：

![](https://source.icode504.com/images/image-07aa672a4f079ca899924e026ece869a.png)

8\. 编写一段测试代码：

```lua
print("你好，我是iCode504，程序猿一枚，请多指教！")

if 1 == 1 then
    print(true)
else
    print(false)
end
```

9\. 编写完成后，按<kbd>Ctrl</kbd>和<kbd>S</kbd>键保存，点击右上角的运行按钮，在下方控制台就可以看到运行结果了：

![](https://source.icode504.com/images/image-62340d09e6530af321b2ec7de2f884a5.png)

# 五、Intellij IDEA编写并运行Lua

需要安装Intellij IDEA的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/10.html)

1\. 按<kbd>Ctrl</kbd>+<kbd>Alt</kbd>+<kbd>S</kbd>键，在设置中找到插件商店：

![](https://source.icode504.com/images/image-c30d6f78c336925683957aa257eafdb4.png)

2\. 在搜索框中搜索EmmyLua，第一个就是我们要安装的插件，点击**Install**安装插件：

![](https://source.icode504.com/images/image-1e7d5a1a6165cc2599157ab0cd0eadc7.png)

3\. 安装完成，点击**Restart IDE**，重启IDEA。

4\. 按照下图操作创建项目：

![](https://source.icode504.com/images/image-3fe20ba6fb9a6131302eb1d6fc1688b3.png)

5\. 在新建项目页面的左侧选中Lua项目，然后点击右下角**Next**：

![](https://source.icode504.com/images/image-e60051229e4914b1fab153694061d6e9.png)

6\. 自定义项目名称和项目的存储位置，完成后点击**Finish**：

![](https://source.icode504.com/images/image-b02dcd74af9a16c0e532030f1a8b212e.png)

7\. 在左侧项目目录中找到src文件夹，鼠标右键选择**New**，然后选择**New Lua File**：

![](https://source.icode504.com/images/image-6e8d3d9e19f06f67d8f995c8d16aa7a9.png)

8\. 自定义Lua文件，这里我命名为`MyFirstLuaProgram`，完成后按一下回车<kbd>Enter</kbd>：

![](https://source.icode504.com/images/image-04a52472d3dcc614f20260190232c341.png)

9\. 这里我写了一段测试代码：

```lua
print("你好，我是iCode504，程序猿一枚，请多指教！")

if 1 == 1 then
    print(true)
else
    print(false)
end
```

10\. 运行Lua文件：鼠标右键点击`Run MyFirstLuaProgram`（或者按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>F10</kbd>）

![](https://source.icode504.com/images/image-5acc71c2767fdd023775ca97b7790d17.png)

11\. 此时控制台会出现报错信息，这是因为我们还没有配置Lua执行文件：

![](https://source.icode504.com/images/image-8491104970c478e077eff482892084f0.png)

12\. 找到右上角的运行配置，选择**Edit Configurations**：

![](https://source.icode504.com/images/image-d9878de3de654c4b47f61d80b6394f5a.png)

13\. 进入运行配置页面，找到Program，点击右侧的文件夹：

![](https://source.icode504.com/images/image-f4bd395e170210b981d58f62ffd0bc46.png)

14\. 找到Lua的安装位置并选中`lua.exe`，完成后点击**OK**：

![](https://source.icode504.com/images/image-bca143b8c339a34aea6408556cc8e346.png)

15\. 点击OK，完成配置：

![](https://source.icode504.com/images/image-05eb5836fb0af80446840b8dd8a397bc.png)

16\. 再次运行这个文件，此时我们就可以看到输出结果了：

![](https://source.icode504.com/images/image-af6f125a895349c73d842e0777bb4395.png)

# 六、参考

1\. VS Code配置Lua环境：https://blog.csdn.net/qq_44697754/article/details/133103543

2\. 使用IDEA编写lua脚本并运行：https://blog.csdn.net/qq_53253335/article/details/137603361
