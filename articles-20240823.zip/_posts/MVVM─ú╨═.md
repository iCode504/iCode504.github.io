---
title: MVVM模型
tags:
  - Vue
category_bar: true
archive: true
category:
  - Vue
  - Vue基础知识
password: 123456
abbrlink: 1880068029
date: 2024-02-11 15:59:19
description:
banner_img:
index_img:
---


1\. M（Model，模型）：对应Vue实例中data的数据。

```javascript
data: {
  name: "iCode504"
}
```

2\. V（View，视图）：模板代码（DOM）。

```html
<div id="app">你好，我是{{name}}</div>
```

3\. VM（ViewModel，视图模型）：Vue实例

>   如果创建Vue实例时需要变量名，那么这个变量名就命名为`vm`（ViewModel的缩写）。

```javascript
const vm = new Vue({
  el: "#app",
  data: () => {
    // 函数式写法
    console.log(this);
    return {
      name: "iCode504"
    };
  }
});
```

4\. data中所有定义的属性，最后都出现在了`vm`身上。这一点我们可以在控制台中验证

![](https://source.icode504.com/images/231213002.gif)

5\. `vm`身上所有的属性以及Vue原型上所有属性，在Vue模板中都可以直接使用。

![](https://source.icode504.com/images/image-20231213112917238.png)
