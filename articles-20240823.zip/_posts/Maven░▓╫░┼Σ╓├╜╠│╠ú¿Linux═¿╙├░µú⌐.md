---
title: Maven安装配置教程（Linux通用版）
tags:
  - Maven
  - Linux
category_bar: true
archive: false
description: Maven是一款项目管理和构建工具，适用于Java开发。本教程提供Linux环境下的Maven安装和配置方法，包括下载和安装Maven，配置环境变量设置。
banner_img: 'https://source.icode504.com/images/Maven安装与配置教程（Windows版）-封面.png'
index_img: 'https://source.icode504.com/images/Maven安装与配置教程（Windows版）-封面.png'
category:
  - 软件安装
  - Linux
  - 项目构建工具
abbrlink: 56
date: 2024-03-06 10:41:42
password:
---


# 一、安装前检查（Linux端）

1\. 检查电脑上是否安装JDK，如果没有安装，请查看JDK安装教程：[点我查看](https://www.icode504.com/posts/55.html)

2\. 已经安装JDK的小伙伴，请在命令行执行如下命令，如果出现下图的版本信息，就说明JDK环境变量配置成功：

```bash
java -version
```

![](https://source.icode504.com/images/image-20240225121013682.png)

# 二、下载Maven安装包（Windows端）

以下两种下载Maven安装包方式二选一：

## 方式一：网盘下载（强烈推荐，下载速度非常快）

点击右侧链接，进入下载界面：[点我下载，密码1024](https://icode504.lanzn.com/b014acbmb)

![](https://source.icode504.com/images/image-20240306103605021.png)

## 方式二：官网下载（不推荐，下载速度较慢）

1\. 点击进入官网下载链接：[点我进入](https://archive.apache.org/dist/maven/maven-3/)

2\. 选择一个版本，点击进入，这里我以3.6.3版本为例，按照下图所示操作即可：

![](https://source.icode504.com/images/image-20240305223639246.png)

![](https://source.icode504.com/images/image-20230508214809153.png)

>   说明：source目录下的文件是Maven的源码文件，如果有查看的源码的小伙伴，也可以点击进入下载，这里就不过多赘述了。

3\. 选择`.tar.gz`结尾的安装包下载：

![](https://source.icode504.com/images/image-20240305223849713.png)

# 三、安装并配置Maven环境变量

1\. 将前面下载好的Maven安装包使用SFTP工具（这里我使用的是Eleterm）由Windows端传输到Linux端（请先确保Windows本身已经通过SSH方式连接到Linux）：

![](https://source.icode504.com/images/image-20240224172925751.png)

2\. 在左侧Windows端找到下载好的安装包：

![](https://source.icode504.com/images/image-20240305225348678.png)

3\. 在右侧Linux端设置安装包存放路径，这里我将安装包存放在`/opt`下：

![](https://source.icode504.com/images/image-20240224173503187.png)

4\. 按照下图所示操作，将Maven安装包传到Linux端的`/opt`目录下：

![](https://source.icode504.com/images/24010304001.gif)

5\. 等待一段时间后，此时Linux端的`/opt`目录下已经存放了刚才我们传输的文件：

![](https://source.icode504.com/images/image-20240305225844104.png)

6\. 此时我们切换回命令行，执行如下命令切换到`/opt`目录下：

```bash
cd /opt
```

7\. 解压刚刚传输过来的安装包，执行如下命令：

```bash
tar -zxvf apache-maven-3.6.3-bin.tar.gz
```

>   小技巧：在命令行中输入文件名时，我们可以只写文件的前一部分，然后按一下<kbd>Tab</kbd>键补齐文件名。

8\. 等待一段时间后，解压完成，执行如下命令，进入解压后的文件夹名称：

```bash
ls
```

![](https://source.icode504.com/images/image-20240305230159629.png)

使用`cd`命令进入解压后的文件夹：

```bash
cd apache-maven-3.6.3/
```

9\. 输入如下命令，查看当前文件路径：

```bash
pwd
```

![](https://source.icode504.com/images/image-20240305230416205.png)

10\. 复制如下代码：

```shell
#MAVEN_HOME  
MAVEN_HOME=/opt/apache-maven-3.6.3
PATH=$PATH:$MAVEN_HOME/bin
export PATH MAVEN_HOME
```

11\. 在`/etc/profile.d`目录下创建`maven_env.sh`文件，执行如下命令：

```shell
vim /etc/profile.d/maven_env.sh
```

> 没有`vim`根据自己的操作系统执行如下命令安装：
>
> - CentOS
>
> ```bash
> sudo yum -y install vim
> ```
>
> - Ubuntu/Debian
>
> ```bash
> sudo apt -y install vim
> ```

12\. 按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴第十步的代码，效果如下图所示：

![](https://source.icode504.com/images/image-20240305230648113.png)

13\. 将光标移动到第二行，将`MAVEN_HOME`对应的值替换成第9步复制的路径。完成后按一下Esc键，然后输入`:wq`保存并退出。

14\. 执行如下命令，让环境变量配置生效：

```bash
source /etc/profile.d/maven_env.sh
```

15\. 执行如下命令即可查看当前Maven版本：

```bash
mvn -v
```

![](https://source.icode504.com/images/image-20240305231236570.png)

# 四、配置Maven

前面我们已经配置好Maven，但是我们在以后导入依赖的时候默认使用的是Maven的中央仓库，而中央仓库是国外网站，下载速度比较慢。因此我们需要将Maven下载源设置成国内镜像仓库，提高导入依赖的速度。以下是下载源配置教程。

1\. 找一个你熟悉的位置存放Maven依赖，这里我创建一个目录专门存放Maven依赖：

```bash
mkdir -p /home/maven/repository
```

2\. 进入Maven安装目录：

```bash
cd /opt/apache-maven-3.6.3/
```

3\. 执行如下命令，查看当前目录下的所有文件和文件夹：

```bash
ls
```

![](https://source.icode504.com/images/image-20240305231857803.png)

4\. 进入`conf`文件夹，执行如下命令：

```bash
cd conf/
```

5\. 再次执行`ls`命令，可以看到里面有一个`settings.xml`文件，这个文件就是我们后续需要修改的配置文件：

![](https://source.icode504.com/images/image-20240305232035444.png)

6\. 使用`vim`命令编辑`settings.xml`：

```bash
vim settings.xml
```

7\. 执行如下命令并回车，开启行号显示（命令在左下角显示）：

```bash
:set nu
```

8\. 复制下面代码：

```xml
<profile>
    <id>jdk-1.8</id>
    <activation>
        <activeByDefault>true</activeByDefault>
        <jdk>1.8</jdk>
    </activation>
    <properties>
        <maven.compiler.source>1.8</maven.compiler.source>
        <maven.compiler.target>1.8</maven.compiler.target>
        <maven.compiler.compilerVersion>1.8</maven.compiler.compilerVersion>
    </properties>
</profile>
```

9\. 按<kbd>i</kbd>进入编辑模式，在第246行末尾换行，将上一步代码按<kbd>Shiht</kbd>和<kbd>Insert</kbd>键粘贴到247行中，效果如下图：

![](https://source.icode504.com/images/image-20240305232911281.png)

此时我们配好了Maven的全局JDK版本，使用的是JDK 8版本。

10\. 复制下面的代码：

>   这段代码的含义是将Maven下载依赖源更改为国内的阿里云，可以大幅加快下载速度。

```xml
<mirror>
    <id>nexus-aliyun</id>
    <mirrorOf>central</mirrorOf>
    <name>Nexus aliyun</name>
    <url>http://maven.aliyun.com/nexus/content/groups/public</url>
</mirror>
```

11\. 在第158行末尾处换行，粘贴上一步代码，效果如下图：

![](https://source.icode504.com/images/image-20240305233219372.png)

12\. 跳转到第55行，创建一个`<localRepository></localRepository>`标签，并在二者中间填写第一步你创建的Maven依赖路径，效果如下图所示：

![](https://source.icode504.com/images/image-20240306090505257.png)

13\. 至此，Maven配置完成，按<kbd>Esc</kbd>键退出编辑模式，按<kbd>:wq</kbd>保存并退出。
