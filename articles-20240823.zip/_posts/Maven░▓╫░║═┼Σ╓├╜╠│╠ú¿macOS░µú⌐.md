---
abbrlink: '96'
banner_img: https://source.icode504.com/images/Maven安装与配置教程（Windows版）-封面.png
categories:
- - 软件安装
  - macOS
  - 项目构建工具
date: '2024-08-14T09:32:02.311+08:00'
description: Maven是一款项目管理和构建工具，适用于Java开发。本教程提供macOS环境下的Maven安装和配置方法，包括下载和安装Maven，配置环境变量和镜像仓库设置。
index_img: https://source.icode504.com/images/Maven安装与配置教程（Windows版）-封面.png
order: ''
tags:
- Maven
- Windows
title: Maven安装和配置教程（macOS版）
updated: '2024-08-14T16:04:48.145+08:00'
---
# 一、安装前检查

1\. 检查电脑上是否安装JDK，如果没有安装，请查看JDK安装教程：[点我查看](https://www.icode504.com/posts/78.html)

2\. 如果你已经安装了JDK，打开终端，输入`java -version`，按一下回车，查看JDK安装信息，如果有下面提示信息，说明JDK安装成功

![](https://source.icode504.com/images/image-20240714133339950.png)

# 二、下载Maven

以下两种方式二选一：

## 方式一：网盘下载（强烈推荐，下载速度较快！）

打开此链接：[点击下载，密码:1024](https://icode504.lanzn.com/b014acbmb)，选择任意一个文件下载即可，这里我选择的是3.6.3版本的：

![](https://source.icode504.com/images/image-887542eac528283182046d30dda58225.png)

## 方式二：官网下载（不推荐，曾经同事和我吐槽由于官网是国外的，下载速度非常慢）

1\. 点击进入官网下载链接：[点击进入](https://archive.apache.org/dist/maven/maven-3/)，会出现如下界面

![](https://source.icode504.com/images/image-20240714232914206.png)

2\. 选择一个，点击进入，这里我以3.6.3版本的为例，按下图所示操作即可：

![](https://source.icode504.com/images/image-20240714233055613.png)

> 说明：source目录下的文件是Maven的源码文件，如果有查看的源码的小伙伴，也可以点击进入下载，这里就不过多赘述了。

3\. 使用macOS的小伙伴，点击`.tar.gz`文件下载（如下图）：

![](https://source.icode504.com/images/image-20240714233304292.png)

# 三、安装并配置Maven环境变量

1\. 打开终端，将下载好的安装包（这里我下载到了`~/Downloads/`目录）移动到`/usr/local`目录下：

```bash
sudo mv Downloads/apache-maven-3.6.3-bin.tar.gz /usr/local
```

使用`sudo`命令可能需要输入用户密码。

2\. 切换到`/usr/local`目录下：

```bash
cd /usr/local
```

3\. 解压当前的压缩包：

```bash
sudo mkdir apache-maven-3.6.3 && sudo tar -zxvf apache-maven-3.6.3-bin.tar.gz 
```

4\. 创建一个软连接（类似Windows快捷方式），方便我们后续快速切换目录：

```bash
sudo ln -s apache-maven-3.6.3 maven
```

5\. 切换到安装目录：

```bash
cd maven
```

6\. 在当前目录下创建一个`maven_env.sh`文件：

```bash
sudo vim maven_env.sh
```

7\. 复制如下代码：

```bash
#MAVEN_HOME  
MAVEN_HOME=/usr/local/maven
PATH=$PATH:$MAVEN_HOME/bin
export PATH MAVEN_HOME
```

8\. 按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴上一步的代码，效果如下图所示：

![](https://source.icode504.com/images/image-606e82bbcffdac4231903161a9b43217.png)

9\. 完成后按一下Esc键，然后输入`:wq`保存并退出。

10\. 执行如下命令，让环境变量配置生效：

```bash
source maven_env.sh
```

11\. 执行如下命令即可查看当前Maven版本：

```bash
mvn -v
```

![](https://source.icode504.com/images/image-004121af09f9a65d3de13a0e90612d44.png)

# 四、配置Maven

前面我们已经配置好Maven，但是我们在以后导入依赖的时候默认使用的是Maven的中央仓库，而中央仓库是国外网站，下载速度比较慢。因此我们需要将Maven下载源设置成国内镜像仓库，提高导入依赖的速度。以下是下载源配置教程。

1\. 这里我在Maven目录中专门创建一个文件夹来存放Maven依赖：

```bash
sudo mkdir -p /usr/local/maven/repository
```

2\. 使用`vim`命令编辑Maven配置文件`settings.xml`：

```bash
sudo vim /usr/local/maven/conf/settings.xml
```

3\. 执行如下命令并回车，开启行号显示（命令在左下角显示）：

```bash
:set nu
```

4\. 复制下面代码：

```xml
<profile>
    <id>jdk-1.8</id>
    <activation>
        <activeByDefault>true</activeByDefault>
        <jdk>1.8</jdk>
    </activation>
    <properties>
        <maven.compiler.source>1.8</maven.compiler.source>
        <maven.compiler.target>1.8</maven.compiler.target>
        <maven.compiler.compilerVersion>1.8</maven.compiler.compilerVersion>
    </properties>
</profile>
```

5\. 按<kbd>i</kbd>进入编辑模式，在第246行末尾换行，将上一步代码按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴到247行中，效果如下图：

![](https://source.icode504.com/images/image-387847aa4cee1954319060f2c4c6a3d6.png)

此时我们配好了Maven的全局JDK版本，使用的是JDK 8版本。

6\. 复制下面的代码：

> 这段代码的含义是将Maven下载依赖源更改为国内的阿里云，可以大幅加快下载速度。

```xml
<mirror>
    <id>nexus-aliyun</id>
    <mirrorOf>central</mirrorOf>
    <name>Nexus aliyun</name>
    <url>http://maven.aliyun.com/nexus/content/groups/public</url>
</mirror>
```

7\. 在第158行末尾处换行，粘贴上一步代码，效果如下图：

![](https://source.icode504.com/images/image-bf7270b36125eda7bd67ed5aba4a883d.png)

8\. 跳转到第55行，创建一个`<localRepository></localRepository>`标签，并在二者中间填写第一步你创建的Maven依赖路径，效果如下图所示：

![](https://source.icode504.com/images/image-d513feb5d6774c5cb6cdfe07a9328ee9.png)

9\. 至此，Maven配置完成，按<kbd>Esc</kbd>键退出编辑模式，按`:wq`保存并退出。
