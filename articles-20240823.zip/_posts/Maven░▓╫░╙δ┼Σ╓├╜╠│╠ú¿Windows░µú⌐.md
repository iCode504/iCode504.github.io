---
title: Maven安装与配置教程（Windows版）
date: 2023-12-11 11:45:30
tags: [Maven, Windows]
category: 
  - 软件安装
  - Windows
  - 项目构建工具
description: Maven是一款项目管理和构建工具，适用于Java开发。本教程提供Windows版本的Maven安装和配置方法，包括下载和安装Maven，配置环境变量设置。
abbrlink: 19
banner_img: https://source.icode504.com/images/Maven安装与配置教程（Windows版）-封面.png
index_img: https://source.icode504.com/images/Maven安装与配置教程（Windows版）-封面.png
---

# 一、安装前检查

1. 检查电脑上是否安装JDK，如果没有安装，请查看JDK安装教程：[点我查看](https://zhuanlan.zhihu.com/p/626465440)

2. 如果电脑上已经安装JDK，按<kbd>Win</kbd> 和<kbd>R</kbd>键，输入`cmd`，然后点击确定

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230508205645141.png)

3. 输入`java -version`，点击`回车`，查看JDK安装信息，如果有下面提示信息，说明JDK安装成功

![img](https://mypicture0706.oss-cn-beijing.aliyuncs.com/v2-3fca64e63e8d136f76373193158d9089_720w.webp)

# 二、下载Maven

以下两种方式二选一：

方式一：网盘下载（强烈推荐，下载速度较快！）

打开此链接：[点击下载，密码:1024](https://icode504.lanzouw.com/b012xidad)，选择任意一个文件下载即可，这里我选择的是3.6.3版本的：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230508213842338.png)

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230508214000869.png)

方式二：官网下载（不推荐，曾经同事和我吐槽由于官网是国外的，下载速度非常慢）

1. 点击进入官网下载链接：[点击进入](https://archive.apache.org/dist/maven/maven-3/)，会出现如下界面

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230508214702016.png)

2. 选择一个，点击进入，这里我以3.6.3版本的为例，按下图所示操作即可

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230508214809153.png)

> 说明：source目录下的文件是Maven的源码文件，如果有查看的源码的小伙伴，也可以点击进入下载，这里就不过多赘述了。

3. 如果你使用的是Windows，请下载后缀名为`.zip`的文件；其他操作系统的请下载`.tar.gz`的版本。

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230508215220278.png)

# 三、配置Maven

1. 将下载下来的压缩包**解压到一个你知道的文件夹下**，为了避免后续可能出现问题，解压目录只包含英文字符 的目录，这里我解压到了`E:/Environment`中

![](https://source.icode504.com/images/image-20230508220254005.png)

2. 双击进入`apache-maven-3.6.3`文件夹中，点击上方路径，鼠标右键点击复制

![](https://source.icode504.com/images/image-20230508220546223.png)

3. 在文件夹左侧，找到此文件，鼠标右键，点击属性

![](https://source.icode504.com/images/image-20230508220742398.png)

4. 点击高级系统设置

![](https://source.icode504.com/images/image-20230508220833089.png)

5. 点击环境变量

![](https://source.icode504.com/images/image-20230508220912799.png)

6. 新建一个环境变量

![](https://source.icode504.com/images/image-20230508220944612.png)

7. 变量名填写`M2_HOME`，变量值将前面复制的内容粘贴进去即可，完成后点击确定。

![](https://source.icode504.com/images/image-20230508221142253.png)

8. 双击打开Path

![](https://source.icode504.com/images/image-20230508221248363.png)

9. 按照下图所示操作即可，完成后一路点击确定。

![](https://source.icode504.com/images/image-20230508221458356.png)

10. 验证Maven是否安装成功：按<kbd>Win</kbd>和<kbd>R</kbd>键，输入cmd，点击进入。

11. 在命令提示行中输入`mvn -version`，如果出现如下提示，说明Maven配置成功！

![](https://source.icode504.com/images/image-20230508221728184.png)

# 四、下载源配置

前面我们已经配置好Maven，但是我们在以后导入依赖的时候默认使用的是Maven的中央仓库，而中央仓库是国外网站，下载速度比较慢。因此我们需要将Maven下载源设置成国内镜像仓库，提高导入依赖的速度。以下是下载源配置教程。

如果你是小白，请一定按照下面的步骤一步一步做:smile::smile::smile:

1. 打开前面我们安装Maven的位置，双击打开conf文件夹。

![](https://source.icode504.com/images/image-20230509200621227.png)

2. 按照下图所示的操作，使用记事本打开`settings.xml`文件

![00002](https://source.icode504.com/images/00002.gif)

3. 用记事本打开后，在上方点击`查看`，然后点击`状态栏`，此时记事本右下角会出现行数

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230509204353762.png)

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230509204435611.png)



4. 请复制下面的代码

```xml
<profile>
    <id>jdk-1.8</id>
    <activation>
        <activeByDefault>true</activeByDefault>
        <jdk>1.8</jdk>
    </activation>
    <properties>
        <maven.compiler.source>1.8</maven.compiler.source>
        <maven.compiler.target>1.8</maven.compiler.target>
        <maven.compiler.compilerVersion>1.8</maven.compiler.compilerVersion>
    </properties>
</profile>
```

5. 在记事本第246行末尾换行，将上一步的代码粘贴到第247行中，效果如下图

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230509204919658.png)

此时我们配好了Maven的全局JDK版本，使用的是JDK 8版本。

6. 请复制下面的代码

```xml
 <mirror>
    <id>nexus-aliyun</id>
    <mirrorOf>central</mirrorOf>
    <name>Nexus aliyun</name>
    <url>http://maven.aliyun.com/nexus/content/groups/public</url>
</mirror>
```

7. 在记事本第158行末尾处换行，粘贴上一步代码，效果如下图：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230509205353978.png)

8. 打开Maven的安装目录，在这里新建一个repository文件夹，创建完成后，进入此文件夹，复制上述路径。

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230509205928445.png)

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230509210144270.png)

9. 打开记事本，在第55行创建一个`<localRepository></localRepository>`标签，并在二者中间粘贴上一步的路径，效果如下图所示：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230509210555912.png)

10. 上述操作完成，请一定一定一定按<kbd>Ctrl</kbd>和<kbd>S</kbd>键保存！！！至此Maven就全部配置完成了。


