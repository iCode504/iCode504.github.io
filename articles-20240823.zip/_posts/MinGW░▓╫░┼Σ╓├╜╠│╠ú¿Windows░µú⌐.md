---
title: MinGW安装配置教程（Windows版）
tags:
  - C
  - C++
  - MinGW
  - Windows
category_bar: true
abbrlink: 39
description: 介绍如何在Windows系统上安装和配置MinGW的教程。它提供了详细的步骤和注意事项，帮助用户顺利完成MinGW的安装和配置
banner_img: https://source.icode504.com/images/MinGW安装配置教程（Windows版）.png
index_img: https://source.icode504.com/images/MinGW安装配置教程（Windows版）.png
category: 
  - 软件安装
  - Windows
  - 编程语言
  - C/C++
date: 2024-02-01 11:05:33
---


MinGW，全称为Minimalist GNU for Windows，是一个可自由使用和发布的Windows特定头文件和使用GNU工具集导入库的集合。它允许在GNU/Linux和Windows平台生成本地的Windows程序而不需要第三方C运行时（C Runtime）库。使用MinGW开发的程序不需要额外的第三方DLL支持就可以在Windows下运行。

以下是MinGW在Windows环境下的安装和配置教程：

# 一、下载MinGW-w64

1\. 打开MinGW-w64官网下载页面（托管到了SourceForge上）：[点我查看](https://sourceforge.net/projects/mingw-w64/files/mingw-w64/mingw-w64-release/)

2\. 向下找，找到最新版本的MinGW，选择seh下载：

![](https://source.icode504.com/images/image-20240201104452235.png)

> 说明（第2、3、4、5点总结的可能不太严谨，如果您在这方面有很深入的了解，可以评论区或者私信告诉我）：
>
> 1\. <font color="FF0000">不要</font>安装上面的`MinGW-W64-install.exe`，这个是联网安装的，服务器在国外，在国内安装因为网络原因大概率会失败。
>
> 2\. x86_64简单而言是64位的操作系统（绝大部分电脑都是64位的），i686属于32位操作系统
>
> 3\. posix（全称Portable Operating System Interface of UNIX，翻译过来就是UNIX可移植操作系统接口），是[IEEE](http://www.ieee.com/)为要在各种UNIX操作系统上运行的软件而定义的一系列API标准总称。
>
> 4\. win32是由Windows操作系统的API，主要也是应用在Windows操作系统上。
>
> 5\. seh（Structured Exception Handling）是Windows操作系统中默认的异常处理机制，sjlj（Signal Set JMP）是Unix及类Unix系统中的一种轻量级异常处理机制。

# 二、安装配置MinGW-w64

1\. 将下载的7z压缩包（推荐使用[Bandzip](https://www.bandisoft.com/bandizip/)、[7-zip](https://7-zip.org/)等解压工具）解压到一个你熟悉的地方（建议是英文路径），这里我解压到了D盘：

![](https://source.icode504.com/images/image-20240131155552319.png)

![](https://source.icode504.com/images/image-20240131155721190.png)

2\. 为MinGW配置环境变量：找到MinGW的安装路径，出现bin、etc、include等文件夹，点击上方路径，**鼠标右键**点击**复制**：

![](https://source.icode504.com/images/image-20240131160221163.png)

3\. 打开文件夹，在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

4\. 点击**高级系统设置**：

|   Windows 11   | ![](https://source.icode504.com/images/image-20240101010932039.png) |
| :------------: | :----------------------------------------------------------: |
| **Windows 10** | ![](https://source.icode504.com/images/image-20240101011132186.png) |

5\. 点击**环境变量**：

![](https://source.icode504.com/images/image-20230314134716166.png)

6\. 在下方系统变量中，点击**新建**：

![](https://source.icode504.com/images/image-20230314134919881.png)

7\. 配置安装路径，按照图示操作即可：

![](https://source.icode504.com/images/image-20240131162334741.png)

8\. 双击Path进入：

![](https://source.icode504.com/images/image-20230314135756989.png)

8\. 按照图示操作即可，然后一路点击确定。

![](https://source.icode504.com/images/image-20240131162546989.png)

9\. 检查Mingw环境变量是否配置成功：按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`并回车，进入控制台，输入`gcc -v`和`g++ -v`，出现版本信息说明环境变量配置成功！

![](https://source.icode504.com/images/image-20240131162902042.png)

![](https://source.icode504.com/images/image-20240131162938776.png)
