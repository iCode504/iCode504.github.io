---
title: MySQL 8.0安装、配置与卸载教程（Windows版）
date: 2023-12-11 11:09:27
tags: [MySQL, Windows]
category: 
  - 软件安装
  - Windows
  - 数据库
category_bar: true
abbrlink: 18
banner_img: https://source.icode504.com/images/Windows安装、配置、卸载MySQL教程.png
index_img: https://source.icode504.com/images/Windows安装、配置、卸载MySQL教程.png
description: 本教程提供MySQL在Windows上的安装、配置与卸载指南，包括下载、安装、配置环境变量、启动MySQL服务、连接MySQL数据库等步骤，以及如何卸载MySQL。
---

MySQL是一个关系型数据库管理系统，目前为Oracle旗下产品，它具有开源、体积小、速度快的优点，许多网站使用的都是MySQL数据库。

简单而言，MySQL数据库核心功能就是用来存储数据的。

MySQL数据库分为社区版和商业版，这里介绍的是社区版的安装教程：

# 一、下载MySQL

1\. 打开MySQL官网下载链接：[点我查看](https://downloads.mysql.com/archives/installer/)

2\. 按照下图所示操作选择相应的MySQL版本下载，这里我选择的Windows MySQL 8.0.30版本。

![](https://source.icode504.com/images/image-20240220110125037.png)

3\. 下载中，请耐心等待。

# 二、安装并配置MySQL

安装MySQL过程中，**请保持网络畅通**！！！

1\. 双击打开安装包，安装器启动需要一些时间，请耐心等待：

![](https://source.icode504.com/images/image-20240220110324590.png)

2\. 如果遇到这个窗口，点击**Yes**即可。如没遇到，请查看下一步。

![](https://source.icode504.com/images/image-20230512214714122.png)

3\. 安装类型选择**Custom**，然后点击**Next**：

![](https://source.icode504.com/images/image-20240220111156356.png)

4\. 按照下图所示操作，选择安装`MySQL Server 8.0.30 - X64`，完成后直接点击**Next**：

![](https://source.icode504.com/images/00003.gif)

> （小白可以忽略下列内容，直接跳到第5步）
>
> - 如果你想修改MySQL的安装路径，如下图，可以点击下方**Advanced Options**：
>
> ![](https://source.icode504.com/images/image-20240220111320444.png)
>
> - 按照下图所示，选择安装路径，为避免后续过程中出现问题，**安装路径建议只包含英文字符**；下面的是MySQL数据存储路径，如果不懂这方面的内容，建议不要修改这个路径。配置完成后后点击**OK**：
>
> ![](https://source.icode504.com/images/image-20240220111711714.png)

5\. 点击**Execute**：

![](https://source.icode504.com/images/image-20230512220628921.png)

6\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20230512220740114.png)

7\. 出现下图提示**Complete**以后，MySQL安装完成。直接点击**Next**：

![](https://source.icode504.com/images/image-20230512220836314.png)

8\. 接下来开始配置MySQL，点击**Next**：

![](https://source.icode504.com/images/image-20230512220905466.png)

9\. 初次安装MySQL的小白请注意，下图的**Port请务必配置成3306**，完成后点击**Next**：

![](https://source.icode504.com/images/image-20240220111939271.png)

> 注意：如果你的电脑安装了多个MySQL，需要修改端口号，要和3306端口避开使用。只安装一个MySQL的小伙伴请忽略此条。

10\. 认证方式选择第一个即可，点击**Next**：

![](https://source.icode504.com/images/image-20230512221223745.png)

11\. 设置root账户密码，这里强烈建议**将密码设置成你最熟悉的密码**，否则后续恢复密码比较麻烦。这里我设置成了`123456`。设置完成后点击**Next**：

![](https://source.icode504.com/images/image-20240220110609804.png)

12\. 在Windows中开启服务，直接点击**Next**即可：

![](https://source.icode504.com/images/image-20230512221927024.png)

13\. 服务器文件权限按照默认配置**选择第一个**即可，点击**Next**：

![](https://source.icode504.com/images/image-20230512222002468.png)

14\. 点击**Execute**，MySQL安装器就会为我们配置上述内容。配置过程中，请耐心等待：

![](https://source.icode504.com/images/image-20230512222105185.png)

15\. 出现下图信息，说明MySQL配置成功，点击**Finish**：

![](https://source.icode504.com/images/image-20230512222243451.png)

16\. 点击**Next**：

![](https://source.icode504.com/images/image-20230512222328898.png)

17\. 点击**Finish**，MySQL配置完成。

![](https://source.icode504.com/images/image-20230512222401129.png)

# 三、配置MySQL环境变量

1\. 初次安装MySQL的小白，按照下图操作复制路径：

![](https://source.icode504.com/images/00005.gif)

> （此条内容小白请忽略）安装在其他位置的小伙伴找到MySQL的安装路径，进入bin文件夹后复制文件路径。

2\. 在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

3\. 点击**高级系统设置**：

|   Windows 11   | ![](https://source.icode504.com/images/image-20240101010932039.png) |
| :------------: | ------------------------------------------------------------ |
| **Windows 10** | ![](https://source.icode504.com/images/image-20240101011132186.png) |

4\. 点击**环境变量**：

![](https://source.icode504.com/images/9b32c83db0d6df2c2f698e9d67d0edfd.png)

5\. 在下方系统变量找到Path，双击进入：

![](https://source.icode504.com/images/image-20230512223639743.png)

6\. 按照下图所示操作，粘贴前面复制的MySQL安装路径，然后一路点击确定即可。

![](https://source.icode504.com/images/image-20240220112157561.png)

7\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，点击进入，在命令提示行中输入`mysql -u root -p`，按回车后会提示让你输入密码。这个密码是前面我们安装MySQL的时候设置的密码，输入完成后按回车即可。完成后出现下图界面表示MySQL安装成功！

![](https://source.icode504.com/images/image-20240220105038897.png)

# 四、卸载MySQL（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

以下两种卸载方式任选其一即可。

{% endnote %}

## 方式一：使用Geek Uninstaller卸载（推荐）

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Installer，在程序列表中找到MySQL相关的内容，鼠标右键，依次点击卸载：

![](https://source.icode504.com/images/image-20240220113015742.png)

2\. 卸载时如果存在残留，直接清理即可。

## 方式二：手动卸载（较麻烦，不推荐）

> MySQL卸载过程会有一些繁琐，卸载过程请一定耐心！如果你按照前面的步骤成功安装MySQL并可以正常使用了，就直接忽略下面的内容。

1\. 停止MySQL的服务：按下图所示操作，进入服务页面。找到MySQL80服务。

![](https://source.icode504.com/images/00006.gif)

2\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`control`，点击进入控制面板，在下方找到卸载程序。

![](https://source.icode504.com/images/image-20240220105209312.png)

3\. 将带有MySQL的程序依次使用鼠标右键卸载：

![](https://source.icode504.com/images/image-20230512231355775.png)

4\. 卸载中，请耐心等待。

5\. 卸载界面不存在MySQL相关程序，说明MySQL卸载成功。

![](https://source.icode504.com/images/image-20230512231640785.png)

6\. 清理残余文件：如果你是小白并且没有修改过MySQL路径，那么你可以去`C盘`的`Program Files`文件夹内看看是否存在MySQL的文件夹。如果存在，直接删除文件夹即可。

7\. 清理注册表

- 按<kbd>Win</kbd>和<kbd>S</kbd>键，输入`regedit`，打开注册表编辑器：

![](https://source.icode504.com/images/image-20240220105352865.png)

- 依次删除下面和MySQL有关的目录。

```
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\Eventlog\Application\MySQL服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\MySQL服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet002\Services\Eventlog\ApplicationMySQL服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet002\Services\MySQL服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Eventlog\Application\MySQL服务目录删除
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MySQL服务 目录删除
```

8\. 删除环境变量

- 如何进入环境变量，请参考第三部分配置MySQL环境变量的前5步。
- 选中MySQL环境变量，点击删除，然后一路点击确定即可。

![](https://source.icode504.com/images/image-20230512233341214.png)

