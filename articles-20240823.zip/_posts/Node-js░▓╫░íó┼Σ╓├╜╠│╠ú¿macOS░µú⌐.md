---
title: Node.js安装、配置教程（macOS版）
tags:
  - Node.js
  - macOS
  - Homebrew
category_bar: true
archive: false
abbrlink: 84
description: >-
  这篇教程旨在为 macOS
  用户提供Node.js的安装指南，涵盖了安装、配置和卸载过程。此外，本文还提供了npm镜像源的修改，方便读者使用国内镜像源快速下载项目所需依赖。
banner_img: >-
  https://source.icode504.com/images/Node.js%E5%AE%89%E8%A3%85%E3%80%81%E9%85%8D%E7%BD%AE%E5%92%8C%E5%8D%B8%E8%BD%BD%E6%95%99%E7%A8%8B%EF%BC%88Windows%E7%89%88%EF%BC%89-%E5%B0%81%E9%9D%A2.png
index_img: >-
  https://source.icode504.com/images/Node.js%E5%AE%89%E8%A3%85%E3%80%81%E9%85%8D%E7%BD%AE%E5%92%8C%E5%8D%B8%E8%BD%BD%E6%95%99%E7%A8%8B%EF%BC%88Windows%E7%89%88%EF%BC%89-%E5%B0%81%E9%9D%A2.png
category:
  - 软件安装
  - macOS
  - 前端框架工具
date: 2024-07-21 21:44:52
password:
---


Node.js 是一个基于 Chrome V8 引擎的 JavaScript 运行时环境，使 JavaScript 能够在服务器端运行，它提供了一个事件驱动的非阻塞 I/O 模型，使得构建高效、可扩展的网络应用变得更加容易。而 npm（Node Package Manager）是 Node.js 的包管理工具，用于安装、分享、管理 JavaScript 代码包，使开发者能够轻松地将自己的代码与他人的代码集成，并且享受到社区共享的各种功能模块。Node.js 和 npm 的结合使得 JavaScript 开发者能够在服务器端和客户端都使用同一种语言，极大地提高了开发效率和跨平台能力。

以下是 macOS 环境下 Node.js 的安装教程。本文提供两种方式安装Node.js，读者任选一种方式安装即可：

# 方式一：正常安装

## 一、下载 Node.js 安装包

1\. 打开右侧链接地址，进入 Node.js 官方下载链接列表页：[点我查看](https://nodejs.org/dist/)

2\. 这里我选择 v16.20.2 版本下载，找到这个文件夹，点击进入：

![](https://source.icode504.com/images/image-20240610231104421.png)

3\. macOS 系统点击以`.pkg`结尾的安装包下载：

![](https://source.icode504.com/images/image-20240720234836974.png)

## 二、安装 Node.js

1\. 打开安装包，进入欢迎界面，点击**继续**：

![](https://source.icode504.com/images/image-20240720235111507.png)

2\. 软件许可协议，点击**继续**：

![](https://source.icode504.com/images/image-20240720235157923.png)

3\. 点击**同意**：

![](https://source.icode504.com/images/image-20240720235223513.png)

4\. 点击**安装**：

![](https://source.icode504.com/images/image-20240720235315573.png)

5\. 输入当前用户名和密码，然后点击**安装软件**：

![](https://source.icode504.com/images/image-20240720235518573.png)

6\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20240720235554831.png)

7\. 安装完成，点击**关闭**：

![](https://source.icode504.com/images/image-20240720235630219.png)

8\. 如果不需要安装包，点击**移到废纸篓**即可：

![](https://source.icode504.com/images/image-20240720235653399.png)

## 三、npm 更换镜像源

Node.js 中包含一个重要模块：npm，它的作用是帮助我们下载项目中的依赖（你可以理解成下载对应的软件包），但是 npm 默认的下载地址在国外，如果使用了默认的下载地址，后续在使用 npm 的过程中下载依赖会非常慢，因此，我们需要将 npm 默认的下载地址改成国内镜像，这里我使用的是淘宝镜像源。

1\. 执行如下命令查看当前`npm`的下载源：

```bash
npm config get registry
```

![](https://source.icode504.com/images/image-20240721000008097.png)

2\. 将镜像源更改成淘宝镜像源，执行如下命令：

```bash
npm config set registry https://registry.npmmirror.com
```

3\. 再次执行如下命令，镜像源成功修改为淘宝镜像源：

```bash
npm config get registry
```

![](https://source.icode504.com/images/image-20240721000256123.png)

# 方式二：Homebrew 安装 Node.js

请确保电脑上已经安装了 Homebrew：[点我查看](https://www.icode504.com/posts/82.html)

## 一、安装 Node.js 并配置环境变量

1\. 打开终端，执行如下命令查找可安装的 Node.js 版本

```bash
brew search node
```

等待一段时间后，我们可以看到如下几个版本的 Node.js：

![](https://source.icode504.com/images/image-20240721102504550.png)

2\. 这里我安装的是 Node.js 16 的最新稳定版本，执行如下命令：

```bash
brew install node@16
```

等待一段时间后（预估 5\~10 分钟），安装完成，接下来我们来配置环境变量。

3\. 在当前目录下新建一个文件 node_env.sh，执行如下命令：

```bash
vim node_env.sh
```

4\. 复制如下代码：

```bash
#NODEJS_HOME
NODEJS_HOME=/usr/local/opt/node@16
PATH=$PATH:$NODEJS_HOME/bin
export PATH NODEJS_HOME
```

5\. 按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴第 4 步的代码，效果如下图所示：

> 下图第 2 行中的路径需要根据你所安装的 Node.js 版本去更改，这里我安装的是 Node.js 16 版本，因此路径是`/usr/local/opt/node@16`，如果你安装的是其他版本的 Node.js，那么将路径改成其他版本的路径。

![](https://source.icode504.com/images/image-20240721104239363.png)

6\. 完成上述配置后，按一下<kbd>Esc</kbd>键，然后输入`:wq`并按一下回车（保存并退出）。

7\. 执行如下命令，让环境变量配置生效：

```bash
source node_env.sh
```

8\. 执行如下两个命令即可查看 Node.js 和 npm 的版本：

```bash
node -v
npm -v
```

## 二、npm 更换镜像源

Node.js 中包含一个重要模块：npm，它的作用是帮助我们下载项目中的依赖（你可以理解成下载对应的软件包），但是 npm 默认的下载地址在国外，如果使用了默认的下载地址，后续在使用 npm 的过程中下载依赖会非常慢，因此，我们需要将 npm 默认的下载地址改成国内镜像，这里我使用的是淘宝镜像源。

1\. 执行如下命令查看当前`npm`的下载源：

```bash
npm config get registry
```

![](https://source.icode504.com/images/image-20240721105347155.png)

2\. 将镜像源更改成淘宝镜像源，执行如下命令：

```bash
npm config set registry https://registry.npmmirror.com
```

3\. 再次执行如下命令，镜像源成功修改为淘宝镜像源：

```bash
npm config get registry
```

![](https://source.icode504.com/images/image-20240721105711377.png)
