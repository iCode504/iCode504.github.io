---
abbrlink: '85'
banner_img: https://source.icode504.com/images/Redis远程连接工具TinyRDM安装、配置和卸载教程（Window版）.png
categories:
- 软件安装
- Windows
- TinyRDM
date: '2024-07-26T14:12:20.611508+08:00'
description: 本教程详细介绍了在Windows系统上安装、配置和卸载Redis远程连接工具TinyRDM的步骤，包括下载安装包、配置连接Redis实例以及卸载程序的操作指南，帮助用户轻松管理Redis数据库。
index_img: https://source.icode504.com/images/Redis远程连接工具TinyRDM安装、配置和卸载教程（Window版）.png
tags:
- Redis
- Windows
- TinyRDM
title: Redis远程连接工具TinyRDM安装、配置和卸载教程（Window版）
updated: '2024-07-26T20:19:56.068+08:00'
---
TinyRDM是一款轻量级的Redis数据库管理工具，提供了用户友好的图形界面，便于开发者和数据库管理员进行Redis数据库的连接、管理和监控。它支持多种Redis命令操作，提供丰富的可视化功能，直观地展示数据结构和存储信息。TinyRDM简洁高效，适合日常的Redis管理工作。

以下是Windows环境下安装Tiny RDM教程：

# 一、准备操作

1\. 请确保Linux操作系统上安装了Redis，需要安装的小伙伴点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/83.html)

2\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`进入命令行界面，执行如下命令查看当前操作系统信息：

```shell
systeminfo
```

这里我的电脑是Windows操作系统，使用的是x64指令集：

![](https://source.icode504.com/images/image-42448e12a41218868a6c13ecb9bb4fac.png)

# 二、下载RDM

1\. 打开Tiny RDM官网：[点我查看]([https://](https://redis.tinycraft.cc/zh/))

2\. 鼠标移到**下载安装**按钮，根据前面我们查看的电脑指令集，x64的小伙伴点击第一个链接下载，arm64的小伙伴按照下图蓝色框找到arm64安装包下载：

![](https://source.icode504.com/images/image-b59501b9a12f6cd374df34e6bbea4d73.png)

# 三、安装Tiny RDM

1\. 双击下载好的安装包，进入欢迎页面，点击**Next**：

![](https://source.icode504.com/images/image-5d61a9e5c54b2371c1de5f9bd7371741.png)

2\. 选择安装位置，这里我安装在了D盘，完成后点击下方的**Install**：

![](https://source.icode504.com/images/image-0338ea215e228ffe2f1f75d4f53756b0.png)

![](https://source.icode504.com/images/image-cdb3280e85900997f87c56463a7321fa.png)

![](https://source.icode504.com/images/image-366228e45dde0f2d6242215118aad761.png)

3\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-19b9e279c735690243cb0c280afa633e.png)

4\. 安装完成，点击**Next**：

![](https://source.icode504.com/images/image-41e953de613efc4a40ceb7f40bf5c63e.png)

5\. 点击Finish，Tiny RDM安装完成：

![](https://source.icode504.com/images/image-aea53fb429cfdcd78af24fe463d79aa1.png)

# 四、使用Tiny RDM远程连接Redis

1\. 在桌面上打开Tiny RDM，点击左下角的加号，新建一个Redis连接：

![](https://source.icode504.com/images/image-c9ca4f23e1de2fbae1604ab9d3e397d5.png)

2\. 按照下图所示操作，配置Redis的连接配置，完成后点击左下角的**测试连接**：

![](https://source.icode504.com/images/image-5f52a47a8b58ea3606d615f8dbd4737c.png)

3\. 如果下方弹出提示“成功连接到Redis服务器”就说明前面的Redis配置没有问题，此时我们点击右下角的确认就可以使用Redis了：

![](https://source.icode504.com/images/image-2e1872a9dac580830efd657e8e03d8cb.png)

4\. 双击左侧的Redis连接，再点击控制台，我们就可以正常使用Redis命令了：

![](https://source.icode504.com/images/image-e69cbbaec6fcf640e0fca44ae8e6d89b.png)

![](https://source.icode504.com/images/image-ce17051a4ad9fa5e8e7760faea13b289.png)

# 五、卸载Tiny RDM

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Uninstaller，找到Tiny RDM，鼠标右键点击卸载：

![](https://source.icode504.com/images/image-1a599a7929a7e9d3ef67b9493ee14e36.png)

2\. 卸载完成，点击**Close**：

![](https://source.icode504.com/images/image-e8074c380dab1832a162f5f92945eb4e.png)

3\. 此时Geek会我们检测出安装残留，我们只需要点击**完成**即可，清除卸载残留：

![](https://source.icode504.com/images/image-1500d9efcb12ecffcfc0436750c6f07f.png)

4\. 清理完毕，关闭Geek即可：

![](https://source.icode504.com/images/image-7e0bc4c21357f1e25531850670e992fb.png)
