---
title: VS Code配置MinGW并编写运行C/C++代码（适用于Windows）
tags:
  - VS Code
  - MinGW
  - C
  - C++
category_bar: true
abbrlink: 40
description: >-
  本文介绍了在Windows系统中使用VS Code配置MinGW环境，并编写运行C/C++代码的步骤。涵盖了MinGW的安装与配置、VS
  Code的设置以及简单代码示例，旨在帮助初学者快速上手C/C++编程。
category:
  - VS Code
  - C/C++
date: 2024-02-04 09:34:32
banner_img:
index_img:
---


请确保电脑本机已经安装了VS Code和MinGW，没有安装的小伙伴按照下方链接给出的教程进行安装：

| [MinGW安装配置教程（Windows版）](https://www.icode504.com/posts/39.html) | [Visual Studio Code安装配置教程（Windows版）](https://www.icode504.com/posts/38.html) |
| :----------------------------------------------------------: | :----------------------------------------------------------: |

1\. 找一个你熟悉的位置写代码，建议文件路径只包含英文字符。这里我在F盘的Code文件夹下创建了一个C-Project文件夹：

![](https://source.icode504.com/images/image-20240203202836440.png)

2\. 打开VS Code，点击左上角文件 --> 打开文件夹。打开上一步我们创建的C-Project空文件夹：

![](https://source.icode504.com/images/image-20240203203122206.png)

![](https://source.icode504.com/images/image-20240203203324194.png)

3\. 点击左上角的插件商店：

![](https://source.icode504.com/images/image-20240203203432028.png)

4\. 在上方搜索框中输入C，下载前三个微软官方提供的插件：C/C++、C/C++ Themes、C++ Extension Pack：

![](https://source.icode504.com/images/image-20240203204408841.png)

5\. 上方弹出一个颜色主题，这里我选择的是第一个：

![](https://source.icode504.com/images/image-20240203204538939.png)

5\. 安装完成，我们点击上方的项目写代码。这里我创建一个C语言文件：`swap.c`，代码如下所示：

```c
// 两数交换
#include <stdio.h>

int main()
{
    int x = 5, y = 10;
    printf("两个数未交换之前的值, x = %d, y = %d\n", x, y);

    // 额外定义一个变量，实现两数的交换
    int temp = x;
    x = y;
    y = temp;

    printf("交换后两个数的值, x = %d, y = %d\n", x, y);
    return 0;
}
```

6\. 按<kbd>Ctrl</kbd>和<kbd>F5</kbd>键，以非调试状态运行程序。在上方调试器选择**C++ (GDB/LLDB)**：

![](https://source.icode504.com/images/image-20240203210122970.png)

7\. 选择**C/C++: gcc.exe 生成和调试活动文件**：

![](https://source.icode504.com/images/image-20240203210217881.png)

8\. 此时左上角生成了一个`.vscode`文件夹，里面包含配置文件，此时点击终端，就可以看到C语言代码的输出结果：

![](https://source.icode504.com/images/image-20240203211336203.png)

