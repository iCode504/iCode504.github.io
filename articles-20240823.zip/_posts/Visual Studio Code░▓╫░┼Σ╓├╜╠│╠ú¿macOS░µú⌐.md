---
abbrlink: '97'
banner_img: https://source.icode504.com/images/Visual Studo Code安装配置教程（Windows版）-封面.png
categories:
  - [软件安装, macOS, 集成开发环境]
date: '2024-08-14T16:16:12.295899+08:00'
description: macOS环境下安装Visual Studio Code并对其做简单的配置
index_img: https://source.icode504.com/images/Visual Studo Code安装配置教程（Windows版）-封面.png
order: ''
tags:
- macOS
- Visual Studio Code
title: Visual Studio Code安装配置教程（macOS版）
updated: '2024-08-14T16:57:08.523+08:00'
---
# 一、安装前准备


| 软件名称                     | 安装教程                                           | 说明                                                             |
| ---------------------------- | -------------------------------------------------- | ---------------------------------------------------------------- |
| NDM（Neat Download Manager） | [点我查看](https://www.icode504.com/posts/24.html) | 推荐使用NDM（Neat Download Manager）下载文件，可以加快下载速度。 |

# 二、下载Visual Studio Code（VS Code）

1\. 打开官网下载地址：[点我查看](https://code.visualstudio.com/Download)

2\. 根据自己的操作系统，选择下载安装包。这里我使用的是macOS，只需要点击第一个即可：

![](https://source.icode504.com/images/image-25df0f629c8a766d25cee7b39c312595.png)

3\. 如果浏览器没有下载，就点击页面中的这个链接下载（浏览器已下载的请忽略这条）：

![](https://source.icode504.com/images/image-a323a0e7ad89cb03e55b167162afd809.png)

# 三、安装Visual Studio Code（VS Code）

1\. 双击打开安装包，此时会将安装包自动解压到当前安装目录：

![](https://source.icode504.com/images/image-9703209f59d6b7eab88e8230ad8f6da1.png)

2\. 将安装程序移动到应用程序中：

![](https://source.icode504.com/images/image-52472d528155bec64aa9aab4c8c36fad.gif)

3\. 在启动栏找到VS Code并打开：

![](https://source.icode504.com/images/image-e1d2a65c8ea75c17a98d4e8ba03cede9.png)

# 四、Visual Studio Code（VS Code）的简单配置

## 3.1 页面汉化（可选）

VS Code默认是英文界面，对于一些英文不太好的小伙伴可能不太友好，好在官方为我们提供了VS Code的汉化包。

1\. 在左侧菜单找到插件商店：

![](https://source.icode504.com/images/image-8db8004ea105ba41de9be3e7c7165a04.png)

2\. 在搜索框中搜索`Chinese Simplified`，搜索结果第一个就是我们要安装插件，点击**Install**安装插件：

![](https://source.icode504.com/images/image-20240131170733135.png)

3\. 安装完成后，右下角会弹出一个窗口提示，点击`Change Language and Restart`，重新加载：

![](https://source.icode504.com/images/image-20240131170831058.png)

4\. 汉化成功！页面如下图所示：

![](https://source.icode504.com/images/image-09e7d5fd36a440cead40287328cf8a9f.png)

## 3.2 开启文件自动保存（可选）

在VS Code中写代码，默认是需要按<kbd>⌘</kbd>+<kbd>S</kbd>键保存文件。但是如果出现意外状况（例如电脑突然断电），你编写的代码如果没保存，绝对能搞炸你的心态。因此，我们需要开启文件自动保存功能。

1\. 点击左下角的齿轮（或者按快捷键<kbd>⌘</kbd>和<kbd>,</kbd>），进入设置：

![](https://source.icode504.com/images/image-5e4e805e711f55df96f117fb6439a96e.png)

2\. 在上方搜索框中输入`auto save`，常用设置中改为`afterDelay`：

![](https://source.icode504.com/images/image-a4d562736ecc94f7ce97aff10e9a8cec.png)

3\. 左侧菜单选择**文件**，将保存方式更改成**afterDelay**，保存时间间隔自定义（以毫秒为单位）：

![](https://source.icode504.com/images/image-fc8288ff3d9bbaf9455d6f6dae3e872e.png)

## 3.3 主题风格配置（可选）

VS Code支持多种主题风格配置。例如：暗黑风格、纯白风格等等。

> 说明：如果系统自带的风格都不符合，可以到插件商店自行下载其他风格的主题。

1\. 点击左下角的齿轮，选择主题：

![](https://source.icode504.com/images/image-a8358af60ea73f89451f0da1b930bc3c.png)

2\. 此时浏览器上方会弹出系统自带的颜色主题。2024是龙年，也是我的本命年，这里我选个红色，图个喜庆！

![](https://source.icode504.com/images/image-5fedf3568adfc2705308ad5497846200.png)

3\. 修改后的颜色风格如下图所示：

![](https://source.icode504.com/images/image-c5cdc0b3625a070d71d19cfaed4be7f8.png)

# 五、卸载Visual Studio Code（VS Code）（可选）

打开访达，点击左侧的应用程序，将Visual Studio Code安装程序移动到废纸篓即可完成卸载：

![](https://source.icode504.com/images/image-b11c13868c1330ab7036b476181ead79.gif)
