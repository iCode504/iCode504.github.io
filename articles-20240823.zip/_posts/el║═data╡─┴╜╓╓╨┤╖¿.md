---
title: el和data的两种写法
tags:
  - Vue
category_bar: true
archive: true
category:
  - Vue
  - Vue基础知识
password: 123456
abbrlink: 2118452631
date: 2024-02-11 15:42:52
description:
banner_img:
index_img:
---


# 一、el的两种写法

方式一：创建Vue实例时配置`el`属性。

```html
<div id="app">
  你好，我是{{name}}
</div>

<script>
  new Vue({
    el: "#app",     // 写在Vue实例作为属性
    data: {
      name: "iCode504"
    }
  });
</script>
```

方式二：先创建Vue实例，随后调用实例方法**vm.$mount**指定el属性值[^1]。

```html
<div id="app">
  你好，我是{{name}}
</div>

<script>
  const vm = new Vue({
    data: {
      name: "iCode504"
    }
  });
  vm.$mount("#app"); // 通过vm.$mount指定el的值，效果和写在Vue实例中
</script>
```

两种方式实现的页面效果完全相同：

![](https://source.icode504.com/images/image-20231213101942261.png)

为什么`vm.$mount`也可以指定el的值呢？

我们先以第一种方式为例，给这个实例赋值给一个变量vm并输出：

```javascript
console vm = new Vue({
  el: "#app",     // 写在Vue实例作为属性
  data: {
    name: "iCode504"
  }
});
console.log(vm);
```

从控制台中我们发现Vue实例的`$el`属性已经和`id=app`的div标签绑定了。

![](https://source.icode504.com/images/image-20231213102750156.png)

接下来再使用第二种方式对`vm`进行输出：

```javascript
const vm = new Vue({
  data: {
    name: "iCode504",
  }
});
vm.$mount("#app"); // 通过vm.$mount指定el的值
console.log(vm)
```

从控制台我们可以发现实现的效果和上面的完全相同，也是指定Vue实例中的`$el`属性的值。

![image-20231213103129684](https://source.icode504.com/images/image-20231213103129684.png)

因此使用`vm.$mount`指定`el`标签和在实例中为属性赋值达到的效果是完全相同的。

以上两种方式任选其一即可，相对而言，第二种方式更加灵活一些。假设在页面启动后，3秒再将`data`中的结果渲染到页面上，代码如下：

```javascript
const vm = new Vue({
  data: {
  	name: "iCode504",
  }
});
setTimeout(() => {
  vm.$mount("#app"); // 通过vm.$mount指定el的值            
}, 3000);
```

效果如下图所示，3秒后`{{name}}`变为Vue实例中的数据：

![231213001](https://source.icode504.com/images/231213001.gif)

# 三、data的两种写法

方式一（对象式写法，仅现阶段使用）：将data作为数据对象传入Vue实例。

```javascript
const vm = new Vue({
  el: "#app",
  data: {	// 作为数据对象传入Vue实例
    name: "iCode504",
  }
});
console.log(vm);
```

方式二（函数式写法，**后续必须使用这种方式**）：先创建Vue实例，随后以函数式赋值给`data`。

```javascript
new Vue({
  el: "#app",
  data: function () {
  	// 函数式写法
  	return {
      name: "iCode504",
  	};
  }
});
```

上述函数式写法的代码还可以简写成如下形式：

```java
new Vue({
  el: "#app",
  data () {
    // 函数式写法
    console.log(this);
    return {
      name: "iCode504",
    };
  }
});
```

3\. 由Vue管理的函数，一定不能写成箭头`=>`函数，一旦写了箭头函数，`this`就不是Vue实例了。

以data函数式为例，我们在函数中写一个`this`的输出：

```javascript
new Vue({
  el: "#app",
  data: function () {
  	console.log(this);
  	return {
  	  name: "iCode504",
  	};
  },
});
```

输出内容是Vue实例：

![](https://source.icode504.com/images/image-20231213105234100.png)

接下来，我们将原有的函数式换成使用箭头`=>`函数表达式，代码如下：

```javascript
new Vue({
el: "#app",
data: () => {
    // 函数式写法
    console.log(this);
    return {
      name: "iCode504",
    };
  }
});
```

此时输出的实例是Window对象，不是我们想要的Vue实例对象，它就失去了可以使用的意义。

![](https://source.icode504.com/images/image-20231213110217908.png)

[^1]: 本文中提到的所有`vm`是Vue实例的名称（Vue Model）。
