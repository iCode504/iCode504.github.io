---
title: qBittorrent安装教程（Windows版）
tags:
  - Windows
  - qBittorrent
  - 磁力
  - BT种子
category_bar: true
archive: false
abbrlink: 71
description: BT种子和磁力链接下载工具qBittorrent安装教程，并提供相应的演示。
banner_img: https://source.icode504.com/images/qBittorrent安装教程（Windows版）.png
index_img: https://source.icode504.com/images/qBittorrent安装教程（Windows版）.png
category:
  - 软件安装
  - Windows
  - 常用工具
date: 2024-05-29 18:42:02
password:
---


qBittorrent是一款开源、免费的BitTorrent客户端，旨在提供一个功能强大且用户友好的文件共享平台。它具有跨平台兼容性，支持Windows、macOS、Linux等操作系统。qBittorrent具备许多高级功能，如内置搜索引擎、RSS订阅、远程控制、IP过滤和带宽管理等，且没有广告。由于其简洁的界面和强大的功能，qBittorrent成为许多用户下载和管理BT种子文件的首选工具。

以下是Windows环境下qBittorrent安装及简单使用教程：

# 一、 安装前操作

以下是本文需要用到的软件，如果需要直接点击对应的链接查看安装教程即可：

| 软件名称                      | 教程链接                                           | 说明                                                         |
| :---------------------------- | :------------------------------------------------- | ------------------------------------------------------------ |
| 下载神器Neat Download Manager | [点我查看](https://www.icode504.com/posts/24.html) | 本文所需要的软件下载源在国外，使用此软件可以加快下载速度。已经安装的小伙伴请直接跳过。 |

# 二、下载qBittorrent

1\. 打开官网下载链接：[点我查看](https://sourceforge.net/projects/qbittorrent/files/)，Windows系统点击第一个文件夹`qbittorrent-win32`：

![](https://source.icode504.com/images/image-20240528153138489.png)

2\. 选择一个版本文件夹，这里我使用的4.6.5版本的文件夹：

![](https://source.icode504.com/images/image-20240528153256475.png)

3\. 点击后缀名exe文件下载：

![](https://source.icode504.com/images/image-20240528153343650.png)

# 三、安装qBittorrent

1\. 双击打开下载好的安装包，进入语言选择界面，这里按照默认选择**中文（简体）**，然后点击**OK**：

![](https://source.icode504.com/images/image-20240528153556106.png)

2\. 进入欢迎界面，点击**下一步**：

![](https://source.icode504.com/images/image-20240528153629679.png)

3\. **勾选下方的许可协议**，完成后点击**下一步**：

![](https://source.icode504.com/images/image-20240528153723081.png)

4\. 选择组件，这里建议勾选第二个创建**桌面快捷方式**，方便我们直接在桌面上直接打开qBittorrent，完成后点击**下一步**：

![](https://source.icode504.com/images/image-20240528153858093.png)

5\. 选择安装位置，这里我安装了D盘，完成后点击**安装**：

![](https://source.icode504.com/images/image-20240528154109038.png)

![](https://source.icode504.com/images/image-20240528154328982.png)

![](https://source.icode504.com/images/image-20240528154424203.png)

6\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20240528154459300.png)

7\. 安装成功，点击**完成**启动qBtorrent：

![](https://source.icode504.com/images/image-20240528154518900.png)

# 四、qBittorrent简单设置

1\. 首次打开qBittorrent会弹出一个法律声明，点击**同意**：

![](https://source.icode504.com/images/image-20240528154804473.png)

2\. 此时进入qBittorrent界面，点击上方点击**工具**，然后点击**设置**：

![](https://source.icode504.com/images/image-20240528155839881.png)

3\. 在左侧选项中点击**下载**，向下找，找到默认保存路径，点击右侧文件夹选择一个你熟悉的下载位置（推荐在C盘以外的位置）。配置完成后点击**确定**：

![](https://source.icode504.com/images/image-20240528160209055.png)

4\. 按照下图所示操作，配置文件默认保存路径：

![](https://source.icode504.com/images/image-20240528160520370.png)

# 五、qBittorrent的使用演示

## 5.1 qBittorrent下载磁力链接

1\. 这是我在某网站上找到的老版三国演义的磁力链接，复制下方链接：

```
magnet:?xt=urn:btih:afab6686072f2ff224da8bec41eb6e08026353d7&dn=%E4%B8%89%E5%9B%BD%E6%BC%94%E4%B9%89%5B%E5%85%A884%E9%9B%86%5D%5B%E5%9B%BD%E8%AF%AD%E9%85%8D%E9%9F%B3%2B%E4%B8%AD%E6%96%87%E5%AD%97%E5%B9%95%5D.The.Romance.of.Three.Kingdoms.1994.1080p.WEB-DL.H264.AAC-HotWEB
```

2\. 打开qBittorrent，点击左上角的链接图标：

![](https://source.icode504.com/images/image-20240528161358700.png)

3\. 将复制的磁力链接粘贴到此处，点击**下载**：

![](https://source.icode504.com/images/image-20240528161456328.png)

4\. 这里我勾选一个视频文件下载，点击**确定**开始下载视频文件：

![](https://source.icode504.com/images/image-20240528161832275.png)

5\. 这里qBittorrent开始下载视频文件，我们需要等待一段时间（甚至更长时间）才能下载完这个文件：

> 这里简单解释一下为什么下载速度这么慢？首先你要下载的资源的速度取决于这个资源下载的人数，如果下载人数确实很多，那么下载速度就会非常快；相反，如果是冷门资源，你的下载速度会非常慢，甚至在下载过程中没有速度。
>
> 当然，我这里解释的也比较浅，如果你想了解磁力、种子等相关知识，可以查看这篇文章：[点我查看](https://baike.baidu.com/item/%E7%A3%81%E5%8A%9B%E9%93%BE%E6%8E%A5/5867775)。

![](https://source.icode504.com/images/image-20240528163715122.png)

## 5.2 qBittorrent下载BT种子

1\. 这是我在是以哦那个老版三国演义的BT种子文件进行演示：[点我下载种子示例文件](https://source.icode504.com/images/三国演义-种子演示文件.torrent)

2\. 打开qBittorrent，点击左上角的加号图标：

![](https://source.icode504.com/images/image-20240528172251776.png)

3\. 找到第一步下载好的BT种子文件，点击右下角的**打开**：

![](https://source.icode504.com/images/image-20240528172412936.png)

4\. 这里我勾选一个视频文件下载，点击**确定**开始下载视频文件：

![](https://source.icode504.com/images/image-20240528161832275.png)

5\. 这里qBittorrent开始下载视频文件，我们需要等待一段时间（甚至更长时间）才能下载完这个文件：

![](https://source.icode504.com/images/image-20240528163715122.png)

# 六、卸载qBittorrent（可选）

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Installer，在程序列表中找到Pycharm，鼠标右键，点击卸载：

![](https://source.icode504.com/images/image-20240529090755971.png)

2\. 进入qBittorrent卸载界面，点击**下一步**：

![](https://source.icode504.com/images/image-20240529090830208.png)

3\. 点击**卸载**：

![](https://source.icode504.com/images/image-20240529090919259.png)

4\. 卸载完成，点击**关闭**：

![](https://source.icode504.com/images/image-20240529090949273.png)

5\. 此时Geek Uninstaller会清理卸载残留，点击**完成**即可：

![](https://source.icode504.com/images/image-20240529091033009.png)

6\. 点击**关闭**，qBittorrent卸载完成！

![](https://source.icode504.com/images/image-20240529091126040.png)
