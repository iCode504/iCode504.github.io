---
title: 访问Github卡顿甚至进不去的解决办法（适用于Windows）
date: 2023-12-29 14:13:02
tags: [NDM, Neat Download Manager, Watt tookit, Github]
category:
  - 软件安装
  - Windows
  - 常用工具
category_bar: true
description: 本文使用Watt Tookit（原Steam++）解决了Github在国内访问速度卡顿甚至无反应的问题，通过NDM和镜像网站实现Github大文件高速下载。
abbrlink: 25
index_img: https://source.icode504.com/images/访问Github卡顿甚至进不去的解决办法（适用于Windows和MacOS）-封面.png
banner_img: https://source.icode504.com/images/访问Github卡顿甚至进不去的解决办法（适用于Windows和MacOS）-封面.png
---

# 一、前言

Github 是全球知名的开源宝库，但是对国内用户并不友好。当我们在浏览器中输入`www.github.com`时，如果你赶的时间点比较好可能会进去，但是大多数情况下浏览器不会对你的请求做出任何响应，就像下图这样：

![](https://source.icode504.com/images/image-20231229085526297.png)

那么，有什么办法解决这个问题呢？

# 二、访问 Github——Watt Tookit（原 Steam++）

官网介绍：Watt Tookit 是一个开源的跨平台的多功能 Stream 工具箱，它可以管理你 Steam 游戏库存，监控 Steam 游戏下载进度实现自动定时关机等功能。本文要介绍的是它的网络加速功能，它内部添加了 Github 网络加速功能。

原作者在 B 站有账号，感兴趣的小伙伴可以关注支持一下：[点我传送到 B 站](https://space.bilibili.com/3546572635768935)

接下来我们就来安装一下 Watt Tookit：

1\. 点击右侧链接进入官网：[点我进入官网](https://steampp.net/)

2\. 根据自己的操作系统下载，这里我使用的是 Windows 版本，点击下载按钮：

![](https://source.icode504.com/images/image-20231229091457093.png)

3\. 此时会弹出一个 GNU 通用公共许可证协议，点击右下角**接受并下载**：

![](https://source.icode504.com/images/image-20231229091615168.png)

4\. 官方给了我们多个下载渠道，大家任选一种方式下载即可，这里我给大家标注了下载的优先级：

![](https://source.icode504.com/images/image-20231229092847673.png)

5\. 我选择的是蓝奏云下载，访问密码：1234，进入后直接下载 exe 安装包：

![](https://source.icode504.com/images/image-20231229093049336.png)

6\. 双击打开安装包，点击自定义安装，选择安装位置，这里我安装在了 D 盘：

![](https://source.icode504.com/images/image-20231229093303865.png)

![](https://source.icode504.com/images/image-20231229093315287.png)

![](https://source.icode504.com/images/image-20231229093436756.png)

![](https://source.icode504.com/images/image-20231229093446834.png)

7\. 点击**立即安装**，软件开始安装：

![](https://source.icode504.com/images/image-20231229093527419.png)

![](https://source.icode504.com/images/image-20231229093535180.png)

8\. 安装完成，点击**立即体验**：

![](https://source.icode504.com/images/image-20231229093625530.png)

9\. 打开后，点击左侧第二个图标**网站加速**，向下翻找到 Github 并勾选，

![](https://source.icode504.com/images/image-20231229093925945.png)

10\. 此时在浏览器再次访问[Github](https://www.github.com)，就可以正常显示页面了。虽然访问速度还是慢，但是总比响应超时啥也不显示的强：

![](https://source.icode504.com/images/image-20231229101555911.png)

此时我们使用`git clone`命令拉取仓库代码，或者是使用`git push`命令将代码推送到我们的 Github 仓库就不会因为网络问题而无法进行操作的问题了。

# 三、下载 Github 中的内容

Github 有很多优秀的开源作品可以下载，如果是大文件使用浏览器，等到猴年马月都下载不完（下载速度真的是太慢了），以下是使用 NDM 和 Github 加速网站下载 Github 的内容的实现步骤。

这里我想下载 Google 家的 Noto Serif 全语言字体包（[点我查看源网站](https://github.com/notofonts/noto-cjk/releases)），文件大小 600M 左右，如果正常使用浏览器下载非常慢，接下来我们就使用 NDM+Github 加速网站解决上述问题。

> 本文后续内容使用 NDM（Neat Download Manager）下载文件，如需使用此款软件的小伙伴，可以查看这篇教程：[下载神器 NDM（Neat Download Manager）安装配置教程（适用于 Windows 和 MacOS）](https://www.icode504.com/posts/24.html)

![](https://source.icode504.com/images/image-20231229102536561.png)

3\. 首先，我们对要下载的文件，鼠标右键**复制链接**：

![](https://source.icode504.com/images/image-20231229102717918.png)

4\. 以下是我整理的 Github 镜像网站，大家任选一个链接进入即可，这里我选择第一个网站进入：

| 网站名称        | 链接                      |
| --------------- | ------------------------- |
| Github 镜像站 1 | https://gitdl.cn/         |
| Github 镜像站 2 | https://moeyy.cn/gh-proxy |
| Github 镜像站 3 | https://github.zhlh6.cn/  |

5\. 将上面复制的链接粘贴到输入框中，点击下载即可

![](https://source.icode504.com/images/image-20231229103230888.png)

6\. 使用 NDM，下载速度直接原地起飞：

![](https://source.icode504.com/images/image-20231229103620649.png)
