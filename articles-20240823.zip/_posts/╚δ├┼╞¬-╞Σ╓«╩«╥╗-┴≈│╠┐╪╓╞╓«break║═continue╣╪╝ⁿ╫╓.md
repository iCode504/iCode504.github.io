---
title: 入门篇-其之十一-流程控制之break和continue关键字
date: 2023-12-20 10:18:36
tags: [Java, Intellij IDEA]
abbrlink: 23
description: 本文主要是在循环结构的基础上进一步讲解了嵌套循环、break和continue关键字，并通过三个案例加深对上述知识点的理解。
banner_img: https://source.icode504.com/images/入门篇-其之十-流程控制之循环结构.jpg
index_img: https://source.icode504.com/images/入门篇-其之十-流程控制之循环结构-封面.png
category: iCode504的Java学习空间
category_bar: true
---

> 本文中使用到的工具是Intellij IDEA和JDK 8，需要安装两款工具的请查看这两篇教程：[点我查看安装JDK8/11/17教程](http://www.icode504.com/posts/1.html)、[点我查看安装Intellij IDEA教程](http://www.icode504.com/posts/10.html)。

# 一、循环的嵌套

和前面学习`if`一样，循环也可以相互搭配嵌套，即一个循环内部还包含一个循环。在编写嵌套循环时，三种循环（`for`、`while`、`do-while`）可以相互嵌套，常见的主要是`for`嵌套和`while`嵌套，它们的格式如下所示：

1\. `for`循环嵌套：

```java
for (int i = 0; i < m; i++) {
    for (int j = 0; j < n; j++) {
        // 执行代码...
	}
}
```

2\. `while`循环嵌套：

```java
int i = 0, j = 0;
while (i < m) {
    while (j < n) {
        // 执行代码...
        j++;
    }
    i++;
}
```

嵌套循环的执行类似于时钟，时钟是秒针走一圈，分针走一格。**在嵌套循环中，内部循环执行n次，外部循环迭代一次。也就是说，嵌套循环执行的次数是`m * n`次**。

![图片来源于Hippopx](https://source.icode504.com/images/Hippopx.jpg)

# 二、循环的break关键字

前面我们学习`switch`语句时使用`break`关键字，当时这个关键字的作用有两个：

1\. 阻止`switch`语句本身的穿透性。

2\. 跳出`switch`语句。

在循环中，我们也可以使用`break`关键字，它的作用就是终止当前循环，需要搭配条件语句使用。

例如：正常输出1\~100的过程中，如果我想让循环之输出到第50个数就终止循环，就可以使用`break`关键字：

```java
/**
 * break关键字
 *
 * @author iCode504
 * @date 2023-12-16
 */
public class BreakDemo1 {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 100) {
            System.out.println(i);
            // break一般会搭配条件判断语句结合使用
            // 输出到第50个数终止当前循环
            if (i == 50) {
                break;
            }
            i++;
        }
    }
}
```

运行后程序输出到第50个数后就不再输出后续的数字，说明`while`循环已经终止。

![](https://source.icode504.com/images/image-20231216142434197.png)

# 三、continue关键字

`continue`关键字用于循环语句中，作用是**跳过当前循环，进入下一次循环**。

在循环中使用`continue`关键字时，如果满足某个条件，`continue`会结束这一轮循环，进入下一次循环。这也就意味着，如果`continue`语句在循环体中被执行，那么循环体之后的代码将不会被执行。

`continue`关键字通常用于优化程序性能防止不必要的迭代，以下是一个`continue`实例，输出`1~100`以内所有的计数：

如果使用原始的方式，我们只需要判断一下数字对2求余是否不等于0，符合这个条件判断就输出数字：

```java
/**
 * 原生方式输出1~100所有的数字
 *
 * @author iCode504
 * @date 2023-12-16
 */
public class NumberPrint {
    public static void main(String[] args) {
        for (int i = 1; i <= 100; i++) {
            if (i % 2 != 0) {
                System.out.println(i);
            }
        }
    }
}
```

当然，我们也可以使用`continue`关键字，既然输出的全是奇数，那么偶数是不符合条件的，如果是这样，就可以在条件判断中添加一个`continue`关键字：

```java
/**
 * continue关键字的使用
 *
 * @author iCode504
 * @date 2023-12-16
 */
public class ContinueDemo1 {
    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            // 如果是偶数，就停止这轮循环，进入到下一次循环中
            if (i % 2 == 0) {
                continue;
            }
            System.out.println(i);
        }
    }
}
```

二者实现运行效果完全一致：

![](https://source.icode504.com/images/image-20231216143816070.png)

需要注意的是，`continue`关键字只能用于循环语句中，并且只能跳过当前循环。如果需要在循环外跳过某些代码块语句，则可以使用其他控制语句，例如：`if-else`语句或者`switch-case`等。

# 四、使用案例

## 4.1 案例一：猜数游戏

> 由计算机生成一个两位数数字，让用户来猜。假设用户用100个游戏币，每猜一次扣10个游戏币（给出提示），猜中以后获得大奖10000个游戏币，猜大或者猜小了给出相应提示。

1\. 首先，计算机随机生成的数字，我们可以使用`java.util.Random`类可以解决，生成两位数数字我们可以利用`Random`默认的范围将其扩充为我们想要的范围：

```java
Random random = new Random();
// 生成[10, 99]区间的数字
int standardNumber = random.nextInt(90) + 10;
```

2\. 搞定了随机数的生成以后，我们需要保证用户能多次输入，需要定义一个循环，在循环外边定义一个`Scanner`，具体的输入操作放入到循环中，这样就能保证用户多次输入了。

3\. 用户只有100元，每猜一次扣10元，需要保证他的游戏币数量 > 0，每执行一次循环，扣除10游戏币，迭代表达式需要写成`游戏币 -= 10`。

4\. 如果用户成功猜中数字，完成后就让用户跳出循环即可。

5\. 猜不中（猜大或者猜小）给用户一个提示。

综合上述分析，代码如下：

```java
import java.util.Random;
import java.util.Scanner;

/**
 * 猜数游戏
 *
 * @author iCode504
 * @date 2023-12-16
 */
public class GuessNumber {
    public static void main(String[] args) {
        Random random = new Random();
        // 计算机生成的标准数字
        int standardNumber = random.nextInt(90) + 10;
        Scanner scanner = new Scanner(System.in);
        // 初始用户有100个游戏币
        int money = 100;
        while (money > 0) {
            System.out.print("请输入数字: ");
            int number = scanner.nextInt();

            // 每猜一次扣10元
            money -= 10;
            System.out.println("当前还剩" + money + "游戏币");
            if (number == standardNumber) {
                System.out.println("恭喜，中大奖了");
                money += 10000;
                break;
            } else if (number > standardNumber) {
                System.out.println("您输入的数字过大");
            } else {
                System.out.println("您输入的数字过小");
            }
        }
        System.out.println("您目前的中奖金额是" + money + "游戏币");
    }
}
```

运行结果（我猜了5次中了，如果你们猜的次数更少也可以试试）：

![](https://source.icode504.com/images/image-20231216171107741.png)

## 4.2 案例二：九九乘法表

> 输出九九乘法表，如下图所示：
>
> ![九九乘法表，图片来源于网络，侵删](https://pic.baike.soso.com/ugc/baikepic2/0/ori-20230423171344-1244803611_jpeg_1045_720_209233.jpg/800)

说起这个九九乘法表，我想起了大一的时候我参加实验室的时候考的一道算法题，当时我用了最蠢笨的方法——一行一行将整个乘法表用C语言的`printf`输出的，直到后来我接触了循环方面的知识，我才知道那时候一行一行写有多愚蠢。

(˚ ˃̣̣̥᷄⌓˂̣̣̥᷅ )(˚ ˃̣̣̥᷄⌓˂̣̣̥᷅ )(˚ ˃̣̣̥᷄⌓˂̣̣̥᷅ )(˚ ˃̣̣̥᷄⌓˂̣̣̥᷅ )

言归正传，我们分析：

1\. 首先，乘法表一共有9行，需要循环9次。可以确定的循环范围是$[1,9]$

2\. 我们截取一个乘法表的片段，发现同一行中，第一个乘数是变化的，第二个乘数是不变的。

![](https://source.icode504.com/images/image-20231216153832641.png)

3\. 如果使用嵌套循环，外层控制行数。也就是说，同一行内部的第二个乘数可以作为外层循环的迭代变量。内层循环控制第一个乘数，在同一行内，第一个乘数是变化的。

4\. 再次观察这个乘法表，我们会发现：$第一个乘数 <= 第二个乘数$，这个可以作为循环的内部条件，防止生成另一半循环。

至此，我们就可以编写一个九九乘法表了，代码如下：

```java
/**
 * 嵌套循环输出九九乘法表
 *
 * @author iCode504
 * @date 2023-12-16
 */
public class MultiplicationTable {
    public static void main(String[] args) {
        // 外层循环控制行数（第二个乘数）
        for (int i = 1; i <= 9; i++) {
            // 内层循环控制第一个乘数的输出
            for (int j = 1; j <= 9; j++) {
                if (j <= i) {
                    System.out.println(j + " * " + i + " = " + j * i);
                }
            }
            System.out.println();
        }
    }
}
```

运行结果如下：

![](https://source.icode504.com/images/image-20231216160006119.png)

虽然得到的结果是正确的，但是样式并不符合九九乘法表的样子，我们只需要使用制表符`\t`和不换行输出的`System.out.print();`做一下处理即可：

```java
/**
 * 嵌套循环输出九九乘法表
 *
 * @author iCode504
 * @date 2023-12-16
 */
public class MultiplicationTable {
    public static void main(String[] args) {
        // 外层循环控制行数（第二个乘数）
        for (int i = 1; i <= 9; i++) {
            // 内层循环控制第一个乘数的输出
            for (int j = 1; j <= 9; j++) {
                // 要求第一个乘数 <= 第二个乘数
                if (j <= i) {
                    // 使用不换行输出和制表符对输出结果进行美化
                    System.out.print(j + " * " + i + " = " + j * i + "\t");
                }
            }
            // 每一行输出完成后，需要换行
            System.out.println();
        }
    }
}
```

运行结果如下，符合我们的预期：

![](https://source.icode504.com/images/image-20231216160237255.png)

乘法表中$第一个乘数 <= 第二个乘数$，我们可以将这个条件写到内层的`for`作为条件表达式，优化后代码如下：

```java
/**
 * 嵌套循环输出九九乘法表
 *
 * @author iCode504
 * @date 2023-12-16
 */
public class MultiplicationTable {
    public static void main(String[] args) {
        // 外层循环控制行数（第二个乘数）
        for (int i = 1; i <= 9; i++) {
            // 内层循环控制第一个乘数的输出
            // 要求第一个乘数 <= 第二个乘数
            for (int j = 1; j <= i; j++) {
                // 使用不换行输出和制表符对输出结果进行美化
                System.out.print(j + " * " + i + " = " + j * i + "\t");
            }
            // 每一行输出完成后，需要换行
            System.out.println();
        }
    }
}
```

运行结果和前面的一摸一样：

![](https://source.icode504.com/images/image-20231216160237255.png)

在这个优化版本中，我修改了内层循环的条件，使其只循环到`i`的值（第二个乘数），而不是9，这样可以减少循环的次数。

## 4.3 案例三：素数问题

> 素数，也被称为质数，是指在自然数系中除了1和它自身以外，无法被其他自然数整除的数。最小的素数是2，它也是素数中唯一的偶数（双数）。其他素数都是奇数（单数）。素数有无限多个，所以不存在最大的素数。
>
> 输出100以内的所有素数。
>

1\. 确认范围：

- 要输出的素数的范围在100以内，最小的素数是2，可以确定被除数`i`要循环的范围是$[2, 100]$。
- 由于素数只能被由于素数只能被1和其自身整除，那么在不包含上述条件的情况下，我们初步可以将除数`j`的范围确定为$[2,i-1]$

2\. 如果除数`j`所在范围内，存在某一个数可以被当前数整除，那么这个数就不是素数。

代码初步实现如下所示：

```java
/**
 * 输出100以内的素数
 *
 * @author iCode504
 * @date 2023-12-18
 */
public class PrimeNumber {
    public static void main(String[] args) {

        // 由于2是最小的素数，因此被除数i的循环范围从2开始
        for (int i = 2; i < 100; i++) {
            // 创建一个flag，默认是true，即当前数字确实是素数
            boolean flag = true;

            // 要想判定当前数i是否是素数，只需要保证j在[2, i-1]的范围内
            for (int j = 2; j < i; j++) {
                // 在上述区间内如果确实存在能被i整除的数，那么这个数就不是素数，就将flag设置为false
                if (i % j == 0) {
                    flag = false;
                    break;
                }
            }

            // 对于符合条件的flag，即素数，进行输出
            if (flag) {
                System.out.print(i + "\t");
            }
        }
    }
}
```

输出结果也符合我们的预期：

![](https://source.icode504.com/images/image-20231219084130368.png)

但是，对于每一个素数而言，我们有必要将除数的范围设置到`j - 1`吗？并不是，这里我举个例子：

48不是素数，除了1和它自身以外，能被48整除的最大数字是$48\div2=24$。而超过24以后，就不存在能被48整除的整数。

我们可以按照上述分析，对内层循环代码做进一步简化，内层循环的范围修改为$[2, j/2]$，代码如下所示：

```java
/**
 * 输出100以内的素数--优化
 *
 * @author iCode504
 * @date 2023-12-19
 */
public class PrimeNumber2 {
    public static void main(String[] args) {
        // 由于2是最小的素数，因此循环范围从2开始
        for (int i = 2; i < 100; i++) {
            // 创建一个flag，默认是true
            boolean flag = true;

            // 要想判定当前数i是否是素数，只需要保证[2, i/2]区间内是否存在可以被整除的数字j
            for (int j = 2; j <= i / 2; j++) {
                // 在这个区间如果确实存在能被i整除的数，那么这个数就不是素数，就将flag设置为false
                if (i % j == 0) {
                    flag = false;
                    break;
                }
            }

            // 对于符合条件的flag，即素数，进行输出
            if (flag) {
                System.out.print(i + "\t");
            }
        }
    }
}
```

输出效果和上面完全相同，但是内层循环的次数减少了一半，循环的执行效率进一步提高：

![](https://source.icode504.com/images/image-20231219085614559.png)

针对内层循环而言，这个程序还有进一步优化的空间。除数的范围只需要计算到被除数的平方根即可，为什么？

判断一个数是否是素数的重要前提就是：除数不能被1和它自身整除。如果一个数不是素数，那么它必定可以分解成两个数（1和它本身除外）的乘积，并且这个数的因子一定会在它的平方根之前出现。

同理，如果一个数如果是素数，即使到这个数的平方根之前也不可能存在能整除这个素数的数。因此，内层循环我们可以将`j`的范围改为`(int) Math.sqrt(i)`（数字的平方根求整）即可：

```java
/**
 * 输出100以内的素数（简化版）
 *
 * @author iCode504
 * @date 2023-12-19
 */
public class PrimeNumber3 {
    public static void main(String[] args) {
        // 由于2是最小的素数，因此循环范围从2开始
        for (int i = 2; i < 100; i++) {
            // 创建一个flag，默认是true
            boolean flag = true;

            // 要想判定当前数i是否是素数，只需要保证[2, Math.sqrt(i)]区间内是否存在可以被整除的数字j
            for (int j = 2; j <= (int) Math.sqrt(i); j++) {
                // 在这个区间如果确实存在能被i整除的数，那么这个数就不是素数，就将flag设置为false
                if (i % j == 0) {
                    flag = false;
                    break;
                }
            }

            // 对于符合条件的flag，即素数，进行输出
            if (flag) {
                System.out.print(i + "\t");
            }
        }
    }
}
```

输出结果和前面的一模一样，循环的次数进一步减少，提高了代码的运行效率。

![](https://source.icode504.com/images/image-20231219085614559.png)

# 五、知识点总结

流程控制之循环结构知识点总结如下图所示：

如需高清大图，请点击右侧链接下载：[点我下载](https://icode504.lanzouw.com/iNjWB1ie8l3g)

![流程控制之循环结构-总结](https://source.icode504.com/images/%E6%B5%81%E7%A8%8B%E6%8E%A7%E5%88%B6%E4%B9%8B%E5%BE%AA%E7%8E%AF%E7%BB%93%E6%9E%84.svg)

