---
title: 第一章 若依-JFlow配置与启动
date: 2023-12-11 09:08:05
tags: [若依, JFlow, Java, MySQL, Intellij IDEA, 开源, Git, Maven]
category: [工作流框架, JFlow]
description: 若依是一款开源的后端管理框架，JFlow是一款经典的纯国产的工作流引擎，若依-JFlow是前两者的完美结合。本文主要介绍了Ruoyi-JFlow框架代码的拉取、配置与启动
abbrlink: 15
category_bar: true
---

若依（Ruoyi）一款开源的后台管理admin框架，JFlow 是一款经典的纯国产全开源的工作流引擎，该版本是两者的完美结合。

RuoYi是一个后台管理系统，基于经典技术组合（Spring Boot、Apache Shiro、MyBatis、Thymeleaf）主要目的让开发者注重专注业务，降低技术难度，从而节省人力成本，缩短项目周期，提高软件安全质量。

JFlow是由济南驰骋团队负责研发，开发语言主要是Java，是一款开源软件，工作流引擎操作简单，概念通俗易懂，操作手册完善（计:14万字操作手册说明书），代码注释完整，案例丰富翔实，单元测试完整，符合国内多种场景的需要。

以下是二者的官网：[若依官网](https://ruoyi.vip/)，[驰骋官网](http://ccflow.org/)

# 一、安装准备

需要安装如下软件：

| 软件名称      | 安装教程                                                     |
| ------------- | ------------------------------------------------------------ |
| Java          | [点我查看](http://www.icode504.com/posts/1.html)             |
| MySQL         | [点我查看](http://www.icode504.com/posts/18.html) |
| Intellij IDEA | [点我查看](http://www.icode504.com/posts/10.html)            |
| Navicat       | [点我查看](https://www.jianshu.com/p/4bb2e2bfb449)           |
| Maven         | [点我查看](https://blog.csdn.net/m0_72248235/article/details/130589912?spm=1001.2014.3001.5501) |
| Git           | [点我查看](https://blog.csdn.net/u012124199/article/details/114004087) |

# 二、若依-JFlow代码下载

1\. 找到一个合适文件夹，鼠标右键，点击`Git Bash Here`，此时会进入Git命令行窗口：

![](https://source.icode504.com/images/image-20231201104451452.png)

2\. 复制下面的内容到Git命令行并回车：

```shell
git clone https://gitee.com/opencc/RuoYi-JFlow.git
```

> 说明：如果你在gitee中添加了SSH KEY，也可以直接复制下面的内容到Git命令行中
>
> ```shell
> git clone git@gitee.com:opencc/RuoYi-JFlow.git
> ```

3\. Git中如果出现如下提示及说明代码克隆完成：

![](https://source.icode504.com/images/image-20231201105147112.png)

# 三、导入项目

1\. 使用Intellij IDEA打开这个文件夹：

![](https://source.icode504.com/images/image-20231201105456043.png)

2\. 打开`Settings`，按照下图所示配置Maven

![](https://source.icode504.com/images/image-20231201105802938.png)

3\. 下载依赖需要一段时间，请耐心等待。

4\. 在左侧项目目录，选中`sql`文件，按<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>C</kbd>，复制文件路径

![](https://source.icode504.com/images/image-20231201110144811.png)

5\. 打开Navicat，如果你没有和本地MySQL连接的话，就点击左上角的连接，选择MySQL

![](https://source.icode504.com/images/image-20231201110329123.png)

6\. 连接名自定义或者不填，用户名填写root，密码即root用户的密码，填写完成后点击确定

![](https://source.icode504.com/images/image-20231201110541430.png)

7\. 鼠标右键点击新建数据库

![](https://source.icode504.com/images/image-20231201110738537.png)

8\. 数据库名称自定义，这里我命名为`ruoyi_jflow`，字符集选择`utf8mb4`即可，排序规则选择`utf8mb4_0900_ai_ci`即可，然后点击**确定**。

![](https://source.icode504.com/images/image-20231201111256799.png)

9\. 鼠标右键点击数据库，点击**运行SQL文件**：

![](https://source.icode504.com/images/image-20231201111742572.png)

10\. 按照下图所示导入SQL：

![](https://source.icode504.com/images/image-20231201111908315.png)

![](https://source.icode504.com/images/image-20231201111954377.png)

![](https://source.icode504.com/images/image-20231201112052134.png)

![](https://source.icode504.com/images/image-20231201112138717.png)

11\. 导入SQL中，请耐心等待：

![](https://source.icode504.com/images/image-20231201112248515.png)

12\. 导入完成，点击关闭：

![](https://source.icode504.com/images/image-20231201112320508.png)

13\. 刷新一下数据库，一共由242张表

![](https://source.icode504.com/images/image-20231201162802611.png)

12\. 双击打开IDEA项目中的`application-druid2.yml`文件

![](https://source.icode504.com/images/image-20231201113749133.png)

13\. 修改数据库配置

![](https://source.icode504.com/images/image-20231201115235424.png)

14\. 将`application-druid2.yml`文件改为`application-druid.yml`

![](https://source.icode504.com/images/image-20231201115432241.png)

![](https://source.icode504.com/images/image-20231201115332224.png)

14\. 点击文件左上角`File -> Project Stucture`，确保版本是JDK 8：

![](https://source.icode504.com/images/image-20231201114408428.png)

15\. Redis配置：需要确保你在本地安装Redis，如果没有安装包，点击右侧链接下载：[点我下载](https://icode504.lanzouw.com/irWZP1ghutla)

- 找一个你熟悉的位置，创建一个文件夹，命名为Redis

- 将下载的压缩包解压到这个文件夹中

![](https://source.icode504.com/images/image-20231201150102280.png)

- 在上方文件路径中输入`cmd`并回车，进入命令行
- 在命令行中输入如下指令

```shell
redis-server --service-install redis.windows-service.conf
```

![](https://source.icode504.com/images/image-20231201150335394.png)

- 此时按<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>Esc</kbd>，打开任务管理器，点击服务，在下方找到Redis说明软件配置成功：

![](https://source.icode504.com/images/image-20231201151105294.png)

16\. 打开项目中`application.yml`，这里关于Redis的配置信息不用修改，因为上面我们已经成功启动了本地Redis服务了：

![](https://source.icode504.com/images/image-20231201151340895.png)

# 四、启动项目

1\. 项目启动：点击右上角Debug调试启动，如果出现下面内容，就说明后端项目启动成功

![](https://source.icode504.com/images/image-20231201150836073.png)

> 说明：如果后端项目起不来，报错信息是8089端口被占用（如下图）
>
> ![](https://source.icode504.com/images/image-20231201141026025.png)
>
> 解决办法：打开项目中的`application.yml`，找到`server.port`，将端口号修改成你知道的即可，这里我改成8090：
>
> ![](https://source.icode504.com/images/image-20231201141214554.png)
>
> 重启一下项目即可。

2\. 打开浏览器，在上方输入地址：[点我进入](http://localhost:8089/ry-jflow/login)，进入登录页面：

账号名：admin，密码：admin123

![](https://source.icode504.com/images/image-20231201150919953.png)

3\. 登录成功：

![](https://source.icode504.com/images/image-20231201150939145.png)


