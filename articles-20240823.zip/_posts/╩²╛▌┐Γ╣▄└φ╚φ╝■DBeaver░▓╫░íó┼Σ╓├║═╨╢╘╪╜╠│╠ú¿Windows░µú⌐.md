---
abbrlink: '77'
archive: false
banner_img: https://source.icode504.com/images/数据库管理软件DBeaver安装、配置和卸载教程（Windows版）.png
categories:
- 软件安装
- Windows
- DBeaver
category_bar: true
date: '2024-07-13T19:46:30+08:00'
description: 本文介绍了数据库管理软件DBeaver在Windows系统上的安装、配置和卸载步骤。详细说明了下载DBeaver安装包，进行安装配置数据库连接的过程，以及如何卸载DBeaver，帮助用户轻松管理和使用数据库。
index_img: https://source.icode504.com/images/数据库管理软件DBeaver安装、配置和卸载教程（Windows版）.png
password: 
tags:
- Windows
- DBeaver
title: 数据库管理软件DBeaver安装、配置和卸载教程（Windows版）
updated: '2024-07-13T20:24:59.039+08:00'
---
DBeaver是一款通用的数据库管理工具和SQL客户端，适用于开发人员和数据库管理员。它支持多种关系数据库和NoSQL数据库，提供直观的用户界面、高级SQL编辑器、数据可视化工具和数据迁移功能，跨平台运行并支持插件扩展，是管理和分析数据库的强大利器。

以下是Windows环境下DBeaver安装教程：

# 一、安装前操作

推荐电脑上安装的软件：


| 软件名称                      | 教程链接                                           | 说明                                                                                                               |
| ----------------------------- | -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| MySQL                         | [点我查看](https://www.icode504.com/posts/18.html) | 在Windows本地安装MySQL教程，已安装的小伙伴请忽略。                                                                 |
| 下载神器Neat Download Manager | [点我查看](https://www.icode504.com/posts/24.html) | 本文所需要的软件下载源在国外，使用此软件可以加快下载速度。已经安装的小伙伴请直接跳过。                             |
| Github加速访问软件Watt Tookit | [点我查看](https://www.icode504.com/posts/25.html) | 本文需要下载的软件在Github上，目前国内访问Github访问速度较慢，推荐大家看一下本文教程，可以模仿文中的方式下载安装包 |

# 二、下载DBeaver

1\. 点击右侧连接打开DBeaver官网：[点我查看](https://github.com/dbeaver/dbeaver/releases)

> 注意：请确保已经打开了Watt Tookit的Github加速（教程请跳转到第一部分去查看）。加载速度可能会较慢，请耐心等待！

2\. 这里我下载的是最新版的24.1.2（截止至2024年7月13日发布的最新版本），向下找到Assets并展开即可看到各个操作系统对应的安装包：

![](https://source.icode504.com/images/image-20240713135720470.png)

3\. 找到exe结尾的安装包，鼠标右键，复制链接地址：

![](https://source.icode504.com/images/image-20240713135852009.png)

4\. 点击右侧链接打开Github加速站：[点我查看](https://moeyy.cn/gh-proxy)

> 说明：如果这个加速网站失效，请到第一部分的Github加速教程中寻找可加速的网站地址！

5\. 将前面复制的链接地址粘贴到此处，点击**下载**：

![](https://source.icode504.com/images/image-20240713140225258.png)

6\. 下载中，请耐心等待：

![](https://source.icode504.com/images/image-20240713140322465.png)

# 三、安装DBeaver

1\. 打开前面下载好的安装包，此时会弹出一个语言选择窗口，按照默认选择**中文（简体）**即可，然后点击**OK**：

![](https://source.icode504.com/images/image-20240713140522081.png)

2\. 进入欢迎页面，点击**下一步**：

![](https://source.icode504.com/images/image-20240713140629386.png)

3\. 许可证协议界面，点击**我接受**：

![](https://source.icode504.com/images/image-20240713140721087.png)

4\. 选择为那些用户安装DBeaver，这里我选择第一个**For anyone who uses this computer (all users)**（为本机所有用户安装），然后点击**下一步**（需要管理员权限）：

![](https://source.icode504.com/images/image-20240713140918366.png)

5\. 此时会再次选择语言，按照第一步选择中文（简体），然后点击**OK**：

![](https://source.icode504.com/images/image-20240713141158997.png)

6\. 进入欢迎页面，点击**下一步**：

![](https://source.icode504.com/images/image-20240713140629386.png)

7\. 进入许可证协议界面后点击**我接受**：

![](https://source.icode504.com/images/image-20240713140721087.png)

8\. 选择要安装的组件：如果你不熟悉里面的组件的作用，就按照系统默认即可，然后点击**下一步**：

![](https://source.icode504.com/images/image-20240713141654132.png)

9\. 选择安装位置，这里我安装在了D盘（推荐是全英文目录，避免出现不必要的麻烦）：

![](https://source.icode504.com/images/image-20240713141909875.png)

![](https://source.icode504.com/images/image-20240713142216382.png)

![](https://source.icode504.com/images/image-20240713142342949.png)

10\. 点击**安装**：

![](https://source.icode504.com/images/image-20240713142432104.png)

11\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20240713142517716.png)

12\. 安装完成，勾选**Create Desktop shortcut**即可在桌面上创建桌面快捷方式，点击**完成**，DBeaver安装完成：

![](https://source.icode504.com/images/image-20240713142923438.png)

# 四、连接数据库

1\. 在桌面上找到DBeaver，双击打开：

![](https://source.icode504.com/images/image-20240713143436878.png)

2\. 此时会弹出一个创建样本数据库的提示，这里选择**否**：

![](https://source.icode504.com/images/image-20240713143614282.png)

3\. 此时会弹出一个连接数据库界面，在上方的搜索框中输入你要连接的关系型数据库，这里我要连接MySQL数据库。选中第一个MySQL，点击**下一步**：

![](https://source.icode504.com/images/image-20240713144145836.png)

4\. 按照下图所示配置数据库连接：

![](https://source.icode504.com/images/image-20240713145311611.png)

5\. 初次点击左下角的测试连接，会下载MySQL JDBC驱动文件，请耐心等待：

![](https://source.icode504.com/images/image-20240713144440746.png)

6\. 下载完成后，再次点击左下角的测试连接，如果出现下图的弹窗，就说明MySQL数据库连接成功！点击确认即可：

![](https://source.icode504.com/images/image-20240713145507350.png)

7\. 点击右下角的完成，数据库成功连接：

![](https://source.icode504.com/images/image-20240713145557976.png)

8\. 接下来我们就可以正常使用MySQL数据库了：

![](https://source.icode504.com/images/image-20240713145928196.png)

# 五、卸载DBeaver（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{% endnote %}

> 注意：本文使用到 Geek Uninstaller 卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Uninstaller，找到DBeaver，**鼠标右键**点击**卸载**：

![](https://source.icode504.com/images/image-20240713151956348.png)

2\. 点击**卸载**：

![](https://source.icode504.com/images/image-20240713152040318.png)

3\. 卸载中，请耐心等待：

![](https://source.icode504.com/images/image-20240713152105862.png)

4\. 卸载完成，点击**关闭**：

![](https://source.icode504.com/images/image-20240713152140401.png)

5\. 此时Geek Uninstaller会检查卸载残留，如果没有卸载残留，点击**关闭**即可：

![](https://source.icode504.com/images/image-20240713152250626.png)
