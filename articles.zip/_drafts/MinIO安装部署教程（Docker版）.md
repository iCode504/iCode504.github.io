---
title: MinIO安装部署教程（Docker版）
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

y

# 一、安装前准备

1\. 请确保你的电脑是Linux操作系统，需要安装的小伙伴，可以根据自己的实际需要点击任意一个连接查看安装教程：

| 操作系统名称 | 教程             |
| ------------ | ---------------- |
| CentOS       | 点我查看         |
| Ubuntu       | 点我查看         |
| Debian       | 点我查看         |
| 雨云服务器   | 撰写中，敬请期待 |

已经安装的小伙伴，请在命令执行如下命令即可查看当前操作系统的信息，这里我的是64位Debian操作系统：

```bash
uname -a
```

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630180304863.png)

2\. 我们还需要安装Docker，根据上面所检查操作系统进行安装，以下是操作系统对应的Docker安装教程：

| Docker安装教程（请根据上述操作系统名称选择查看教程） | 教程                                               |
| ---------------------------------------------------- | -------------------------------------------------- |
| Docker（CentOS版）                                   | [点我查看](https://www.icode504.com/posts/70.html) |
| Docker（Ubuntu/Debian版）                            | [点我查看](https://www.icode504.com/posts/75.html) |

3\. 如果你已经按照上述教程安装Docker，执行如下命令即可查看Docker是否安装：

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630183534461.png)

# 二、安装并启动MinIO容器

1\. 在命令行界面，在root目录下创建一个`/minio/data`文件夹，执行如下命令：

```bash
mkdir -p /minio/data
```

2\. 执行如下命令即可创建并启动MinIO容器：

-   命令行中的用户名MINIO_ROOT_USER可以自定义，长度至少3位。
-   密码MINIO_ROOT_PASSWORD对应的值可自定义，长度至少8位。

这里我设置用户名为admin，密码是12345678

```bash
docker run \
   -id \
   -p 9000:9000 \
   -p 9001:9001 \
   --name minio \
   -v ~/minio/data:/data \
   -e "MINIO_ROOT_USER=admin" \
   -e "MINIO_ROOT_PASSWORD=12345" \
   quay.io/minio/minio server /data --console-address ":9001"
```

3\. 执行如下命令，就可以看到MinIO正在运行：

```bash
docker ps -a
```

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630185854934.png)

4\. 执行如下命令即可查看当前主机的IP地址：

```bash
ip addr
```

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630190106675.png)

5\. 打开浏览器，在上方搜索框输入**IP地址:9001**，即可打开MinIO控制台页面：

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630190527143.png)

6\. 进入控制台界面，我们点击左侧的**Buckets**，然后点击右上角的**Create Bucket**就可以创建一个存储桶了：

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630191043765.png)

7\. 在创建存储桶界面中，桶名称可以自定义，建议是英文名称，然后点击右下角的Create Bucket即可完成创建：

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630191241375.png)

8\. 点击进入新创建的存储桶：

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630191556657.png)

9\. 进入存储桶配置界面，我们需要先设置一下资源访问策略，这里我设置的访问策略是**public**：

>   访问策略一共有三种：private（私有的）、public（所有人都可以访问）、custom（自定义策略）

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630192043007.png)

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630192010838.png)

10\. 接下来我们点击右上角的文件夹图标，上传一个文件：

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630192145033.png)

11\. 进入文件管理页面，点击Upload即可上传本地文件，这里我为了方便展示效果，我上传了一张图片：

![](F:\Code\icode504_blog_front\source\_drafts\assets\image-20240630192336192.png)
