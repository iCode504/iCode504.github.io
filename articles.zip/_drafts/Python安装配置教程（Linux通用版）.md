---
title: Python 3安装配置教程（Linux通用版）
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

Python 是一种高级编程语言，于 1991 年第一次公开发布。Python 的设计哲学强调代码的可读性和简洁的语法（尤其是使用空格缩进划分代码块），这使得 Python 成为初学者和专家都喜欢的语言。

以下是 Python 的一些主要特点：

1.  **易于学习**：Python 是一种解释型语言，语法简洁明了，代码结构清晰，易于上手。
2.  **跨平台**：Python 是跨平台的，可以在多种操作系统上运行，包括 Windows、Linux、macOS 等。
3.  **免费和开源**：Python 是开源的，任何人都可以获取源代码并修改。它也有一个庞大的社区和丰富的第三方库，这些库覆盖了各种任务，从 Web 开发到科学计算。
4.  **动态类型**：Python 是动态类型的语言，这意味着你不需要在声明变量时指定其类型，Python 会在运行时确定类型。
5.  **面向对象**：Python 支持面向对象编程，包括类和继承。
6.  **强大的库**：Python 标准库包含了许多常用的功能，如文件处理、网络编程、数据库接口、图形界面开发、科学计算等。此外，还有大量的第三方库，如 NumPy、Pandas、Matplotlib 用于数据处理和可视化，Django、Flask 用于 Web 开发，以及 TensorFlow、PyTorch 用于机器学习。
7.  **可扩展性**：Python 可以调用 C、C++ 等语言的代码，也可以将 Python 代码编译成 C 扩展模块，从而提高执行效率。
8.  **脚本编写**：Python 常被用于编写脚本，自动化日常任务，如文件处理、数据转换等。
9.  **科学计算和数据分析**：Python 在科学计算和数据分析领域非常受欢迎，特别是在数据科学、机器学习和人工智能领域。
10.  **Web 开发**：Python 有多个 Web 框架，如 Django 和 Flask，使得 Python 成为 Web 开发的流行选择。

以下是Linux环境下Python的安装教程：

# 一、安装前操作

1\. 这里建议登录`root`用户执行命令。

2\. 建议操作系统上安装Vim编辑器，方便后续我们在Linux端写Python代码：

- Ubuntu/Debian

```bash
apt-get -y install vim
```

- CentOS

```bash
yum -y install vim gcc-c++
```

# 二、Ubuntu/Debian安装Python3

1\. Ubuntu/Debian在安装操作系统中就已经默认安装了Python3。如果你不确定自己电脑上是否安装了Python，可以执行如下操作命令来安装：

```bash
apt-get -y install python3
```

2\. 执行如下命令检查Python3是否安装成功，执行如下命令：

```bash
python3 --version
```

如果出现如下提示信息，就说明Python3成功安装到了Linux上：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240411085409248.png)

# 三、CentOS安装Python3

1\. 打开Python官网下载页：[点我查看](https://www.python.org/downloads/source/)，加载速度可能会较慢，请耐心等待。

2\. 在左侧找到Stable Releases（稳定发布版），选择一个你想要下载的Python3的版本，点击**Gzipped source tarball**下载安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240514095603623.png)

3\. 将前面下载好的JDK安装包使用SFTP工具（这里我使用的是Eleterm）由Windows端传输到Linux端（请先确保Windows本身已经通过SSH方式连接到Linux）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224172925751.png)

4\. 在左侧Windows端找到下载好的安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240514101854490.png)

5\. 在右侧Linux端设置安装包存放路径，这里我将安装包存放在`/opt`下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224173503187.png)

6\. 按照下图所示操作，将Python安装包传到Linux端的`/opt`目录下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/240514001.gif)

7\. 等待一段时间后，此时Linux端的`/opt`目录下已经存放了刚才我们传输的文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240514102330825.png)

8\. 此时我们切换回命令行，执行如下命令切换到`/opt`目录下：

```bash
cd /opt
```

9\. 解压刚刚传入过来的安装包，执行如下命令：

```bash
tar zxvf Python-3.12.3.tgz
```

> 小技巧：在命令行中输入文件名时，我们可以只写文件的前一部分，然后按一下<kbd>Tab</kbd>键补齐文件名。

10\. 等待一段时间后，解压完成，执行如下命令，进入解压后的文件夹名称：

```bash
ls
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240514102758467.png)

```bash
cd Python-3.12.3
```

11\. 分别执行如下命令，开始安装配置Python（安装时间比较长，请耐心等待）：

```bash
./configure
make
make install
```

