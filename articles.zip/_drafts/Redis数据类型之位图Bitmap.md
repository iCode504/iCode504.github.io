---
abbrlink: '103'
banner_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
categories: []
date: '2024-08-20T00:03:14.040688+08:00'
description: Redis位图类型介绍和相关命令
index_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
order: '90'
tags:
- Redis
title: Redis数据类型之位图Bitmap
updated: '2024-08-20T17:47:53.480+08:00'
---
# 一、Redis位图（Bitmap）介绍

在正式讲解位图的概念之前，我们先来简单介绍一下位图中“位”是什么。

位（Bit，也称作比特）是计算机存储信息的最小单位，每一个位由二进制数字0或1组成。

计算机存储的最小单位是字节（Byte），字节和位之间的换算关系：

$$
1byte = 8bit
$$

位图是由多个0或1的二进制位组成的数组。也就是说，每一个二进制位是位图的组成单位。

严格意义上讲，位图并不能算上Redis的数据类型，因为它本质上仍然是字符串（String）。

应用场景：

- 钉钉统计上下班打卡：
- 签到领积分：

# 二、Redis位图（Bitmap）相关命令

1\. 给指定的key第offset位赋值为value：

```bash
SETBIT key offset value
```

2\. 获取当前key第offset位的值：

```bash
GETBIT key offset
```

3\. 获取当前key在某个offset区间中值为1的数量：

```bash
BITCOUNT key [start end [BYTE | BIT]]
```

4\. 对不同的二进制存储数据进行位运算（AND/OR/NOT/XOR）：

```bash
BITOP <AND | OR | NOT | XOR> destkey key
```
