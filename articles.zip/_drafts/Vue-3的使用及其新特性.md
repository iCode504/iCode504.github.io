---
title: Vue 3的使用及其新特性
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

# 一、创建Vue 3.0工程

## 方式一：使用vue-cli创建

1\. 查看`@vue/cli`版本，确保`@vue/cli`版本在4.5.0以上。

```shell
vue --version
```

2\. 安装或者升级你的`@vue-cli`

```shell
npm install -g @vue/cli
```

3\. 创建Vue项目，语言选择Vue 3

```shell
vue create vue_test
```

4\. 启动当前模块

```shell
cd vue_test
npm run serve
```

## 方式二：使用vite创建

vite是新一代前端构建工具。

官方文档：https://v3.cn.vuejs.org/guide/installation.html/#vite

vite官网：https://vitejs.cn

vite的优势：

-   开发环境中，无需打包操作，可以快速地冷启动。
-   轻量快速的热重载。
-   真正地按需编译，不再等待整个应用编译完成。

传统构建与vite构建对比图：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240331213858582.png)

创建工程：

```shell
npm init vite-app <project-name>
```

进入工程目录：

```shell
cd <project-name>
```

安装依赖：

```shell
npm install
```

运行工程：

```shell
npm run dev
```

# 二、Composition API

## 2.1 setup钩子函数

1\. 理解：Vue3.0中的一个全新配置项，值是一个函数。

2\. setup时所有**Composition API（组合API）**“表演的舞台”。

3\. 组件中所用到的：数据、方法等等，均需要配置咋setup中。

4\. setup函数的两种返回值：

- 若返回一个对象，则对象中的属性、方法，在模板中均可以直接使用（重点关注！）。
- 若返回一个渲染函数：则可以自定义渲染内容（了解即可）。

5\. 尽量不要和Vue2.x配置混用

- Vue2.x配置（data、methods、computed...）中可以访问到setup中的属性和方法。
- 在setup中不能访问到Vue2.x配置（data、methods、computed...）。
- 如果存在重名现象，setup中的内容优先访问。

6\. setup不能是一个async函数，因为返回值不再是return的对象，而是promise，模板看不到return对象中的属性。（后期也可以返回一个promise实例，但需要Suspense和异步组件的配合）

## 2.2 ref函数

1\. 作用：定义一个响应式的数据。

2\. 语法：

```js
const xxx = ref(initValue);
```

- 创建一个包含响应式数据的引用对象**（reference对象，简称ref对象）**。
- JS中操作数据：`xxx.value`
- 模板中读取数据：不需要`.value`，直接使用：`<div>{{xxx}}</div>`

3\. 备注：

- 接收的数据可以是：基本类型、也可以是对象类型。
- 基本类型的数据：响应式依然是靠`Object.defineProperty()`的`get`与`set`完成的。
- 对象类型的数据：内部“求助”了Vue3.0中的一个新函数——`reactive`函数。

## 2.3 reactive函数

1\. 作用：定义一个对象类型的响应式数据（基本类型不要用它，要用`ref`函数）

2\. 语法：

```js
const 代理对象 = reactive(源对象);
```

接受一个对象或数据，返回一个代理对象（proxy对象）

3\. reactive定义的响应式数据是“深层次的”。

4\. 内部基于ES6的Proxy实现，通过代理对象操作数据源对象内部数据进行操作。

## 2.4 Vue3.0中响应式原理

1\. Vue2.x的响应式实现原理：

-   对象类型：通过`Object.defineProperty()`属性的读取、修改进行拦截（数据劫持）。
-   数组类型：通过重写更新数组的一系列方法实现拦截。（对数组的变更方法进行了包裹）。

```js
Object.defineProperty(data, 'count', {
  get () {...},
  set () {...}
})
```

2\. Vue2存在的问题：

-   新增属性、删除属性，界面不会更新。
-   直接通过下标修改数组，界面不会自动更新。

3\. Vue3.x的响应式实现原理：

-   通过Proxy（代理）：拦截对象中任意属性的变化，包括：属性值的读写、属性的添加、属性的删除等。

```js
const p = new Proxy(person, {
  get(target, propName) {
    console.log(`有人读取了p身上的${propName}属性`);
    return target[propName];
  },
  set(target, propName, value) {
    console.log(`有人修改了p身上的${propName}属性`);
    target[propName] = value;
  },
  deleteProperty(target, propName) {
    console.log(`有人删除了p身上的${propName}属性`);
    return delete target[propName];
  }
});
```

-   通过Reflect（反射）：对被代理对象的属性进行操作。

```js
p = new Proxy(person, {
  get(target, propName) {
    console.log(`有人读取了p身上的${propName}属性`);
    return Reflect.get(target, propName);
  },
  set(target, propName, value) {
    console.log(`有人修改了p身上的${propName}属性`);
    Reflect.set(target, propName, value);
  },
  deleteProperty(target, propName) {
    console.log(`有人删除了p身上的${propName}属性`);
    return Reflect.deleteProperty(target, propName);
  }
});
```

## 2.5 reactive对比ref

1\. 从定义数据角度对比：

-   ref用来定义：**基本类型数据**。
-   reactive用来定义：**对象（或数组）类型的数据**。
-   备注：ref也可以用来定义**对象（或数组）类型的数据**，它内部会自动通过`reactive`转为**代理对象**。

2\. 从原理角度对比：

-   ref通过`Object.defineProperty()`的`get`与`set`来实现响应式（数据劫持）。
-   reactive通过使用**Proxy**来实现响应式（数据劫持），并通过Reflect操作**源对象**内部的数据。

3\. 从使用角度对比：

-   ref定义的数据：操作数据**需要**使用`.value`，读取数据时模板中直接读取**不需要**`.value`。
-   reactive定义的数据：操作数据与读取数据：**均不需要**`.value`。

## 2.6 setup的两个注意点

1\. setup执行的时机：在beforeCreate之前执行一次，此时的this的值是undefined。

2\. setup的参数：

-   props：值为对象，包含：组件外部传递过来，且组件内部声明接收了的属性。
-   context：上下文对象
    -   attrs：值为对象，包含：组件外部传递过来，但没有在props配置中声明的属性，相当于`this.$attrs`。
    -   slots：收到的插槽内容，相当于`this.$slots`。
    -   emit：分发自定义事件的函数，相当于`this.$emit`。

*App.vue*：

```vue

```

*MyDemo.vue*：

```vue

```

## 2.7 计算属性与监视

### 2.7.1 计算属性——computed函数

1\. 在vue中引入computed函数。

2\. 使用computed函数定义计算属性。

3\. 将计算属性添加到返回值，并在模板中使用。

```js
// Vue3中计算属性简写形式
person.fullName = computed(() => {
  return person.firstName + "-" + person.lastName;
});
```

```js
// 如需修改计算属性的值，需要些成完整形式
person.fullName = computed({
  get() {
    return person.firstName + "-" + person.lastName;
  },
  set(value) {
    let nameArr = value.split("-");
    person.firstName = nameArr[0];
    person.lastName = nameArr[1];
  },
});
```

### 2.7.2 监视属性——watch函数

与Vue2.x中的watch配置功能一致。

注意点：

- 监视reactive定义的响应式数据：oldValue无法正确获取、强制开启了深度监视（deep配置失效）。
- 监视reactive定义的响应式数据中的某个属性时：deep配置有效。

情况一：监视ref所定义的一个响应式数据

```js
watch(
  sum,
  (newValue, oldValue) => {
    console.log("sum的值发生改变", newValue, oldValue);
  },
  { immediate: true }
);
```

情况二：监视ref所定义的多个响应式数据

```js
watch(
  [sum, msg],
  (newValue, oldValue) => {
    console.log("监视到数据发生改变", newValue, oldValue);
  },
  { immediate: true }
);
```

情况三：监视reactive所定义的一个响应式数据的全部属性

- 此处无法正确地获取oldValue
- 强制开启了深度监视，即deep配置无效

```js
watch(person, (newValue, oldValue) => {
  console.log("监视到数据发生改变", newValue, oldValue);
}, {deep: false});  // 此处开启深度监视无效
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240403140440952.png)

情况四：监视reactive所定义的一个响应式数据中的某个属性

```js
watch(
  () => person.name,
  (newValue, oldValue) => {
    console.log("监视到数据发生改变", newValue, oldValue);
  }
);
```

情况五：监视reactive所定义的一个响应式数据中的多个属性

```js
watch([() => person.name, () => person.age], (newValue, oldValue) => {
  console.log("监视到数据发生改变", newValue, oldValue);
});
```

### 2.7.3 watchEffect函数

watch的套路是既要指明监视的属性，也要指明监视的回调。

watchEffect的思路是：不用指明监视那个属性，监视的回调中用到那个属性，那就监视那个属性。

watchEffect有点像computed：

- 但computed注重的是计算出来的值（回调函数的返回值），所以必须要写返回值。
- 而watchEffect更注重的是过程（回调函数的函数体），所以不用写返回值。

```js
// watchEffect所指定的回调中用到的数据只要发生变化，则直接重新执行回调
watchEffect(() => {
  const p1 = sum.value;
  const p2 = msg.value;
  const p3 = person.job.j1.salary;
  console.log("watchEffect函数被调用了！");
});
```

## 2.8 Vue 3的生命周期

1\. Vue 3的生命周期图：

![组件生命周期图示](https://icode504.oss-cn-beijing.aliyuncs.com/lifecycle_zh-CN.FtDDVyNA.png)

2\. Vue 3中可以继续使用Vue 2.x中的生命周期钩子，但有两个被更名：

- `beforeDestroy`改名为`beforeUnmount`
- `destroyed`改名为`unmounted`

3\. Vue 3也提供了Composition API形式的生命周期钩子，与Vue 2.x中钩子对应关系如下：

| Vue 3.0生命周期钩子函数 | Vue 3.0 Composition API形式的生命周期钩子 |
| :---------------------: | :---------------------------------------: |
|      beforeCreate       |                  setup()                  |
|         created         |                  setup()                  |
|       beforeMount       |               onBeforeMount               |
|         mounted         |                 onMounted                 |
|      beforeUpdate       |              onBeforeUpdate               |
|         updated         |                 onUpdated                 |
|      beforeUnmount      |              onBeforeUnmount              |
|        unmounted        |                onUnmounted                |

```js
// Vue 3中钩子函数
beforeCreate() {
  console.log("---beforeCreate---");
},

created() {
  console.log("---created---");
},

beforeMount() {
  console.log("---beforeMount---");
},

mounted() {
  console.log("---mounted---");
},

beforeUpdate() {
  console.log("---beforeUpdate---");
},

updated() {
  console.log("---updated---");
},

beforeUnmount() {
  console.log("---beforeUnmount---");
},

unmounted() {
  console.log("---unmounted---");
},
```

```js
// 使用组合式API的钩子函数
onBeforeMount(() => {
  console.log("---onBeforeMount---");
});
onMounted(() => {
  console.log("---onMounted---");
});
onBeforeUpdate(() => {
  console.log("---onBeforeUpdate---");
});
onUpdated(() => {
  console.log("---onUpdated---");
});
onBeforeUnmount(() => {
  console.log("---onBeforeUnmount---");
});
onUnmounted(() => {
  console.log("---onUnmounted---");
});
```

## 2.9 自定义hook函数

1\. `hook`本质是一个函数，把setup函数中使用的Composition API进行了封装，类似于Vue2.x中的mixin。

2\. 自定义hook的优势：代码复用，让setup中的逻辑更清楚易懂。

`hook/usePoint.js`：

```js
import { reactive, onMounted, onBeforeUnmount } from "vue";
export default function () {
  let point = reactive({
    x: 0,
    y: 0,
  });

  function getPoint(event) {
    point.x = event.pageX;
    point.y = event.pageY;

    console.log(point.x, point.y);
  }

  onMounted(() => {
    window.addEventListener("pointermove", getPoint);
  });

  onBeforeUnmount(() => {
    window.removeEventListener("pointermove", getPoint);
  });

  return point;
}
```

`xxx.vue`中使用`usePoint.js`：

```js
import usePoint from "../hooks/usePoint.js";

export default {
  name: "MyDemo",
  setup() {
    const point = usePoint();
    return { point };
  },
};
```

## 2.10 toRef和toRefs

1\. 作用：创建一个ref对象，其value值指向另一个对象中的某个属性。

2\. 语法：

```js
const name = toRef(person, 'name');
```

3\. 应用：要将响应式对象中的某个属性单独提供给外部使用时。

4\. 扩展：`toRefs`和`toRef`功能一致，但可以批量创建多个ref对象，语法：

```js
const personObj = toRefs(person);
```

```vue
<template>
  <h1>姓名: {{ name }}</h1>
  <button @click="name += '@'">点我修改姓名</button>
  <h1>年龄: {{ age }}</h1>
  <button @click="age++">点我修改年龄</button>

  <h1>薪资: {{ job.j1.salary }}K</h1>
  <button @click="job.j1.salary++">点我修改薪资</button>
</template>

<script>
import { reactive, toRef, toRefs } from "vue";

export default {
  name: "MyDemo",
  setup() {
    let person = reactive({
      name: "iCode504",
      age: 23,
      job: {
        j1: {
          salary: 20,
        },
      },
    });

    // const name = toRef(person, 'name');
    // const age = toRef(person, 'age');
    // console.log(name);
    // console.log(age);

    return {
      ...toRefs(person)
    };
  },
};
</script>

<style></style>
```

# 三、其他Composition API

## 3.1 shallowReactve与shallowRef

1\. shallowReactive只处理对象最外层属性的响应式（浅响应式）。使用场景：如果只有一个对象数据，结构比较深，但变化时只是外层属性发生变化时使用。

2\. shallowRef只处理基本数据类型的响应式，不进行对象的响应式处理。使用场景：如果只有一个对象数据，后续功能不会修改该对象中的属性，而是生成新的对象来替换。

```vue
<template>
  <h1>姓名: {{ name }}</h1>
  <button @click="name += '@'">点我修改姓名</button>
  <h1>年龄: {{ age }}</h1>
  <button @click="age++">点我修改年龄</button>

  <h1>薪资: {{ job.j1.salary }}K</h1>
  <button @click="job.j1.salary++">点我修改薪资</button>

  <hr>
  <h2>{{ obj }}</h2>
  <button @click="obj = { y: 999 }">点我修改数据</button>
</template>

<script>
import { reactive, toRef, toRefs, ref, shallowRef, shallowReactive } from "vue";

export default {
  name: "MyDemo",
  setup() {
    // let person = reactive({
    let person = shallowReactive({
      name: "iCode504",
      age: 23,
      job: {
        j1: {
          salary: 20,
        },
      },
    });


    let obj = shallowRef({
      x: 888
    });

    return {
      ...toRefs(person),
      obj
    };
  },
};
</script>
```

## 3.2 readonly与shallowReadonly

1\. readonly：让一个响应式数据变成只读的（深只读）。

2\. shallowReadonly：让一个响应式数据变成只读的（浅只读）。

3\. 应用场景：不希望数据被修改时。

```vue
<template>
  <h1>姓名: {{ name }}</h1>
  <button @click="name += '@'">点我修改姓名</button>
  <h1>年龄: {{ age }}</h1>
  <button @click="age++">点我修改年龄</button>

  <h1>薪资: {{ job.j1.salary }}K</h1>
  <button @click="job.j1.salary++">点我修改薪资</button>
</template>

<script>
import { reactive, toRefs, readonly, shallowReadonly } from "vue";

export default {
  name: "MyDemo",
  setup() {
    // let person = reactive({
    let person = reactive({
      name: "iCode504",
      age: 23,
      job: {
        j1: {
          salary: 20,
        },
      },
    });

    // person = readonly(person);
    person = shallowReadonly(person);

    return {
      ...toRefs(person),
    };
  },
};
</script>

<style></style>
```

## 3.3 toRaw与markRaw

1\. toRaw：

-   作用：将一个有`reactive`生成的**响应式对象**转换成**普通对象**。
-   使用场景：用于读取响应式对象对应的普通对象，对这个普通对象的所有操作，不会引起页面的更新。

2\. markRaw

-   作用：标记一个对象，使其永远不会再成为响应式对象。
-   应用场景：
    -   有些值不应被设置成响应式的，例如复杂的第三方类库等。
    -   当渲染具有不可变数据源的大列表时，跳过响应式转换可以提高性能

```vue
<template>
  <h1>姓名: {{ name }}</h1>
  <button @click="name += '@'">点我修改姓名</button>
  <h1>年龄: {{ age }}</h1>
  <button @click="age++">点我修改年龄</button>

  <h1>薪资: {{ job.j1.salary }}K</h1>
  <h1 v-show="person.car">汽车信息: {{ person.car }}</h1>

  <button @click="job.j1.salary++">点我修改薪资</button>

  <hr>
  <button @click="showRawPerson">点我查看原始的person对象</button>
  <button @click="addCar">点我添加汽车信息</button>
  <button v-if="person.car" @click="person.car.name += '@'">点我修改汽车信息</button>
  <button v-if="person.car" @click="person.car.price++">点我修改汽车价格</button>
</template>

<script>
import { reactive, toRefs, toRaw, markRaw } from "vue";

export default {
  name: "MyDemo",
  setup() {
    // let person = reactive({
    let person = reactive({
      name: "iCode504",
      age: 23,
      job: {
        j1: {
          salary: 20,
        },
      },
    });

    function showRawPerson() {
      const p = toRaw(person);
      p.age++;
      console.log(p);
    }

    function addCar() {
      let car = { name: '奔驰', price: 40 };
      // person.car = car;
      // 变成原始对象，此时在页面中点击按钮不会产生任何响应式效果
      person.car = markRaw(car);
    }

    return {
      ...toRefs(person),
      showRawPerson,
      person,
      addCar
    };
  },
};
</script>

<style></style>
```

## 3.4 customRef

作用：创建一个自定义的ref，并对其依赖项跟踪和更新触发进行显式控制：

```vue
<template>
  <input type="text" v-model="keyword">
  <h1>{{ keyword }}</h1>
</template>

<script>
import { customRef } from 'vue';

export default {
  name: 'MyDemo',
  setup() {
    let keyword = myRef('iCode504', 500);

    // 自定义一个myRef
    function myRef(value, delay) {
      let timer;
      return customRef((track, trigger) => {
        return {
          get() {
            console.log('get函数被调用了!');
            track();    // 通知Vue追踪value的变化（提前和get商量一下，让它认为）
            return value;
          },
          set(newValue) {
            clearInterval(timer);
            console.log(`set函数被调用了!`);
            timer = setTimeout(() => {
              value = newValue;
              trigger();  // 通知Vue去重新解析模板
            }, delay);
          }
        }
      });
    }
    return {
      keyword
    }
  }
}
</script>

<style></style>
```

## 3.5 provide与inject

作用：实现**祖与后代组件间**的通信。

父组件有一个`provide`选项来提供数据，后代组件有一个`inject`选项来开始使用这些数据。

具体写法：

祖组件*App.vue*

```vue
<template>
  <div class="app">
    <h3>App组件 </h3>
    <p>汽车信息: </p>
    <p>车型: {{car.name}}</p>
    <p>价格: {{car.price}}万</p>
    <Child />
  </div>
</template>

<script>
import Child from "./components/Child.vue";
import {reactive, provide} from 'vue';

export default {
  name: 'App',
  components: {Child},
  setup() {
    let car = reactive({
      name: '奔驰',
      price: 40
    });

    provide('car', car);

    return {
      car
    }
  }
}
</script>

<style>
.app {
  background-color: skyblue;
  padding: 10px;
}
</style>
```

后代组件*Son.vue*

```vue
<template>
  <div class="son">
    <h3>Son组件</h3>
    <p>汽车信息: </p>
    <p>车型: {{car.name}}</p>
    <p>价格: {{car.price}}万</p>    
  </div>
</template>

<script>
import {inject} from 'vue';

export default {
  name: 'Son',
  setup() {
    const car = inject('car');
    return {car};
  }
}
</script>

<style>
.son {
  background-color: yellowgreen;
  padding: 10px;
}
</style>
```

## 3.6 响应式数据的判断

1\. isRef：检查一个值是否是一个ref对象。

2\. isReactive：检查一个对象是否是由`reactive`创建的响应式代理。

3\. isReadonly：检查一个对象是否由`readonly`创建的只读代理。

4\. isProxy：检查一个对象是否是由`reactive`或者`readonly`方法创建的代理。

```vue
<template>
  <div class="app">
  </div>
</template>

<script>
import { reactive, ref, readonly, isRef, isReactive, isReadonly, isProxy } from 'vue';

export default {
  name: 'App',
  setup() {
    let car = reactive({
      name: '奔驰',
      price: 40
    });
    let car1 = ref({
      name: '宝马',
      price: 30
    });
    let number = ref(0);
    let car2 = readonly(car)

    console.log(isRef(car1));
    console.log(isRef(number));

    console.log(isReactive(car));
    console.log(isReadonly(car2));
    console.log(isProxy(car));
    console.log(isProxy(car2));

    return {
      car
    }
  }
}
</script>

<style>
.app {
  background-color: skyblue;
  padding: 10px;
}
</style>
```

# 四、Composition API的优势

## 4.1 Options API 存在的问题

在使用传统的OptionsAPI中，新增或者修改一个需求，就需要分别在data、methods、computed里修改。

## 4.2 Composition API的优势

我们可以更加优雅地组织我们的代码和函数。让相关功能的代码更加有序地组织在一起。

# 五、Vue3新的组件

## 5.1 Fragment

1\. 在Vue2中：组件必须有一个根标签。

2\. 在Vue3中：组件可以没有根标签，内部会将多个标签包含在一个Fragment虚拟元素中。

3\. 好处：减少标签层级，减少内存占用。

## 5.2 Teleport

`Teleport`是一种能够将我们的组件HTML结构移动到指定位置的技术。

实现一个弹窗效果：

*Son.vue*：

```vue
<template>
  <div class="son">
    <h3>Son组件</h3>
      <Dialog />
  </div>
</template>

<script>
import Dialog from './Dialog.vue';

export default {
  name: 'Son',
  components: {Dialog}
}
</script>

<style>
.son {
  background-color: yellowgreen;
  padding: 10px;
}
</style>
```

*Dialog.vue*：

```vue
<template>
  <div>
    <button @click="isShow = true">点我弹个窗</button>
    <teleport to="body">
      <div v-if="isShow" class="mask">
        <div class="dialog">
        <h3>我是一个弹窗</h3>
        <h4>内容1</h4>
        <h4>内容2</h4>
        <h4>内容3</h4>
        <button @click="isShow = false">关闭弹窗</button>
      </div>
      </div>
    </teleport>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  name: 'Dialog',
  setup() {
    let isShow = ref(false);
    return {
      isShow
    }
  }
}
</script>

<style>
.dialog {
  width: 300px;
  height: 300px;
  background-color: #66ccff;
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
}

.mask {
  position: absolute;
  top: 0; 
  bottom: 0;
  left: 0;
  right: 0;
  background-color: rgba(0, 0, 0, 0.5);
}
</style>
```

## 5.3 Suspense

等待异步组件时选一些额外内容，让应用有更好的用户体验。

使用步骤：

-   异步引入组件：

```js
import { defineAsyncComponent } from 'vue';
const Child = defineAsyncComponent(() => import('./components/Child.vue'))
```

-   使用Suspense包裹组件，并配置好`default`和`fallback`

```vue
<template>
  <div class="app">
    <h3>App组件 </h3>
    <Suspense>
      <template v-slot:default>
        <Child />
      </template>
      <template v-slot:fallback>
        <h2>加载中，请稍后！</h2>
      </template>
    </Suspense>
  </div>
</template>
```

# 六、Vue3其他新特性

## 6.1 全局API的转移

Vue 2.x有许多全局API和配置。例如：注册全局组件、注册全局指令等。

```js
// 注册全局组件
Vue.component('MyComponent', {
  data: () => {
    count: 0
  },
  template: '<p>{{ count }}</p>'
});

// 注册全局指令
Vue.directive('focus', {
  inserted: el => el.focus(); 
});
```

Vue 3.x中对这些API做出了调整。将全局的API，即`Vue.xxx`调整到了应用实例app上。

| Vue 2.x 全局API          | Vue 3.x 全局API             |
| ------------------------ | --------------------------- |
| Vue.config.xxx           | app.config.xxx              |
| Vue.config.productionTip | **移除**                    |
| Vue.component            | app.component               |
| Vue.directive            | app.directive               |
| Vue.mixin                | app.mixin                   |
| Vue.use                  | app.use                     |
| Vue.prototype            | app.config.globalProperties |

## 6.2 其他改变

Vue 2中data项在Vue 3中应始终被声明一个函数。

过度类名的修改：

-   Vue 2的写法

```css
.v-enter,
.v-leave-to: {
  opacity: 0;
}

.v-leave,
.v-enter-to: {
  opacity: 1;
}
```

-   Vue 3的写法

```css
.v-enter-form,
.v-leave-to: {
  opacity: 0;
}

.v-leave-form,
.v-enter-to: {
  opacity: 1;
}
```

**移除**了keyCode作为v-on的修饰符，同时也不再支持`config.keyCodes`。

**移除**了`v-on.native`修饰符。

-   父组件中绑定事件：

```vue
<my-component 
  v-on:close="handleComponentEvent"
  v-on:click="handleNativeClickEvent"/>
```

-   子组件声明自定义事件：

```html
<script>
  export default {
  	emits: ['close']
  }
</script>
```

**移除**了过滤器（filter）：过滤器虽然这看起来很方便，但是它需要一个自定义与方法，打破大括号内表达式只是JavaScript的假设，这不仅有学习成本，而且有实现成本！建议用方法调用或者计算属性去替换过滤器。
