---
title: $mount函数源码分析
tags: []
category_bar: true
archive: false
date: 2024-02-11 15:42:04
abbrlink:
description:
banner_img:
index_img:
category:
password:
---


# 一、prototype复习

在JavaScript中，每个函数都是一个对象，每一个函数都包含一个子对象，即`prototype`对象。以下是一段包含JS函数的代码：

```javascript

```



# 二、$mount为什么是函数

1\. 打开Vue源码，按<kbd>Ctrl</kbd>和<kbd>F</kbd>键搜索`$mount`，我们会发现源码中对于`$mount`是这样定义的：

```javascript
Vue.prototype.$mount = function (el, hydrating) {
	...
}
```

首先，这里出现的Vue本身是一个函数：

```javascript
function Vue(options) {
  ...
}
```

这里`$mount`函数一共有两个参数，其中第一个参数`el`就是我们传入和容器绑定的`el`。第二个参数`hydrating`我们目前在调用`$mount`函数时没有使用到，因此后续在函数中出现`hydrating`出现的内容默认忽略。

`$mount`函数源码如下：

```javascript
Vue.prototype.$mount = function (el, hydrating) {
  el = el && query(el);
  /* istanbul ignore if */
  if (el === document.body || el === document.documentElement) {
      warn$2("Do not mount Vue to <html> or <body> - mount to normal elements instead.");
      return this;
  }
  var options = this.$options;
  // resolve template/el and convert to render function
  if (!options.render) {
      var template = options.template;
      if (template) {
          if (typeof template === 'string') {
              if (template.charAt(0) === '#') {
                  template = idToTemplate(template);
                  /* istanbul ignore if */
                  if (!template) {
                      warn$2("Template element not found or is empty: ".concat(options.template), this);
                  }
              }
          }
          else if (template.nodeType) {
              template = template.innerHTML;
          }
          else {
              {
                  warn$2('invalid template option:' + template, this);
              }
              return this;
          }
      }
      else if (el) {
          // @ts-expect-error
          template = getOuterHTML(el);
      }
      if (template) {
          /* istanbul ignore if */
          if (config.performance && mark) {
              mark('compile');
          }
          var _a = compileToFunctions(template, {
              outputSourceRange: true,
              shouldDecodeNewlines: shouldDecodeNewlines,
              shouldDecodeNewlinesForHref: shouldDecodeNewlinesForHref,
              delimiters: options.delimiters,
              comments: options.comments
          }, this), render = _a.render, staticRenderFns = _a.staticRenderFns;
          options.render = render;
          options.staticRenderFns = staticRenderFns;
          /* istanbul ignore if */
          if (config.performance && mark) {
              mark('compile end');
              measure("vue ".concat(this._name, " compile"), 'compile', 'compile end');
          }
      }
  }
  return mount.call(this, el, hydrating);
};
```

假设我们在`$mount`函数传入的参数是`'#app'`。

## 第一部分：el的处理

```javascript
el = el && query(el);
/* istanbul ignore if */
if (el === document.body || el === document.documentElement) {
  warn$2("Do not mount Vue to <html> or <body> - mount to normal elements instead.");
  return this;
}
```

第一行首先对传入的`el`进行与`&&`运算，与运算左右都是布尔类型的值，除了`0`、空字符串和空模板字符串、`null`、`undefined`、`NaN`这几个值转换成布尔类型的值结果是false，其他结果都是true。左侧`el`传入的是`'#app'`，是一个非空字符串，因此`&&`左侧计算结果是`true`。

`&&`运算符右侧是一个`query`函数，也将`el`的值传入到这个函数中，以下是`query`函数的源码：

```javascript
/**
 * Query an element selector if it's not an element already.
 */
function query(el) {
  if (typeof el === 'string') {
      var selected = document.querySelector(el);
      if (!selected) {
          warn$2('Cannot find element: ' + el);
          return document.createElement('div');
      }
      return selected;
  }
  else {
      return el;
  }
}
```

在`query`函数中，首先对`el`的数据类型进行判断。前面我们已经说过`el`是字符串类型（string），因此外层判断结果是`true`，此时执行`if`内部的代码。

`document.querySelector(el)`方法是返回文档中与指定选择器或选择器组匹配的第一个==元素==，如果在DOM中没有找到就返回`null`。

根据我们传入的参数，这段代码的作用就是去DOM中查找`id = 'app'`的容器，如果找到了将得到的结果赋值给变量`selected`。

我们在代码中已经写了一个`id = 'app'`的`div`容器，调用`document.querySelector`的结果一定是`true`。

`if`中的判断条件是`!selected`，这里得到的结果就是`false`，就不进入内层的`if`了，直接将变量`selected`对应的值`true`返回。

因此，`query`函数的结果是`true`。根据`&&`运算符的规则，左右布尔表达式计算结果是`true`，得到的结果也最终是`true`并将这个值赋值给`el`。

