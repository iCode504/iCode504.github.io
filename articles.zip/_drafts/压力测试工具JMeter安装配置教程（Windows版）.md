---
abbrlink: '95'
banner_img: ''
categories: []
date: '2024-08-11T19:26:04.375164+08:00'
description: ''
index_img: ''
order: ''
tags: []
title: 压力测试工具JMeter安装配置教程（Windows版）
updated: '2024-08-11T19:27:15.638+08:00'
---
# 一、安装前准备

1\. JMeter默认使用JDK 8及以上，没有安装的小伙伴点击下方任意一个链接查看安装教程：


| JDK 8                                             | JDK 11                                             | JDK 17                                             | JDK 21                                             |
| ------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- | -------------------------------------------------- |
| [点我查看](https://www.icode504.com/posts/1.html) | [点我查看](https://www.icode504.com/posts/28.html) | [点我查看](https://www.icode504.com/posts/26.html) | [点我查看](https://www.icode504.com/posts/27.html) |

2\. 推荐安装NDM（Neat Download Manager），可以加快文件下载速度：[点我查看](https://www.icode504.com/posts/24.html)

# 二、下载JMeter

1\. 点击右侧链接进入官网：[点我查看](https://jmeter.apache.org/download_jmeter.cgi)

2\. 点击下载后缀名为`.zip`的文件：

![](https://source.icode504.com/images/image-b4a86af038f5d131579a713cc4775820.png)

# 三、JMeter的使用

1\. 将下载好的安装包解压到一个你熟悉的位置。为了避免出现不必要的麻烦，建议将解压路径存放到你熟悉的位置且为英文路径，这里我将安装包解压到了E盘：

![](https://source.icode504.com/images/image-6f49f845076902eb1c68e32b6a11bbb7.png)
