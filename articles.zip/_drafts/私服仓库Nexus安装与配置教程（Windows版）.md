---
title: 私服仓库Nexus安装与配置教程（Windows版）
tags: [Nexus, Maven, Gradle, Windows]
category_bar: true
archive: false
abbrlink: 65
description: 
banner_img: 
index_img: 
category: [软件安装, Windows, 项目构建工具]
password:
---



# 一、准备操作

1\. 请确保电脑上已经安装了JDK，如果没有安装，请点击下方任意一个链接查看安装教程（这里我安装的是JDK 8）：

| [JDK 8安装教程](https://www.icode504.com/posts/1.html) | [JDK 11安装教程](https://www.icode504.com/posts/28.html) | [JDK 17安装教程](https://www.icode504.com/posts/26.html) | [JDK 21安装教程](https://www.icode504.com/posts/27.html) |
| :----------------------------------------------------: | :------------------------------------------------------: | :------------------------------------------------------: | :------------------------------------------------------: |

2\. 如果电脑上已经安装JDK，按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，然后点击**确定**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502204142586.png)

3\. 输入`java -version`，按一下回车键，查看JDK安装信息，如果有下面提示信息，说明JDK安装成功：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502204421939.png)

4\. 电脑上需要安装Maven或者Gradle，如果没有安装，请点击下方任意一个链接查看安装教程：

| [Maven安装配置教程](https://www.icode504.com/posts/19.html) | [Gradle安装配置教程](https://www.icode504.com/posts/20.html) |
| :---------------------------------------------------------: | :----------------------------------------------------------: |

5\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，然后点击**确定**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502204142586.png)

6\. 进入命令行以后，如果你安装的是Maven，那么在控制台输入`mvn -v`即可查看当前安装的Maven版本信息；如果你安装的是Gradle，在控制台输入`gradle -v`即可查看当前安装的Gradle版本信息：

|          输入`mvn -v`并执行即可查看Maven的安装信息           |         输入gradle -v并执行即可查看Gradle的安装信息          |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230508221728184.png) | ![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502212143948.png) |

# 二、下载并解压Nexus

1\. 点击右侧链接进入官网下载链接（百度网盘）：[点我下载](https://pan.baidu.com/s/1xdXCvC8Ktam293OlP0uUtw?pwd=1024)

2\. 将下载好的安装包解压到一个你熟悉的位置，路径中建议只包含英文字符，这里我解压到了E盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410113548189.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410113721891.png)

3\. 找到解压后的路径，点击第一个文件夹`nexus-3.66.0-02`进入，然后点击`bin`文件夹进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410113859242.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410113959124.png)

4\. 点击上方路径，鼠标右键点击**复制**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410114939959.png)

4\. 按<kbd>Win</kbd>和<kbd>S</kbd>键，在在搜索框中输入**命令提示符**，然后点击**以管理员身份运行**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410114501336.png)

5\. 由于我们将Nexus解压到D盘，我们需要切换到D盘，在命令行中执行如下命令即可切换：

```powershell
d:
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410115133811.png)

6\. 在命令行中先输入`cd`，然后加一个空格，再将第4步复制的路径粘贴到此处，切换到当前的`bin`目录：

```powershell
cd 第四步你复制的路径
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410115337547.png)

7\. 执行如下命令，启动Nexus：

```powershell
nexus.exe /run
```

8\. 启动过程中会进行一系列初始化，大家一定要耐心等待（初次加载预计需要5~6分钟，执行初始化过程中不要关闭窗口，否则初始化将会失败）。

9\. 当命令行最下方出现如下提示信息就说明Nexus初始化完成，并且成功启动：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410115846582.png)

# 三、配置Nexus

## 3.1 为admin用户重置密码

1\. 打开浏览器，在上方搜索框中输入http://localhost:8081，即可打开Nexus控制台欢迎界面：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410133733885.png)

2\. 点击右上方的**Sign in**登录：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410143409903.png)

3\. 用户名输入`admin`，然后根据输入框中的路径找到`admin.password`文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410143559819.png)

4\. 根据上一步提示框中的路径（如下图），使用记事本打开`admin.password`文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410143814465.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410143927150.png)

5\. 复制文件中的密码，然后粘贴到提示框中的密码输入框：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410144110382.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410144201668.png)

6\. 登录成功，此时会弹出一个启动向导，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410144321224.png)

7\. 这里我们需要重新设置用户`admin`的密码，为了方便记忆，这里我将密码设置成123456，完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410144419100.png)

8\. 配置是否允许匿名访问，处于仓库数据文件安全考虑，这里我们选择第二个禁止匿名访问**Disable anonymous access**。完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410144614630.png)

9\. 点击**Finish**，启动向导配置完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410144740737.png)

## 3.2 Nexus配置国内阿里云仓库

Nexus中提供了如下四个仓库：maven-central、maven-public、maven-releases、maven-snapshots，以下是对这四个仓库的相关说明

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410145615164.png)

以公司研发的产品为例：

| 仓库名称        | 仓库说明                                                     | 类型   | 类型说明                       |
| --------------- | ------------------------------------------------------------ | ------ | ------------------------------ |
| maven-central   | 代理某个远程的中央仓库/镜像仓库。如果Nexus本地不存在jar/war包，就会转到配置的远程仓库中下载。 | proxy  | 代理远程仓库                   |
| maven-public    | 这个仓库存放Nexus获取到的第三方jar包，供开发人员下载。       | group  | 存储第三方的jar包              |
| maven-releases  | 开发人员如果需要部署**正式**版本的jar/war包，就会存储到maven-releases仓库中 | hosted | 存储开发人员部署到Nexus的jar包 |
| maven-snapshots | 开发人员如果需要部署**快照**版本的jar/war包，就会存储到maven-snapshots仓库中 | hosted |                                |

由于maven-central默认使用的是Maven官方的中央仓库，这个仓库服务器在国外，我们需要将仓库代理设置为国内阿里云的镜像仓库。

1\. 在上方点击Nexus设置：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410151328225.png)

2\. 点击左侧的**Repositories**，然后点击列表中的**maven-central**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410151444916.png)

3\. 复制下方阿里云镜像仓库链接：

```http
https://maven.aliyun.com/repository/public
```

4\. 将Remote storage中的链接替换成上一步复制的链接：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410151950507.png)

5\. 翻到页面最下方，点击**Save**保存当前配置：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410152040098.png)

此时右上角弹出一个绿色提示框说明配置保存成功，此时Nexus就会代理国内的阿里云镜像仓库了！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410152119520.png)

## 3.3 将Maven镜像配置成Nexus私服仓库

1\. 找到Maven安装路径，打开`conf`目录，然后将这个目录下的`setting.xml`复制一份留作备份：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410153738013.png)

2\. 按照下图所示的操作，使用记事本打开`settings.xml`文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/00002.gif)

3\. 

