---
title: 软件包管理器Homwbrew安装、配置教程（Linux通用版）
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

# 一、安装前操作

1\. 执行如下命令，查看当前Linux发行版本信息：

```bash
uname -a
```

这里我使用的是Debian操作系统：

![](https://source.icode504.com/images/image-20240430090546557.png)

2\. 根据上面的操作系统信息，安装git和curl，执行如下命令：

-   Ubuntu/Debian

```bash
sudo apt -y install git curl
```

-   CentOS

```bash
sudo yum -y install git curl
```

3\. 创建一个用户（用户名可自定义），这里我命名为`testuser`：

```bash
sudo useradd -m testuser
```

4\. 为新用户设置密码，为了方便记忆，这里我将密码设置为123456（密码不会在命令行显示）：

```bash
sudo passwd testuser
```

![](https://source.icode504.com/images/image-20240716205639415.png)

5\. 使用`su`命令切换至新用户：

```bash
su - testuser
```



# 二、安装Homebrew

1\. 依次执行如下命令设置环境变量：

```bash
export HOMEBREW_INSTALL_FROM_API=1
export HOMEBREW_API_DOMAIN="https://mirrors.tuna.tsinghua.edu.cn/homebrew-bottles/api"
export HOMEBREW_BOTTLE_DOMAIN="https://mirrors.tuna.tsinghua.edu.cn/homebrew-bottles"
export HOMEBREW_BREW_GIT_REMOTE="https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/brew.git"
export HOMEBREW_CORE_GIT_REMOTE="https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/homebrew-core.git"
```

2\. 使用Git拉取代码，执行如下命令：

```bash
git clone --depth=1 https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/install.git brew-install
```

3\. 安装Homebrew，执行如下命令：

```bash
/bin/bash brew-install/install.sh
```

4\. 删除前面使用Git拉去下来的代码：

```bash
rm -rf brew-install
```

