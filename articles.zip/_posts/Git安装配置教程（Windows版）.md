---
title: Git安装配置教程（Windows版）
tags:
  - Git
  - Windows
category_bar: true
abbrlink: 69
description: Windows环境下安装版本控制工具Git
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Git安装配置教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Git安装配置教程（Windows版）.png
category:
  - 软件安装
  - Windows
  - 版本控制工具
date: 2024-05-09 17:22:54
---


Git是一种分布式版本控制系统，用于跟踪文件和文件夹的变化，并协调多人在同一个项目中的工作。它允许开发者在不同的分支上并行开发，轻松地将更改合并到主分支中，并提供了强大的版本控制和协作功能。

以下是Windows环境下Git的安装教程。

# 一、下载Git

以下两种下载方式任选其一：

## 方式一：镜像网站下载（推荐）

1\. 点击右侧链接进入清华大学镜像网站：[点我查看](https://mirrors.tuna.tsinghua.edu.cn/github-release/git-for-windows/git/LatestRelease/)

2\. 点击64位的安装包下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240509170526006.png)

## 方式二：官网下载（下载地址来源于Github，速度较慢，不推荐）

1\. 点击右侧链接进入Git官网下载地址：[点我查看](https://git-scm.com/downloads)

2\. 选择Windows系统安装包下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205115812104.png)

3\. 选择64位安装包下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205161003502.png)

# 二、安装Git

1\. 双击打开安装包，此时会弹出GNU通用公共协议界面，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205163219091.png)

2\. 点击**Browse**选择安装路径，这里我安装在D盘。选择好路径以后，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205163336033.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205163549635.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205163649431.png)

3\. 如果出现下图的弹窗提示文件夹已经存在，点击**是**即可（没有此提示的小伙伴直接跳转到下一步）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205163911992.png)

4\. 选择要安装的组件：按照默认勾选即可，后面两个以`(NEW!)`开头的可以不勾选，完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164025989.png)

5\. 选择开始菜单文件夹，如果你对此操作不熟悉的话，就不用修改任何内容。完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164150833.png)

6\. 默认编辑器选择Vim。点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164229347.png)

> 说明（初次安装的小白可以跳过这段内容）：Vim编辑器是一款高度可定制的编辑器，它是从Unix平台的Vi编辑器发展而来的，Vim在Vi的基础上添加了很多新特性。Vim包含多种模式：正常模式（查看文本内容）、插入模式（文本编辑）、命令行模式（执行各种命令，例如保存文件、查找或替换内容等）。

7\. 设置新仓库初始分支的名字，按照系统默认选择**Let Git decide**（让Git自己决定），完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164344584.png)

> 说明（初次安装的小白可以跳过这段内容）：使用`git --init`命令初始化一个仓库时，默认会创建一个名为`master`分支。

8\. 调整环境变量，按照系统推荐选择**Git from the commond line and alos from 3rd-party software**，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164432091.png)

> 说明（初次安装的小白可以跳过这段内容）：勾选上述选项的作用是将Git添加到环境变量中。后续你可以在Windows的命令行、PowerShell、Git Bash和其他第三方软件中使用Git命令。
>
> 以下是在Windows命令行（cmd）拉取代码的演示：
>
> ![](https://icode504.oss-cn-beijing.aliyuncs.com/240429001.gif)

9\. 选择可执行的SSH工具，这里按照默认勾选**Use bundled OpenSSH**（使用Git自带的SSH工具），点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164541084.png)

> 说明（初次安装的小白可以跳过这段内容）：OpenSSH的一个主要用途就是可以使用`ssh`命令远程登录服务器，以下是ssh命令在Git中的使用演示：
>
> ![](https://icode504.oss-cn-beijing.aliyuncs.com/240429002.gif)

10\. 选择HTTPS连接时，Git使用的是SSL还是TLS库，这里按照系统默认勾选**Use the OpenSSL library**，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164623393.png)

11\. 换行风格选择，按照系统默认勾选**Checkout Windows-style, commit Unix-style line endings**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164808355.png)

> 说明（初次安装的小白可以跳过这段内容）：LF（Line Feed）是Unix和类Unix系统的换行方式，CRLF（Carriage Return + Line Feed）是换行键+回车键，是Windows系统表示换行的方式。

12\. 按照系统默认勾选**Use MinTTY(the default terminal of MSYS2)**，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205164916315.png)

13\. 配置从服务器拉取代码的默认操作，按照系统默认勾选**Fast-forward or merge**，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205165043193.png)

14\. 按照系统默认勾选**Git Credential Manager**，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205165127672.png)

> 说明（初次安装的小白可以跳过这段内容）：Git凭证管理工具（Git Credential Manager），主要用于存储和检索访问Git仓库的凭据，例如用户名、密码、访问Github/Gitee所用到的token令牌等。

15\. 配置额外选项，按照系统默认勾选**Enable file system caching**（开启文件系统缓存），点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205165221025.png)

16\. 配置实验性选项，这里全部不勾选，点击**Install**开始安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205165328884.png)

17\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205165358391.png)

18\. 安装完成，上方内容全部取消勾选，点击**Finish**。至此，Git安装完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205165528937.png)

