---
abbrlink: '45'
archive: false
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Intellij IDEA-DataGrip配置MySQL教程.png
categories: []
category:
- - Intellij IDEA
  - MySQL
- - DataGrip
  - MySQL
category_bar: true
date: '2024-02-20T15:19:24+08:00'
description: 本文提供了关于如何在Intellij IDEA/DataGrip中配置MySQL的详细教程。通过此教程，读者将了解如何安装MySQL插件、配置数据库并测试连接。
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Intellij IDEA-DataGrip配置MySQL教程.png
order: ''
password: null
tags:
- Intellij IDEA
- MySQL
- DataGrip
title: Intellij IDEA/DataGrip配置MySQL8.0教程
updated: '2024-08-16T10:00:40.521+08:00'
---
请确保电脑本机已经安装MySQL和Intellij IDEA/DataGrip，没有安装的小伙伴根据自己的操作系统点击下方链接查看安装教程（已经安装的小伙伴继续往下看）：


|              |                      Windows                      |                       macOS                       |  Linux  |
| :-----------: | :------------------------------------------------: | :------------------------------------------------: | :------: |
|   MySQL 8.0   | [点我查看](https://www.icode504.com/posts/18.html) | [点我查看](https://www.icode504.com/posts/68.html) | 敬请期待 |
| Intellij IDEA | [点我查看](https://www.icode504.com/posts/10.html) | [点我查看](https://www.icode504.com/posts/79.html) | 敬请期待 |
|   DataGrip   |                      敬请期待                      |                      敬请期待                      | 敬请期待 |

- Windows检查MySQL安装版本：按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`并回车，在命令行中输入`mysql --version`，确保本机安装的MySQL版本在8.0及以上：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220151342379.png)

- macOS检查MySQL安装版本：如果你是按照上面的链接一步一步安装的MySQL。在安装完成后，重新打开终端，在终端中输入`mysql --version`，即可查看当前MySQL版本信息。

1\. 打开Intellij IDEA，按照下图所示操作，数据源选择**MySQL**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220143236662.png)

2\. 在Driver处，点击**MySQL**，点击**Go to Driver**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220143412262.png)

3\. 在Driver Files处，点击**加号**，选择**Proviced Dirver**，数据库驱动选择MySQL官网最新稳定版本：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220143707207.png)

4\. 由于我的电脑中已经下载最新版本的MySQL数据库驱动（JDBC），直接点击右侧的`Switch to ver. xxxx`即可：

> 如果你没有数据库驱动，此时右侧应该是`Download ver. xxxx`，直接点击下载即可。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220144109011.png)

5\. 此时数据库驱动切换成功，我们再点击左上角的**Data Sources**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220144741605.png)

6\. 按照下图操作，根据自己的实际情况添加数据库配置信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220145242313.png)

7\. 填写完成后，点击右下角的**Test Connection**测试一下数据库连接，出现下图所示的连接就说明MySQL连接成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220145404194.png)

8\. 此时再次输入以下密码，直接点击**OK**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220145705718.png)

9\. 连接成功，接下来你就可以在console中写SQL语句了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240220145832765.png)
