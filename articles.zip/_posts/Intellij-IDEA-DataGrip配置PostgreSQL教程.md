---
title: Intellij IDEA/DataGrip配置PostgreSQL教程
tags:
  - Intellij IDEA
  - PostgreSQL
  - DataGrip
category_bar: true
abbrlink: 36
description: Intellij IDEA/DataGrip配置PostgreSQL
categories:
  - [Intellij IDEA, PostgresSQL]
  - [DataGrip, PostgresSQL]
date: 2024-01-31 09:14:56
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Intellij-IDEA-DataGrip配置PostgreSQL教程.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Intellij-IDEA-DataGrip配置PostgreSQL教程.png
---


请确保电脑本机已经安装PostgresSQL和Intellij IDEA，没有安装的小伙伴根据自己的操作系统点击下方链接查看安装教程（已经安装的小伙伴继续往下看）：

|               |                      Windows                       |  macOS   |  Linux   |
| :-----------: | :------------------------------------------------: | :------: | :------: |
|  PostgreSQL   | [点我查看](https://www.icode504.com/posts/35.html) | 敬请期待 | 敬请期待 |
| Intellij IDEA | [点我查看](https://www.icode504.com/posts/10.html) | 敬请期待 | 敬请期待 |

1\. 按照下图所示操作，数据源选择PostgreSQL：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240105174627593.png)

2\. 在Driver处，点击**PostgreSQL**，点击**Go to Driver**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240105175052684.png)

3\. 在Driver Files处，点击**加号**，选择**Proviced Dirver**，数据库驱动选择PostgreSQL官网最新稳定版本：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130111433876.png)

4\. 点击**Download**，下载数据库驱动文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130111631704.png)

5\. 下载中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130111649561.png)

5\. Postgres驱动包添加成功，如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130114135936.png)

6\. 点击左上角的Data Sources。用户名Username输入**postgres**，密码是你在安装Postgres的时候设置的密码（我当时设置的是123456）。配置完成后，点击左下角的**Test Connection**测试我们填写的内容是否正确：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130114220813.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130094448766.png)

7\. 左下角出现Succeeded弹窗表示Postgres连接成功。重新输入一遍密码，点击**OK**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130094755483.png)

8\. 连接成功，接下来你就可以在console中写SQL语句了！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130100150910.png)
