---
abbrlink: '88'
banner_img: https://source.icode504.com/images/Linux Ubuntu安装配置教程.png
categories:
  - [系统安装, Ubuntu]
date: '2024-08-03T11:33:25.203400+08:00'
description: 本教程详细介绍Linux Ubuntu桌面版的安装配置步骤，包括虚拟机创建、系统安装、网络配置、用户权限设置等关键内容，帮助用户快速搭建稳定、高效的Ubuntu系统环境。
index_img: https://source.icode504.com/images/Linux Ubuntu安装配置教程.png
order: ''
tags:
- Ubuntu
title: Linux Ubuntu桌面版安装配置教程
updated: '2024-08-04T10:49:53.975+08:00'
---
Ubuntu是一个基于Linux的开源操作系统，它遵循GNU通用公共许可证，用户可以自由使用、复制、分发和修改。它提供直观易用的桌面环境，适合新手和有经验用户。Ubuntu有强大的软件中心，支持多硬件架构，注重安全和稳定，并有庞大的用户社区提供支持。它适用于桌面、笔记本和服务器等多种设备，被广泛应用于教育、开发和科学等领域。

接下来就为大家介绍一下Ubuntu桌面版操作系统的安装与配置：

# 一、安装前准备

请确保电脑中已经安装了VMware，如果没有安装的小伙伴可以点击下面的链接查看安装教程：


| 需要安装的软件名称                                        | 链接         |
| --------------------------------------------------------- | ------------ |
| 虚拟机软件VMWare Workstation                              | [点我查看](https://www.icode504.com/posts/41.html) |
| 下载器Neat Download Manager（推荐安装，可以加快下载速度） | [点我查看](https://www.icode504.com/posts/24.html) |

建议电脑预留50G以上的存储空间。

# 二、下载Ubuntu镜像

这里我安装的是22.04版本的Ubuntu服务器。

1\. 点击右侧链接进入清华大学镜像站：[点我查看](https://mirrors.tuna.tsinghua.edu.cn/ubuntu-releases/)

2\. 这里我选择的是22.04版本下载，点击进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221212521251.png)

3\. 下载桌面端的Ubuntu镜像，如下图所示：

![](https://source.icode504.com/images/image-c81730feca4d51c04005cdf848f11034.png)

# 三、创建Ubuntu虚拟机

1\.打开VMware，按<kbd>Ctrl</kbd>和<kbd>N</kbd>键，新建虚拟机。

2\. 进入新建虚拟机向导以后，选择第二个**自定义(高级)**，完成后点击**下一步**：

![https://source.icode504.com/images/image-5d8a8b52b3a1d293e052c802843a77a0.png](https://source.icode504.com/images/image-5d8a8b52b3a1d293e052c802843a77a0.png)

3\. 点击**下一步**：

![https://source.icode504.com/images/image-dae74e0a9bfded71ec53de75250d67c7.png](https://source.icode504.com/images/image-dae74e0a9bfded71ec53de75250d67c7.png)

4\. 安装客户机操作系统选择**稍后安装操作系统**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213134527045.png)

5\. 客户机操作系统选择**Linux**，版本选择**Ubuntu 64位**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221215406394.png)

6\. 自定义虚拟机名称和安装位置。安装位置建议安装在一个空间比较大的盘，这里我安装在了J盘：

![https://source.icode504.com/images/image-3ed1a9b7808131ce70e15639e91b246a.png](https://source.icode504.com/images/image-3ed1a9b7808131ce70e15639e91b246a.png)

![https://source.icode504.com/images/image-8331b8d8676584f0e282ebb09d4e25d0.png](https://source.icode504.com/images/image-8331b8d8676584f0e282ebb09d4e25d0.png)

![https://source.icode504.com/images/image-014ca958cb472efc80cca32cd14f8867.png](https://source.icode504.com/images/image-014ca958cb472efc80cca32cd14f8867.png)

7\. 处理器配置时处理器数量和内核数量不能超过电脑自身的数量，否则虚拟机无法正常运行，这里我设置的**处理器内核总数**为2：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135358478.png)

如何检查电脑本机的CPU信息：按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，即可查看到CPU信息：

![](https://source.icode504.com/images/image-20240213135636008.png)

8\. 设置虚拟机内存，内存大小按照VMware的要求设置在一定范围之内。这里我设置内存大小为4GB（4096M），完成后点击**下一步**：

![](https://source.icode504.com/images/image-20240221213933440.png)

9\. 网络类型选择**网络地址转换(NAT)**，完成后点击**下一步**：

![](https://source.icode504.com/images/image-20240213153239112.png)

10\. I/O控制器类型按照系统默认选择即可，然后点击**下一步**：

![](https://source.icode504.com/images/image-20240213153335558.png)

11\. 虚拟磁盘类型按照默认选择即可，完成后点击**下一步**：

![](https://source.icode504.com/images/image-20240213153449643.png)

12\. 选择磁盘按照系统默认选择即可，然后点击**下一步**：

![](https://source.icode504.com/images/image-20240213153601825.png)

13\. 最大磁盘大小建议设置在20GB及以上，这里我设置了50GB，磁盘分配按照默认勾选即可。完成后点击**下一步**：

![](https://source.icode504.com/images/image-20240213153741099.png)

14\. 指定磁盘文件位置可以自定义。这里需要设置的小伙伴点击**浏览**可以更改。不需要更改的小伙伴点击**下一步**：

![](https://source.icode504.com/images/image-20240221214019977.png)

15\. 点击**完成**，虚拟机创建完成：

![](https://source.icode504.com/images/image-20240221215930776.png)

16\. 点击**编辑虚拟机设置**：

![](https://source.icode504.com/images/image-20240221214109235.png)

17\. 进入虚拟机设置后，左侧设备选择**CD/DVD**，设备状态勾选**启动时连接**，连接选择**使用ISO映像文件**，点击**浏览**：

![](https://source.icode504.com/images/image-20240213160808035.png)

18\. 找到前面我们下载的Ubuntu镜像并选中，完成后点击右下角**打开**：

![](https://source.icode504.com/images/image-f1504ad5a7def1dd636886f62647464b.png)

19\. 镜像配置成功，点击**确定**：

![](https://source.icode504.com/images/image-20240221214534533.png)

# 四、开启虚拟化

1\. 开启刚刚创建好的虚拟机，此时VMware会弹出一个错误信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214629072.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113330696.png)

2\. 此时按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，虚拟化并未开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113646198.png)

3\. 重新启动电脑，具体进入BIOS可以根据自身电脑品牌型号进入。这里我的电脑使用的是华硕，开机过程中一直按<kbd>F2</kbd>键即可进入BIOS，再点击右下角**Advanced Mode**，进入高级模式：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227133747848.png)

4\. 按照下图所示操作，点击**高级**，将**Intel Virtualization Technology**配置项开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134148071.png)

5\. 按<kbd>F10</kbd>键保存上述配置并重启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134402192.png)

6\. 按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，左上角找到**性能**，发现虚拟化成功开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227114535913.png)

# 五、安装Ubuntu操作系统

1\. 开启刚刚创建好的虚拟机：

![https://source.icode504.com/images/image-c4b2e376f743d10bdaed76bb494015ce.png](https://source.icode504.com/images/image-c4b2e376f743d10bdaed76bb494015ce.png)

2\. 进入安装界面，选择第一个**Try or Install Ubuntu Server**，然后按一下回车：

![https://source.icode504.com/images/image-a45c1b00c888a3c60c9fb6eb62226d91.png](https://source.icode504.com/images/image-a45c1b00c888a3c60c9fb6eb62226d91.png)

3\. 此时会加载Ubuntu的安装界面，请耐心等待。

4\. 加载完成后 ，进入Ubuntu安装界面，在左侧安装语言选择**中文（简体）**，然后点击**安装Ubuntu**：

![https://source.icode504.com/images/image-cc06ba35c387e0eadc83021df486d07a.png](https://source.icode504.com/images/image-cc06ba35c387e0eadc83021df486d07a.png)

5\. 键盘布局按照系统默认即可，点击右下角**继续**：

![https://source.icode504.com/images/image-b8f9fd9dafd565717b2333028469a3c7.png](https://source.icode504.com/images/image-b8f9fd9dafd565717b2333028469a3c7.png)

6\. 更新和安装软件界面按照系统默认即可，点击右下角**继续**：

![https://source.icode504.com/images/image-040276d5e0494d2e791c758ecfb72344.png](https://source.icode504.com/images/image-040276d5e0494d2e791c758ecfb72344.png)

7\. 安装类型按照系统默认选择即可，点击右下角**现在安装**：

![https://source.icode504.com/images/image-65f57f8dff166879820be93a517eefbf.png](https://source.icode504.com/images/image-65f57f8dff166879820be93a517eefbf.png)

8\. 此时会弹出是否写入磁盘的提示，点击右下角**继续**：

![https://source.icode504.com/images/image-085f4d8785529f2b79d1634221602f7c.png](https://source.icode504.com/images/image-085f4d8785529f2b79d1634221602f7c.png)

9\. 时区默认选择上海（Shanghai），点击**继续**：

![https://source.icode504.com/images/image-f075741396e1c22f7afa75d1841fb898.png](https://source.icode504.com/images/image-f075741396e1c22f7afa75d1841fb898.png)

10\. 按照下面内容进行配置用户名和密码，点击**继续**：

![https://source.icode504.com/images/image-2e3ad7e6782f73b6c58babe578f475c3.png](https://source.icode504.com/images/image-2e3ad7e6782f73b6c58babe578f475c3.png)

11\. 安装中，请耐心等待：

![https://source.icode504.com/images/image-7bb2634c42cb16c881c0feca7c6e0552.png](https://source.icode504.com/images/image-7bb2634c42cb16c881c0feca7c6e0552.png)

12\. 安装完成，点击**立即重启**：

![https://source.icode504.com/images/image-93bd6e17ef672a9c9ad8dceb317a8b0a.png](https://source.icode504.com/images/image-93bd6e17ef672a9c9ad8dceb317a8b0a.png)

13\. 重启以后，点击前面创建的用户，输入当前用户密码，按一下<kbd>Enter</kbd>键：

![https://source.icode504.com/images/image-e850bc14f3a1cbbb530b46e8849c63f2.png](https://source.icode504.com/images/image-e850bc14f3a1cbbb530b46e8849c63f2.png)

![https://source.icode504.com/images/image-56d92f94483b5208f99664ffc0623f32.png](https://source.icode504.com/images/image-56d92f94483b5208f99664ffc0623f32.png)
