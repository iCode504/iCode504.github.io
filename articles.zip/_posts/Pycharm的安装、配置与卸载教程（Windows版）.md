---
title: Pycharm的安装、配置与卸载教程（Windows版）
tags:
  - Windows
  - Pycharm
category_bar: true
archive: false
abbrlink: 50
description: >-
  本教程详细介绍了在Windows操作系统下，如何安装、配置和卸载PyCharm这款强大的Python集成开发环境。涵盖了安装步骤、配置选项及卸载流程，帮助用户轻松管理PyCharm。
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Pycharm的安装、配置与卸载教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Pycharm的安装、配置与卸载教程（Windows版）.png
category: 
  - 软件安装
  - Windows
  - 集成开发环境
date: 2024-02-27 10:39:00
password:
---


PyCharm是一种功能强大的Python集成开发环境（IDE），由JetBrains开发，旨在提高开发者的工作效率和便利性。它提供了一系列工具和功能，帮助开发者更快速地编写代码、调试程序、进行单元测试以及管理项目。

PyCharm的主要特点包括：

1. 智能代码补全：PyCharm具备智能代码补全功能，能够根据上下文自动推荐合适的代码片段，从而加快编写速度。
2. 语法高亮：通过语法高亮，开发者可以清晰地看到代码的结构和语法，有助于减少错误并提高可读性。
3. 调试功能：PyCharm提供了强大的调试工具，允许开发者设置断点、单步执行代码、查看变量值等，从而更容易地找到和修复错误。
4. 代码重构：该IDE支持代码重构功能，可以帮助开发者改进代码结构，提高代码质量。
5. 单元测试：PyCharm内置了单元测试框架，方便开发者编写和执行测试用例，确保代码的正确性。
6. 版本控制：PyCharm支持多种版本控制系统（如Git），可以帮助开发者管理代码版本，协同开发。

此外，PyCharm还提供了其他一些高级功能，如支持Django框架下的专业Web开发、支持科学计算库（例如：numpy、pytorch、panda）等。它支持多种Python解释器，可以与多种数据库和Web服务器进行集成，为开发者提供了全面的开发环境。

接下来就为大家介绍一下Windows环境下Pycharm的安装与使用：

# 一、安装前检查

1\. 请确保本地已经安装了Python，如果没有安装的，查看此文章一步一步安装即可：点我查看

|                |                      Windows                       |  macOS   | Linux通用版 |
| :------------: | :------------------------------------------------: | :------: | :---------: |
| Python安装教程 | [点我查看](https://www.icode504.com/posts/49.html) | 敬请期待 |  敬请期待   |

2\. 输入`python --version`命令表示电脑上已经成功安装了Python：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226141207153.png)

# 二、Pycharm下载

1\. 进入Pycharm的官方下载页面，[点我查看](https://www.jetbrains.com.cn/pycharm/download/other.html)。这里我使用的是2021.1.3版本（事实上，要下载的版本和最新版本使用Python编写代码的差异并不大）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226145214009.png)

2\. Windows选择2021.1.3版本的安装包进行下载（如下图所示）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226145256169.png)

# 三、Pycharm安装

1\. 双击打开安装包，进入欢迎界面后，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226133856208.png)

2\. 点击Browse选择安装位置，这里我将Pycharm安装在了D盘，完成后点击Next：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226134014038.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226134219637.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226134252053.png)

3\. 安装操作中，勾选**64-bit launcher**（在桌面上生成快捷方式），完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226134402753.png)

4\. 点击**Install**，开始安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226134536277.png)

5\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226134601699.png)

6\. 点击**Finish**，安装完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226134736032.png)

# 四、Pycharm开启30天免费实用&插件安装

1\. 在桌面上双击打开Pycharm，首次安装的小伙伴，可能会弹出如下的弹出一个协议，按照下图所示勾选，然后点击**Continue**（没有的下图弹窗的请跳转到第三步）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231026114146154.png)

2\. 出现数据分享窗口后，选择**Don't Send**（没有的下图弹窗的请跳转到第三步）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231026114256575.png)

3\. 是否导入Pycharm配置，这里我选择第二个**Do not import settings**（不导入配置），完成后点击**OK**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226135256036.png)

4\. 进入激活页面，我们下载的是Pycharm Profession版，正常是需要按月或者按年支付费用的。此处我们先按照下图进行30天的免费试用：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226135537943.png)

> 如需正版，请点击右侧链接到官网购买（需要注册账号）：[点我进入](https://www.jetbrains.com.cn/pycharm/buy/#personal)

5\. 出现下方这个页面以后，就说明我们30天使用申请成功，此时点击**Continue**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226135758110.png)

6\. 进入Pycharm欢迎界面以后，点击Plugins进入插件下载页面：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226135859295.png)

7\. 点击右上角小齿轮，点击**Manage Plugin Repositories**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226140203135.png)

8\. 点击左上角的加号，复制下方链接并粘贴到输入框中，然后点击OK：

```
https://plugins.zhile.io
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226140313487.png)

9\. 此时在插件下载页面中搜索`IDE Eval Reset`，然后点击`Install`：

> `IDE Eval Reset`插件的作用是无限延长IDEA的试用期。正常IDEA给我们的试用是30天，使用这款插件以后，只要快到了需要激活IDEA的时间，他就会自动延长一个月的试用期。从理论上来讲，安装这款插件以后，理论上就可以实现永久使用。
>
> 这款插件仅限于在IDEA 2021.2.2以下的版本使用，往后的版本中不适用。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226140649592.png)

10\. 出现此弹框时，点击`Accept`，此时IDEA会安装此插件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226140715561.png)

11\. 至此，插件已经成功安装了。此插件具体使用详见下一部分内容。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226140745622.png)

# 五、使用Pycharm编写并运行Python程序

1\. 创建项目：点击左侧**Projects**，然后点击**New Project**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226141337128.png)

2\. 进入创建项目后，点击Location右侧的小文件夹，修改写代码的位置，建议将这个路径修改成你熟悉的文件路径，这里我将项目位置存放到E盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226141639600.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226141812068.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226141850171.png)

3\. Pycharm会自动检查Python安装位置，点击**Create**，创建项目：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226142439706.png)

4\. 此时会弹出一个每日小提醒，勾选左下角**Don't show tips**，然后点击右下角**Close**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226142721480.png)

5\. 鼠标右键点击项目文件夹，选择第一个**New**，再选择**Python File**，创建一个Python文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226143312984.png)

6\. 输入文件名称，这里我将文件命名为`MyDemo01`，类型选择`Python file`，然后按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226143502795.png)

7\. 复制下方代码，并粘贴到Pycharm中，效果图如下：

```python
print("秋容浅淡映重门，七节攒成雪满盆。")
print("出浴太真冰作影，捧心西子玉为魂。")
print("晓风不散愁千点，宿雨还添泪一痕。")
print("独倚画栏如有意，清砧怨笛送黄昏。")
print("选自《红楼梦》第三十七回")
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226144259362.png)

8\. 运行Python程序：

方式一：鼠标右键，点击`Run MyDemo01.py`：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226144424753.png)

方式二：使用快捷键，这里我使用的快捷键是<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>F10</kbd>，具体的快捷键详见自己鼠标右键后`Run xxx`后面对应的快捷键执行即可。

运行结果如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226144541010.png)

9\. IDE Eval Reset插件的无限期使用：点击上方**Help**，然后点击最下面的**Eval Reset**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226144708487.png)

10\. 按照下图所示进行勾选，然后点击Reset，此时IDEA会自动重启。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231026160856389.png)

11\. 点击Yes，就会重启，此时IDEA的试用期就会延长。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226144850168.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226144904782.png)


# 六、Pycharm卸载（可选）

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Installer，在程序列表中找到Pycharm，鼠标右键，点击卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227104420588.png)

2\. 卸载向导中会询问是否删除Pycharm缓存、配置文件和插件。如果需要彻底删除的话，请将下图两个选项进行勾选。完成后点击**Uninstall**，开始卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227104604708.png)

3\. 卸载中，请耐心等待。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227104722141.png)

4\. 卸载完成，点击Close关闭窗口：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227104755189.png)

5\. 此时Geek会我们检测出安装残留，我们只需要点击**完成**即可，清除卸载残留：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227104821350.png)

6\. 清理完毕，关闭Geek即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240121164930832.png)
