---
abbrlink: '83'
archive: false
banner_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
categories:
- 软件安装
- Linux
- 数据库
- 非关系型数据库(NoSQL)
category_bar: true
date: '2024-07-25T22:54:21+08:00'
description: 本教程详细介绍了在Linux系统上安装Redis的步骤，包括两种方式：Docker方式安装并启动Redis、源码方式安装、配置并启动Redis，帮助用户快速部署和运行Redis实例。
index_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
order: ''
password: null
tags:
- Redis
- Docker
- Linux
title: Redis安装教程（Linux版）
updated: '2024-08-15T09:05:20.352+08:00'
---
想学习更多Redis相关知识，请点击右侧链接查看Redis学习笔记：[点我查看](https://www.icode504.com/posts/90.html)

Redis是一种开源的、内存中的键值存储数据库，通常用作缓存、消息代理和持久化存储。它支持丰富的数据结构，如字符串、哈希、列表、集合和有序集合等，能够高效地执行各种操作。Redis具有极高的性能，常被用于需要快速数据读写的场景，同时提供持久化选项，可以将数据定期保存到磁盘上，以确保数据的持久性。其丰富的功能和灵活性使其在分布式系统和实时应用中非常受欢迎。

以下是Redis的安装教程，两种方式任选其一：

# 方式一：Docker方式安装并启动Redis

请确保电脑上已经安装了Docker，需要安装Docker的小伙伴根据自己的操作系统去安装Docker：


|                |                       CentOS                       |                   Ubuntu/Debian                   |
| -------------- | :------------------------------------------------: | :------------------------------------------------: |
| Docker安装教程 | [点我查看](https://www.icode504.com/posts/94.html) | [点我查看](https://www.icode504.com/posts/75.html) |

这里我使用的是Redis 6.0.10版本。

1\. 拉取Redis镜像：

```bash
docker pull redis:6.0.10
```

2\. 创建一个文件目录，用来存储redis配置文件，这里我创建了`/opt/redis/conf`目录：

```bash
mkdir -p /opt/redis/conf
```

3\. 下载Redis配置文件到上面的目录中，执行如下命令：

```bash
wget -P /opt/redis/conf/ https://source.icode504.com/data/conf/redis/redis.conf
```

这个配置文件中一共修改了4个地方：

- 将第259行的修改为可以后台运行`daemonize yes`；
- 第94行的保护模式`protect-mode`的值改为了no；
- 将第75行默认只能本机访问的`bind 127.0.0.1 -::1`注释掉，改成所有IP都可以访问Redis；
- 第903行访问Redis需要输入密码，默认是123456

4\. 根据第1步拉取的镜像创建Redis容器：

```bash
docker run -p 6379:6379 -d\
 		--privileged=true\
 		-v /opt/redis/conf/redis.conf:/etc/redis/redis.conf\
 		-v /opt/redis/data:/data\
 		--name redis\
 		redis:6.0.10
```

5\. 查看所有容器的运行情况：

```bash
docker ps -a
```

此时我们发现redis正常运行：

![](https://source.icode504.com/images/image-20240725213246978.png)

6\. 进入到容器（`/bin/bash`命令行方式），执行如下命令：

```bash
docker run -it redis /bin/bash
```

7\. 此时我们进入了Redis容器的内部，接下来我们来既可以使用客户端：

```bash
redis-cli
```

此时左侧提示变为`127.0.0.1:6379`：

![](https://source.icode504.com/images/image-20240725222722661.png)

8\. 执行如下命令，如果返回结果是PONG，就说明我们的Redis可以正常使用了：

![](https://source.icode504.com/images/image-20240725173708679.png)

9\. 退出Redis客户端，执行如下任意一个命令：

```bash
exit
quit
```

10\. 退出当前Docker容器，执行如下命令：

```bash
exit
```

# 方式二：源码安装

## 一、准备操作

1\. 请根据自己的操作系统，安装以下软件，如果里面的软件你已经安装可以直接跳过：


|                            |                      Windows                      |                       macOS                       | 说明                                                                                                               |
| -------------------------- | :------------------------------------------------: | :------------------------------------------------: | ------------------------------------------------------------------------------------------------------------------ |
| 解决Github国内无法访问问题 | [点我查看](https://www.icode504.com/posts/25.html) | [点我查看](https://www.icode504.com/posts/80.html) | 本文需要下载的软件在Github上，目前国内访问Github访问速度较慢，推荐大家看一下本文教程，可以模仿文中的方式下载安装包 |
| Neat Download Manager      | [点我查看](https://www.icode504.com/posts/24.html) | [点我查看](https://www.icode504.com/posts/24.html) | 本文所需要的软件下载源在国外，使用此软件可以加快下载速度。                                                         |
| Electerm                   | [点我查看](https://www.icode504.com/posts/47.html) |                      敬请期待                      | 一款比较好用的通过SSH远程连接Linux的工具，支持Windows/macOS以SFTP的方式传输文件                                    |

2\. 打开Electerm并连接Linux服务器后，执行如下命令查看操作系统信息：

```bash
uname -a
```

这里我使用的是Debian操作系统：

![](https://source.icode504.com/images/image-20240725214016476.png)

3\. 根据所在的操作系统，安装如下的依赖：

- CentOS

```bash
yum -y install gcc-c++ make vim
```

- Ubuntu/Debian

```bash
apt -y install gcc-c++ make vim
```

## 二、下载Redis安装包

1\. 打开Redis官方Github仓库：[点我查看](https://github.com/redis/redis/tags)

2\. 这里我下载的是6.2.14版本的Redis，点击进入：

![](https://source.icode504.com/images/image-20240722215142941.png)

3\. 在下方Assets中鼠标右键点击`.tar.gz`结尾的安装包，然后点击**复制链接地址**：

![](https://source.icode504.com/images/image-20240722215323382.png)

4\. 点击右侧链接打开Github加速站：[点我查看](https://moeyy.cn/gh-proxy)

> 说明：如果这个加速网站失效，请到第一部分《准备操作》中的Github加速教程中寻找可加速的网站地址！

5\. 将前面复制的链接地址粘贴到此处，点击**下载**：

![](https://source.icode504.com/images/image-20240722215812500.png)

6\. 打开Electerm并连接到远程Linux服务器，点击左上角的SFTP，在左侧找到本地下载好的Redis安装包，

![](https://source.icode504.com/images/image-20240722220910319.png)

![](https://source.icode504.com/images/image-20240722221051181.png)

7\. 按照下图所示操作，将Redis安装包传输到Linux端：

![](https://source.icode504.com/images/240722001.gif)

8\. 此时Linux端有一个Redis安装包，我们再点击左上角SSH，返回命令行：

![](https://source.icode504.com/images/image-20240722221409176.png)

9\. 执行`ls`命令即可查看当前目录下的文件，此时我们发现Redis安装包也在此目录下：

![](https://source.icode504.com/images/image-20240722221541947.png)

10\. 解压这个安装包，执行如下命令：

```bash
tar -zxvf redis-6.2.14.tar.gz
```

11\. 在执行一遍`ls`命令，可以看到解压后的文件夹：

![](https://source.icode504.com/images/image-20240722221732124.png)

12\. 进入`redis-6.2.14`目录下，执行如下命令：

```bash
cd redis-6.2.14
```

13\. 执行如下命令，对源码进行编译和安装，这一过程消耗的时间教程，请耐心等待（预计需要5分钟）：

```bash
make && make install
```

14\. 出现下面的提示后，说明Redis已经安装成功：

![](https://source.icode504.com/images/image-20240725100221971.png)

## 三、修改Redis配置文件

1\. （当前位置：解压后的redis文件夹）执行`ls`命令，我们可以看到当前文件夹下有一个`redis.conf`文件，这个文件是Redis的配置文件，我们需要将其复制到Redis安装位置下：

![](https://source.icode504.com/images/image-20240725100556725.png)

2\. Redis的安装位置在`/usr/local/bin`目录下，我们需要切到这个目录下，执行如下命令：

```bash
cd /usr/lobal/bin
```

3\. （当前位置：Redis安装目录）在这个目录下创建一个文件夹`redis-config`用于存放Redis配置文件，执行如下命令：

```bash
mkdir redis-config
```

4\. 将配置文件redis.conf复制到redis-config目录下：

```bash
cp ~/redis-6.2.14/redis.conf /usr/local/bin/redis-config/
```

5\. 使用vim命令修改复制的redis.conf文件：

```bash
vim redis-config/redis.conf
```

6\. 执行如下命令并回车显示行号：

```bash
:set nu
```

![](https://source.icode504.com/images/image-20240725111632228.png)

7\. 执行如下命令并按一下回车（按<kbd>N</kbd>键查找下一个，按<kbd>P</kbd>查找上一个），查找Redis后台运行相关配置：

```bash
/daemonize
```

在259行，Redis默认是不能后台运行，即`damonize no`，我们需要将no改为yes，将其更改为能后台运行：

![](https://source.icode504.com/images/image-20240725112834580.png)

按<kbd>i</kbd>进入编辑模式（左下角会有INSERT提示），将这个地方改成yes（如下图），修改完成后按一下<kbd>Esc</kbd>键退出编辑模式：

![](https://source.icode504.com/images/image-20240725113130945.png)

8\. 执行如下命令并按一下回车（按<kbd>N</kbd>键查找下一个，按<kbd>P</kbd>查找上一个），查找Redis保护模式：

```bash
/protected-mode
```

在94行，Redis默认开启了保护模式，即`protect-mode yes`，我们需要将yes改为no，保证后续其他的客户端也能连接到Redis：

![](https://source.icode504.com/images/image-20240725113635641.png)

按<kbd>i</kbd>进入编辑模式（左下角会有INSERT提示），将这个地方改成no（如下图），修改完成后按一下<kbd>Esc</kbd>键退出编辑模式：

![](https://source.icode504.com/images/image-20240725114022138.png)

9\. 执行如下命令并按一下回车（按<kbd>N</kbd>键查找下一个，按<kbd>P</kbd>查找上一个），查看Redis所绑定的ip：

```bash
/bind
```

在75行，Redis默认只允许本机访问，其他IP在访问都会被拒绝，这里为了演示，我将第75行的代码注释掉，让所有IP都可以访问到Redis服务端：

> 说明：上述做法只适合学习环境中使用。在生产环境中，bind后面只能填写一个或多个可以访问到redis的IP地址。

![](https://source.icode504.com/images/image-20240725114711153.png)

按<kbd>i</kbd>进入编辑模式（左下角会有INSERT提示），将第75号注掉，修改完成后按一下<kbd>Esc</kbd>键退出编辑模式：

![](https://source.icode504.com/images/image-20240725115136412.png)

10\. 执行如下命令并按一下回车（按<kbd>N</kbd>键查找下一个，按<kbd>P</kbd>查找上一个），查看访问Redis是否需要密码访问：

```bash
/requirepass
```

在903行，这段配置默认是被注掉的，说明不需要密码也可以访问到Redis服务器。处理安全考虑，我们需要为Redis访问设置密码：

![](https://source.icode504.com/images/image-20240725115520187.png)

按<kbd>i</kbd>进入编辑模式（左下角会有INSERT提示），将第903号注释去掉，为了方便记忆，我将密码设置为123456，修改完成后按一下<kbd>Esc</kbd>键退出编辑模式：

![](https://source.icode504.com/images/image-20240725115705245.png)

11\. 上述配置完成后，输入<kbd>:wq</kbd>命令保存并退出。

## 四、启动Redis

1\. （当前位置：Redis安装目录`/usr/lobal/bin`）启动Redis服务端（后台启动）：

```bash
redis-server redis-config/redis.com
```

此时命令行没有提示说明Redis启动成功，那么我们如何验证Redis是否在后台正常运行呢？使用如下命令即可查看Redis服务端是否正常运行：

```bash
ps -ef |grep redis|grep -v grep
```

这里我的Redis正常运行，使用6379号端口（Redis默认端口）：

![](https://source.icode504.com/images/image-20240725172804006.png)

2\. 连接到Redis服务端：

```bash
redis-cli
```

此时命令提示变成了`127.0.0.1:6379`：

![](https://source.icode504.com/images/image-20240725173225493.png)

3\. 由于前面我们设置了密码，我们需要使用下面的命令去登录且输入前面的密码：

```bash
auth 前面设置的密码
```

![](https://source.icode504.com/images/image-20240725173428604.png)

4\. 执行如下命令，如果返回结果是PONG，就说明我们的Redis可以正常使用了：

```bash
PING
```

![](https://source.icode504.com/images/image-20240725173708679.png)

5\. 退出Redis：使用下面任意一个命令都可以退出Redis客户端

```bash
exit
quit
```

## 五、关闭Redis

1\. 关闭单个的客户端命令：

```bash
redis-cli -a 密码 shutdown
```

2\. 关闭6379端口下的所有客户端：

```bash
redis-cli -p 6379 shutdown
```

## 六、卸载Redis（可选）

1\. 停止Redis服务：

```bash
redis-cli shutdown
```

2\. 删除`/usr/lobal/bin`目录下的所有和redis相关的文件

```bash
rm -rf /usr/lobal/bin/redis-*
```
