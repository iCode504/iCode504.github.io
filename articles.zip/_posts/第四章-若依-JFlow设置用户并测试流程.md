---
title: 第四章 若依-JFlow设置用户并测试流程
date: 2023-12-11 13:58:48
tags: [若依, JFlow]
description: 本文在完成流程模型和各节点的表单设计的基础上，使用若依框架来创建用户并分配角色和部门，实现部门员工请假逐级审批的过程。 
abbrlink: 21
category: [工作流框架, JFlow]
---

> 若依-JFlow框架如何拉取、配置并运行请查看这篇文章：[《第一章 若依-JFlow的配置与启动》](http://www.icode504.com/posts/15.html)
>
> 如何创建业务场景、流程图和单节点表单设计请查看这篇文章：[《第二章 若依-JFlow流程模型与单节点表单设计》](http://www.icode504.com/posts/16.html)
>
> 如何设置多节点的表单并检查流程，请查看这篇文章：[《第三章 若依-JFlow其他节点的表单设计和流程检查》](http://www.icode504.com/posts/17.html)

# 一、创建用户及相关信息

在正式进行测试之前，我们需要保证有相应的用户来执行我们前面设计的流程。

假设我们的岗位是程序员，属于研发部，我们至少需要两个角色：普通员工和开发组长。

1\. 点击左侧菜单：`系统管理-->用户管理`，在左上角点击**新增**，创建用户：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208135500591.png)

2\. 这里我创建了四个用户，小张、小李、小陈、小刘，它们的基本信息如下图所示（密码默认是123456）：

> 其中：小张是研发部门的一名普通员工，小李是研发部门的经理，小陈是人事部门的总经理，小刘是公司的总经理。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208135738944.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208140240453.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208140558667.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208140735464.png)

# 二、测试请假流程

> 情景一：顺序执行
>
> 假设研发部员工小张今天有事需要请假，它需要填写请假单，到部门经理小李那边审批，小李通过审批以后，人事部门经理小陈继续审批申请单，审批以后，再流经总经理小刘进行审批，审批通过以后，小张即可查看请假单信息。

1\. 进入我们设计的流程图，在上方点击**测试运行**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208141202035.png)

2\. 点击小张，开始运行，此时表单中上方系统已经为我们自动加载了申请人的基本信息，不需要我们再填写了。填写后的内容如下所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208141713794.png)

3\. 点击左上角**发送**，在选择接收人界面中选择由部门经理小李。然后点击发送：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208141953776.png)

4\. 出现下面的信息，就说明已经成功向部门经理小李发送请假申请了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208142054478.png)

5\. 切换用户到小李，让小李执行任务

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208142136668.png)

6\. 假设小李默认选择同意，发送给人事经理小陈执行任务：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208151209317.png)

7\. 选择人事经理小陈并发送

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208151412103.png)

发送成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208151427486.png)

8\. 切换到人事经理小陈执行任务：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208151525891.png)

9\. 假设人事同意申请，就发送给总经理小刘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208151706251.png)

10\. 假设总经理也同意我们的申请：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208154107771.png)

11\. 点击发送以后，填写请假单的小张就会看到所有人的审批结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208154426432.png)

点击左上角的轨迹可以查看任意一个节点审批情况：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208154609844.png)

> 情景二：驳回场景
>
> 假设研发部员工小张今天有事需要请假，它需要填写请假单，到部门经理小李那边审批，小李通过审批以后，人事部门经理小陈继续审批申请单，但是给出了驳回理由，让xxx重新填写。

1\. 小张填写请假申请单，假设部门经理审批通过，到人事经理小陈进行审批，此时小陈点击驳回时需要填写驳回理由

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208155633882.png)

2\. 在左上角点击退回，退回节点选择员工填写请假单，并填写退回理由

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208160042749.png)

3\. 此时退回到小张那里，重新填写请假单

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208155922811.png)

4\. 切换到小张，重新填写请假单，此时会弹出一个提示信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208160144682.png)

5\. 重新填写表单信息，重新发送给人事经理并审批：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208160359210.png)

6\. 假设人事经理、总经理全部同意，那么我们再查看请假申请单时的轨迹图如下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231208160614626.png)

至此，请假的两种简单情况流程就执行完成了。

# 三、总结

我们在《第二章 若依-JFlow流程模型设计》中提到过，设计流程一共有五个步骤：

1. 绘制流程图：创建各个节点，并根据实际情况连结各个节点。
2. 设置接收人规则：每一个节点到底是有谁来执行任务，是某一个人还是某一个特定部门的人在执行，JFlow框架都已经为我们设置好了。
3. 设计表单：根据实际的业务设计表单，注意表单中的细节要和实际对应上。其他节点的表单可以引入上一个节点的，并再次基础上进行设计即可。
4. 检查流程：流程图和各个节点的表单设计完成后，最好检查一下流程，有错误可以及时更改。
5. 测试并运行该流程：测试过程中可以按角色所在部门一级一级审批，审批过程中可以对某个节点进行退回，每一个角色可以查看审批情况。

