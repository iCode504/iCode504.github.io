---
abbrlink: '101'
banner_img: https://source.icode504.com/images/image-02c32288e9a30d183144369e5c1c1827.png
categories:
- 开源框架
- 若依
- 常见问题
date: '2024-08-15T14:38:21.370+08:00'
description: 解决若依启动后，使用Apifox访问接口返回401的问题
index_img: https://source.icode504.com/images/image-02c32288e9a30d183144369e5c1c1827.png
order: ''
tags:
- Java
- 若依
- Apifox
title: 若依+Apifox实现接口测试（解决访问接口401问题）
updated: '2024-08-21T10:37:54.230+08:00'
---
在使用Apifox测试用户登录时，需要关闭验证码功能：[点我查看](https://www.icode504.com/posts/100.html)

# 一、问题复现

假设我们在若依框架的ruoyi-admin模块中编写了一个controller代码，已知端口号是8080：

```java
package com.ruoyi.data.controller;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 业务Controller
 *
 * @author iCode504
 * @date 2024-08-16
 */
@RestController
@RequestMapping("/data")
public class DataController extends BaseController {

    @GetMapping(value = "/getDataInfo")
    public AjaxResult getDataInfo() {
        return success("你好，我是iCode504，程序猿一枚，请多指教(●'◡'●)");
    }
}
```

我们在Apifox中对该接口进行测试时，响应结果很有可能会出现401的情况：

![](https://source.icode504.com/images/image-628598e7654d766dca652734cd2bd431.png)

# 二、问题分析

出现上述问题的主要原因是登录时返回的token并没有添加到接口实际的请求上：

![](https://source.icode504.com/images/image-51a6129a4ed2763f7b14a56ae89a5032.png)

# 三、解决方案

## 方式一：提取token（一劳永逸）

1\. 我们先找到用户登录接口，按照下图所示找到接口的后置操作：

![](https://source.icode504.com/images/image-d27008d23d0374a75ac9b270dff4c377.png)

2\. 添加后置操作中选择**提取变量**：

![](https://source.icode504.com/images/image-579fe89652657b0beb3b8cdbce403004.png)

3\. 按照下图填写相关信息，完成后按<kbd>Ctrl</kbd>+<kbd>S</kbd>键保存：

![](https://source.icode504.com/images/image-09584c12e4826795ab503e5725a2d91a.png)

4\. 在左侧找到根目录，按照下图所示填写全局Token，完成后按<kbd>Ctrl</kbd>+<kbd>S</kbd>键保存：

![](https://source.icode504.com/images/image-3778be6ce990e7f68a927267593ebad5.png)

5\. 此时重新登录，再次运行测试接口，此时我们就可以看到接口返回的数据了：

![](https://source.icode504.com/images/image-cb4ca24c8172b5ac4b19c5aa90ad2c95.png)

6\. 此时接口的实际请求中也包含登录时返回的token信息：

![](https://source.icode504.com/images/image-eeffaed26a4117bc798a961a131b53b7.png)

## 方式二：在接口方法上添加@Anoymous注解（临时使用）

> 注意：该方式只适用于开发环境中，请勿用于生产环境！

要想避开登录访问，可以在controller方法中添加@Anoymous注解，即匿名访问：

```java
package com.ruoyi.data.controller;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 业务Controller
 *
 * @author iCode504
 * @date 2024-08-16
 */
@RestController
@RequestMapping("/data")
public class DataController extends BaseController {

    @Anonymous      // 添加匿名访问注解
    @GetMapping(value = "/getDataInfo")
    public AjaxResult getDataInfo() {
        return success("你好，我是iCode504，程序猿一枚，请多指教(●'◡'●)");
    }
}
```

重新启动若依框架，此时到Apifox中对该接口进行测试，也可以看到返回结果：

![](https://source.icode504.com/images/image-8694746e2d2dbb6d2d44e79847eec214.png)
