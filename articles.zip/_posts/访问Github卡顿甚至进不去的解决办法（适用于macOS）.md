---
title: 访问Github卡顿甚至进不去的解决办法（适用于macOS）
tags:
  - NDM
  - Neat Download Manager
  - Watt tookit
  - Github
category:
  - 软件安装
  - macOS
  - 常用工具
category_bar: true
description: 本文使用Watt Tookit（原Steam++）解决了Github在国内访问速度卡顿甚至无反应的问题，通过NDM和镜像网站实现Github大文件高速下载。
abbrlink: 80
index_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/访问Github卡顿甚至进不去的解决办法（适用于Windows和MacOS）-封面.png
banner_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/访问Github卡顿甚至进不去的解决办法（适用于Windows和MacOS）-封面.png
date: 2024-07-20 10:13:02
---


# 一、前言

Github 是全球知名的开源宝库，但是对国内用户并不友好。当我们在浏览器中输入`www.github.com`时，如果你赶的时间点比较好可能会进去，但是大多数情况下浏览器不会对你的请求做出任何响应，就像下图这样：

![](https://source.icode504.com/images/image-20231229085526297.png)

那么，有什么办法解决这个问题呢？

# 二、访问 Github——Watt Tookit（原 Steam++）

官网介绍：Watt Tookit 是一个开源的跨平台的多功能 Stream 工具箱，它可以管理你 Steam 游戏库存，监控 Steam 游戏下载进度实现自动定时关机等功能。本文要介绍的是它的网络加速功能，它内部添加了 Github 网络加速功能。

原作者在 B 站有账号，感兴趣的小伙伴可以关注支持一下：[点我传送到 B 站](https://space.bilibili.com/3546572635768935)

接下来我们就来安装一下 Watt Tookit：

1\. 点击右侧链接进入官网：[点我进入官网](https://steampp.net/)

2\. 根据自己的操作系统下载，这里我使用的是 macOS 版本，点击下载按钮：

![](https://source.icode504.com/images/image-20240720123429084.png)

3\. 此时会弹出一个 GNU 通用公共许可证协议，点击右下角**接受并下载**：

![](https://source.icode504.com/images/image-20231229091615168.png)

4\. 官方为我们提供多个下载渠道，这里我点击左下角Nas分流（德国）下载链接：

![](https://source.icode504.com/images/image-20240720125053299.png)

5\. 进入后，点击最新版本：

![](https://source.icode504.com/images/image-20240720125252862.png)

6\. 选择Mac版本的文件夹：

![](https://source.icode504.com/images/image-20240720125357620.png)

7\. 选中这个文件，点击右上角的**下载**：

![](https://source.icode504.com/images/image-20240720125531721.png)

8\. 双击打开安装包，按照下图所示操作，将Steam++拖入到应用程序：

![](https://source.icode504.com/images/240720001.gif)

9\. 等待一段时间后，软件安装完成，找到Steam++并打开：

![](https://source.icode504.com/images/image-20240720130155688.png)

10\. 此时会系统会弹出一个错误：无法打开“Steam++”，因为它来自身份不明的开发者。点击窗口下方**好**：

![](https://source.icode504.com/images/image-20240720130427359.png)

11\. 点击左上角苹果logo，然后点击**系统设置**：

![](https://source.icode504.com/images/image-20240224155139125.png)

12\. 点击**左侧隐私与安全性**，向下找安全性中有一个提示信息：已阻止使用“Steam++”，因为它来自身份不明的开发者。点击提示信息下方的**仍要打开**：

![](https://source.icode504.com/images/image-20240720130839492.png)

13\. 输入本机的用户名和密码，完成后点击**修改设置**：

![](https://source.icode504.com/images/image-20240224155514630.png)

14\. 此时会弹出如下的提示信息，点击**打开**：

![](https://source.icode504.com/images/image-20240720131206774.png)

15\. 打开后，按照下图所示操作完成对Github的配置：

![](https://source.icode504.com/images/image-20240720133958064.png)

16\. 为了避免每次启动和关闭加速需要输入密码，打开终端执行如下命令：

```bash
sudo chmod 666 /etc/hosts
```

输入本机用户密码（密码不在终端中显示），完成后按一下回车：

![](https://source.icode504.com/images/image-20240720133727253.png)

17\. 切回到Watt Tookit，点击一键加速，此时Github的加速已经成功开启：

![](https://source.icode504.com/images/image-20240720134347410.png)



11\. 此时在浏览器再次访问[Github](https://www.github.com)，就可以正常显示页面了。虽然访问速度还是慢，但是总比响应超时啥也不显示的强：

![](https://source.icode504.com/images/image-20231229101555911.png)

此时我们使用`git clone`命令拉取仓库代码，或者是使用`git push`命令将代码推送到我们的 Github 仓库就不会因为网络问题而无法进行操作的问题了。

# 三、下载 Github 中的内容

Github 有很多优秀的开源作品可以下载，如果是大文件使用浏览器，等到猴年马月都下载不完（下载速度真的是太慢了），以下是使用 NDM 和 Github 加速网站下载 Github 的内容的实现步骤。

这里我想下载 Google 家的 Noto Serif 全语言字体包（[点我查看源网站](https://github.com/notofonts/noto-cjk/releases)），文件大小 600M 左右，如果正常使用浏览器下载非常慢，接下来我们就使用 NDM+Github 加速网站解决上述问题。

> 本文后续内容使用 NDM（Neat Download Manager）下载文件，如需使用此款软件的小伙伴，可以查看这篇教程：[下载神器 NDM（Neat Download Manager）安装配置教程（适用于 Windows 和 MacOS）](https://www.icode504.com/posts/24.html)

![](https://source.icode504.com/images/image-20240720135903758.png)

3\. 首先，我们对要下载的文件，鼠标右键**复制链接**：

![](https://source.icode504.com/images/image-20240720140012891.png)

4\. 以下是我整理的 Github 镜像网站，大家任选一个链接进入即可，这里我选择第一个网站进入：

| 网站名称        | 链接                      |
| --------------- | ------------------------- |
| Github 镜像站 1 | https://gitdl.cn/         |
| Github 镜像站 2 | https://moeyy.cn/gh-proxy |
| Github 镜像站 3 | https://github.zhlh6.cn/  |

5\. 将上面复制的链接粘贴到输入框中，点击下载即可

![](https://source.icode504.com/images/image-20231229103230888.png)

6\. 使用 NDM，下载速度直接原地起飞：

![](https://source.icode504.com/images/image-20240720135740502.png)
