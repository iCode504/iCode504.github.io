---
abbrlink: '111'
banner_img: https://source.icode504.com/images/9a9d36168bc0568b80b055f25568101c.png
categories:
- 软件安装
- Windows
- 服务注册和配置中心
date: '2024-10-08T14:13:25.873421+08:00'
description: 本教程介绍了在Windows上安装Consul的步骤，包括下载、启动Consul服务。
index_img: https://source.icode504.com/images/9a9d36168bc0568b80b055f25568101c.png
order: ''
tags:
- Windows
- Consul
title: Consul安装配置教程（Windows版）
updated: '2024-10-08T15:48:21.286+08:00'
---
Consul 是一个开源的分布式服务发现和配置管理工具，主要用于支持微服务架构。它提供了服务发现、健康检查、键值存储、分布式锁、以及多数据中心的服务网格功能。通过 Consul，服务可以动态注册和发现彼此，无需手动配置 IP 地址或端口，同时能够自动执行健康检查，确保只将健康的服务实例注册到集群中。此外，Consul 还支持一致性哈希的分布式键值存储，用于配置共享和动态更新，广泛应用于微服务、云原生架构中。

以下是Windows环境下Consul安装和配置教程。

# 一、下载Consul

1\. 点击右侧链接进入官网下载页：[点我查看](https://developer.hashicorp.com/consul/downloads)

2\. 选择你要安装的版本，新手小白可以跳过这一步：

![](https://source.icode504.com/images/23dc2e97e8517c0899ac02bfd3195710.png)

3\. 在下方找到Windows操作系统，根据自己的电脑的操作系统位数下载Consul。这里我的电脑是64位的操作系统，点击红色链接下载：

<details>
<summary>如何查看自己的电脑是32位还是64位？</summary>
<br>
<ul>
<li>按<kbd>Win</kbd>和<kbd>R</kbd>，输入<code>cmd</code>并按一下回车，进入命令行界面。</li>
<li>执行如下命令，查看当前操作系统的信息：</li>

</ul>


```powershell
systeminfo
```

![](https://source.icode504.com/images/2b462c49d961e5b4aa5d7b8218996b13.png)

</details>

![](https://source.icode504.com/images/3aac2bbfb580aa063b2e7747ca23e37c.png)

# 二、安装并启动Consul

1\. 将下载好的Consul安装包解压到你熟悉的位置且只包含英文路径，这里我解压到了D盘的Environment目录下：

![](https://source.icode504.com/images/45448112151373a7252351b028b018a5.png)

![](https://source.icode504.com/images/7fc316d64b698afa6e6d028af55979d0.png)

2\. 进入解压后的目录，点击上方路径，输入 `cmd`并回车，进入命令行界面：

![](https://source.icode504.com/images/89028e0b5055bda019a0d3b0ca07d587.png)

3\. 输入 `consul -version`，如果可以查看当前Consul版本信息，就说明Consul配置成功：

![](https://source.icode504.com/images/ce7e130f51e7e02fb65050fbd6b98c4e.png)

4\. 通过开发模式启动Consul：

```powershell
consul agent -dev
```

5\. 打开浏览器，在上方搜索框输入 `http://localhost:8500`即可访问Consul，如果出现如下页面就说明Consul启动成功！

![](https://source.icode504.com/images/7daee3a472c39d15f88338bf3d87b89b.png)

