---
abbrlink: '105'
banner_img: https://source.icode504.com/images/数据库管理软件DBeaver安装、配置和卸载教程（Windows版）.png
categories:
- - DBeaver
date: '2024-08-23T15:13:31.883964+08:00'
description: DBeaver加快依赖下载速度
index_img: https://source.icode504.com/images/数据库管理软件DBeaver安装、配置和卸载教程（Windows版）.png
order: ''
tags:
- DBeaver
title: DBeaver加快依赖下载速度
updated: '2024-08-23T15:38:32.195+08:00'
---
需要安装DBeaver的小伙伴根据自己所在的操作系统查看安装教程：


|                      Windows                      |                       macOS                       |
| :------------------------------------------------: | :------------------------------------------------: |
| [点我查看](https://www.icode504.com/posts/77.html) | [点我查看](https://www.icode504.com/posts/81.html) |

我们在使用DBeaver连接数据库的时候，可能会需要到Maven中央仓库下载一些依赖（JAR包），但是中央仓库服务器在国外，对于国内用户下载不一定友好：

![](https://source.icode504.com/images/image-29db969146c7cf2a81bf0eadec186213.png)

要想解决上述问题，只需要将下载源改为国内的镜像源，这里我使用的阿里云镜像源。以下是修改镜像源的教程：

1\. 复制下面的链接地址：

```
http://maven.aliyun.com/nexus/content/groups/public/
```

2\. 在上方菜单找到**窗口** --> **首选项**，进入设置页面：

![](https://source.icode504.com/images/image-990a04be1d839a7e51c3c3ab0028c077.png)

3\. 在左侧菜单上方的搜索框搜索Maven，然后点击右侧的**添加**：

![](https://source.icode504.com/images/image-ea0e0efaccd7f60934db5e95ea8349ab.png)

4\. 将第1步中复制的链接地址粘贴到此处，完成后点击确定：

![](https://source.icode504.com/images/image-4c5896454e65e5368fde581f7d708d0e.png)

5\. 选中新添加的链接，点击右侧的**向上**，将这个链接置顶，完成后点击右下角**应用并关闭**：

![](https://source.icode504.com/images/image-60144dd59bd7a4a9a229ebbbc5bdc1e0.png)

6\. 此时配置完数据库以后，再次点击测试连接时，下载依赖使用的国内的镜像源，下载速度比较快：

![](https://source.icode504.com/images/image-d110c55820a47a9214aa3ee801c86ac3.png)
