---
abbrlink: '112'
banner_img: https://source.icode504.com/images/Linux Debian安装配置教程.png
categories:
- 常用操作
- Windows
- Debian
date: '2024-10-11T16:11:31.616326+08:00'
description: Debian虚拟机修改静态IP
index_img: https://source.icode504.com/images/Linux Debian安装配置教程.png
order: ''
tags:
- Debian
title: Debian修改静态IP
updated: '2024-10-11T17:01:49.211+08:00'
---
# 一、准备操作

需要在VMware安装Debian虚拟机的小伙伴，点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/52.html)

使用云服务器的小伙伴不需要看下面的配置哦(ᕑᗢᓫ∗)˒

# 二、VMware相关操作

1\. （虚拟机处于关机状态）在未开启Debian虚拟机之前，按照下图所示打开虚拟机的网络设置：

![](https://source.icode504.com/images/30f37dbd371b7ac93ce756d1b7424f60.png)

2\. 点击右下角的**更改设置**：

![](https://source.icode504.com/images/a7cb64c3b9c6396a8370e31f03a45e51.png)

3\. 进入编辑模式后，上方的虚拟网络选中VMnet8（NAT模式）：

![](https://source.icode504.com/images/020ceab236d61c0341c80ade96ebdf49.png)

4\. 按照下图所示修改子网IP，修改的数值范围在**0\~255**之间，我修改后的子网IP为192.168.40.0：

![](https://source.icode504.com/images/5fe139fec7dde3d798a240acbb2ff10a.png)

5\. 点击右下角的**DHCP设置**：

![](https://source.icode504.com/images/b28c1b878fca3e76e9038f66cc3d28be.png)

6\. 按照下图操作修改网段，完成后一路点击确定，虚拟网络配置完成。

![](https://source.icode504.com/images/2475fa8817e27d03b932c28866ba886a.png)

# 三、Debian修改静态IP

1\. 开启Debian虚拟机，执行如下命令查看当前虚拟机的IP地址：

```bash
ip addr
```

这里我的虚拟机IP地址是192.168.40.5，接下来我将这个IP修改为静态IP，192.168.40.100：

![](https://source.icode504.com/images/6b5a474d812bedc220d46e12d2bd045e.png)

2\. Debian关于网络IP的配置在`/etc/network/interfaces`文件中，使用Vim编辑这个文件：

```bash
vim /etc/network/interfaces
```

3\. 输入`:set nu`可以查看行号，此时我们看到未修改之前为动态IP：

![](https://source.icode504.com/images/c2a15482c33771fd577823fc2bdb34ac.png)

4\. 按<kbd>I</kbd>键进入编辑模式，将最后两行代码注掉，效果图如下：

![](https://source.icode504.com/images/1fdb92edb1735377e9f8d6eaf864b158.png)

5\. 另起一行，输入如下内容：

```bash
auto ens33
iface ens33 inet static    # 修改为静态ip
address 192.168.40.100     # 其中40要和前面自定义的要保持一致，100可以设置其他数字（0~255之间）
netmask 255.255.255.0
gateway 192.168.40.2       # 其中40要和前面自定义的要保持一致
```

修改后的效果如下图：

![](https://source.icode504.com/images/18d2853a81e652f845b66fea032effad.png)

6\. 按<kbd>Esc</kbd>键退出编辑模式，输入`:wq`保存并退出。

7\. 执行如下命令重新启动网络服务：

```bash
sysmctl restart networking
```

8\. 执行如下命令重新启动：

```bash
reboot
```

9\. 再次执行`ip addr`命令，发现IP已经变为192.168.40.100：

![](https://source.icode504.com/images/0e1f4c2e2b46f3741147273a970ea6c0.png)

10\. 此时我们ping一下百度也有响应，至此，Debian成功修改为静态IP并且可以访问外网：

```bash
ping www.baidu.com
```

![](https://source.icode504.com/images/dc1fead36b500490bd96dd65104a6b65.png)
