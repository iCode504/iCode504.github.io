---
abbrlink: '75'
archive: false
banner_img: https://source.icode504.com/images/Docker安装和配置教程（Linux CentOS版）.png
categories:
- 软件安装
- Linux
- 容器化
- Docker
category_bar: true
date: '2024-06-22T15:53:12+08:00'
description: 本教程详细介绍了在Linux Ubuntu系统上安装和配置Docker的步骤，包括安装前的准备工作、安装Docker、启动和测试容器等内容，帮助用户快速上手Docker。
index_img: https://source.icode504.com/images/Docker安装和配置教程（Linux CentOS版）.png
order: ''
password: null
tags:
- Docker
- Linux
- Ubuntu
- Debian
title: Docker安装和配置教程（适用于Linux Ubuntu和Debian）
updated: '2024-12-27T13:57:06.514+08:00'
---
Docker 是一种开源的平台，用于开发、运输和运行应用程序。它通过将应用程序及其依赖项打包在一个可移植的容器中，使得应用程序可以在任何环境中一致地运行。Docker 容器利用了操作系统的虚拟化技术，相比传统的虚拟机更加轻量级、高效。开发人员可以在本地构建和测试容器，然后将其部署到生产环境，确保环境一致性和快速部署。Docker 极大地简化了应用程序的开发和运维流程，提高了工作效率和系统的可扩展性。

以下是 Linux Ubuntu 和 Debian 系统环境下 Docker 的安装和配置教程：

# 一、安装前操作

1\. 需要安装 Ubuntu 或 Debian 操作系统的小伙伴，请根据自己的需要点击下方链接查看安装教程：


| 系统/软件名称 |       安装教程       |
| :-----------: | :-------------------: |
|    Ubuntu    | [点我查看](./51.html) |
|    Debian    | [点我查看](./52.html) |
|   Electerm   | [点我查看](./47.html) |

2\. 执行如下命令可以查看当前操作系统信息，这里我使用的 Ubuntu 操作系统：

```bash
uname -a
```

![](https://source.icode504.com/images/image-20240623105752873.png)

3\. 如果你要安装新版本的 Docker，需要将系统中安装的旧版本 Docker 卸载。执行如下命令卸载 Docker：

```bash
for pkg in docker.io docker-doc docker-compose docker-compose-v2 podman-docker containerd runc; do sudo apt-get remove $pkg; done
```

4\. 删除以前在 Docker 安装的镜像、容器等文件：Docker 在卸载过程中默认不会删除原来下载的镜像文件，它们默认存储在`/var/lib/docker`中，如果需要删除这些残留文件，可以执行如下命令：

```bash
rm -rf /var/lib/docker/
```

5\. 安装一些必要的工具，执行如下命令：

```bash
apt-get -y update
apt-get -y install vim apt-transport-https ca-certificates curl software-properties-common gpg-agent
```

# 二、安装 Docker

接下来我们就可以安装 Docker 了，这里我使用的是`apt-get`方式安装 Docker。

1\. 根据自己的操作系统，执行如下命令添加 Docker 官方 GPG key：

- Ubuntu

```bash
curl -fsSL https://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | sudo apt-key add -
```

- Debian

```bash
curl -fsSL https://mirrors.aliyun.com/docker-ce/linux/debian/gpg | sudo apt-key add -
```

2\. 根据自己的操作系统，写入软件源信息：

- Ubuntu

```bash
sudo add-apt-repository "deb [arch=amd64] https://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable"
```

- Debian

```bash
sudo add-apt-repository "deb [arch=amd64] https://mirrors.aliyun.com/docker-ce/linux/debian $(lsb_release -cs) stable"
```

按一下回车键继续：

![](https://source.icode504.com/images/image-20240623111157253.png)

3\. 更新软件包列表，执行如下命令：

```bash
sudo apt-get -y update
```

3\. 执行如下命令安装 Docker（下载安装的时间可能会较长，请耐心等待！）：

```bash
sudo apt-get -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

4\. 安装完成后，执行如下命令即可查看 Docker 版本信息：

```bash
docker version
```

![](https://source.icode504.com/images/image-20240623094637000.png)

# 三、配置镜像加速器

以下两种方式任选其一：

## 方式一：配置镜像源（可能拉取不了最新版本镜像）

> 说明：镜像加速器面向个人开发者，仅适用于个人开发场景，**请勿用于商业用途**！

我们使用 Docker 创建容器的时候，首先需要获取镜像，如果本地存在镜像就是用本地的镜像创建容器，如果本地不存在这个镜像，就需要到官方镜像仓库中下载镜像，但是官方镜像国内无法访问（除非你有特殊的方法）。为了解决上述问题，我们需要配置国内镜像加速器，这里我使用的阿里云的镜像加速器，确保后续能顺利拉取镜像。以下是配置阿里云镜像加速器教程：

1\. 打开阿里云官网，注册一个阿里云账号（使用钉钉、支付宝、淘宝登录都 OK，毕竟它们都是一家的）：[点我登录/注册](https://account.aliyun.com/login/login.htm)

2\. 登陆后，在主页面搜索**容器镜像服务**，点击进入：

![](https://source.icode504.com/images/image-20240623100827340.png)

3\. 点击**管理控制台**：

![](https://source.icode504.com/images/image-20240623100914010.png)

4\. 进入控制台，在左侧菜单栏单机镜像加速器，此时页面中有一给个人的加速器地址，点击**复制**：

![](https://source.icode504.com/images/image-20240623101441310.png)

5\. 回到命令行界面，我们使用 vim 命令，在`/etc/docker`目录下创建一个 daemon.json 文件，执行如下命令：

```bash
sudo vim /etc/docker/daemon.json
```

6\. 按<kbd>i</kbd>键进入编辑模式（此时命令行左下角会有一个 INSERT 的提示），编写如下内容：

```json
{
	"registry-mirrors": [""]
}
```

效果图如下：

![](https://source.icode504.com/images/image-20240623102231989.png)

7\. 将光标移动到两个中括号内部的双引号中，按<kbd>Shift</kbd><kbd>Insert</kbd>键粘贴前面复制的镜像加速器地址，效果图如下：

![](https://source.icode504.com/images/image-20240623102402464.png)

8\. 检查无误后，按<kbd>Esc</kbd>键退出编辑模式，输入<kbd>:wq</kbd>（左下角有提示）并按一下回车保存并退出编辑。

9\. 依次执行如下命令重新加载 daemon 和 Docker：

```bash
sudo systemctl daemon-reload
sudo systemctl restart docker
```

## 方式二：通过Github拉取Dockerhub镜像并推送到阿里云

该方案请点击右侧链接查看具体教程：[点我查看](./113.html)

# 四、Docker 的简单使用

1\. 使用`systemctl`命令启动 Docker：

```bash
sudo systemctl start docker
```

2\. 运行`hello-world`镜像，执行如下命令：

```bash
sudo docker run hello-world
```

执行这个命令时，首先去本地寻找是否存在 hello-world 镜像，如果没有，就去镜像仓库拉取（下载）Docker 镜像，拉取完成后会创建一个容器，此时 Docker 会运行这个容器并在控制台输出结果：

![](https://source.icode504.com/images/image-20240623102936551.png)

3\. （可选）如果想让 Docker 开机自启动，可以执行如下命令：

```bash
sudo systemctl enable docker
```

4\. （可选）如果禁用 Docker 开机自启动，可以执行如下命令：

```bash
sudo systemctl disable docker
```

5\. （可选）如果想停止 Docker，可以执行如下命令：

```bash
sudo systemctl stop docker
```

# 五、卸载 Docker（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{% endnote %}

1\. 执行下面命令，卸载 Docker：

```bash
sudo apt-get -y purge docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin docker-ce-rootless-extras
```

2\. 卸载时，镜像和容器文件默认不会删除，如果需要删除这些文件，请依次执行如下命令：

```bash
sudo rm -rf /var/lib/docker
sudo rm -rf /var/lib/containerd
```
