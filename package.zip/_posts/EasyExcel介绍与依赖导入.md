---
title: EasyExcel介绍与依赖导入
tags:
  - EasyExcel
category_bar: true
archive: false
abbrlink: 58
description: 本文简要介绍了EasyExcel的优势，并创建了Maven/Gradle项目，并导入相关的依赖
banner_img: https://source.icode504.com/images/EasyExcel使用教程.png
index_img: https://source.icode504.com/images/EasyExcel使用教程.png
category:
  - 文档操作
  - EasyExcel
  - 使用EasyExcel将数据写入到Excel文件
date: 2024-03-18 11:44:56
password:
---


# 一、EasyExcel介绍

EasyExcel是由阿里巴巴一款开源的读写Excel项目，和Apache POI相比，它的最大优势就是在尽可能节省内存的情况下支持读写百兆的Excel，目前维护的版本是3.1.x-3.2.x（截止到2024年3月），更多内容说明可以到官网查看：[点我进入官网](https://easyexcel.opensource.alibaba.com/)

![16M内存23秒读取了75M（46W行25列）的Excel](https://source.icode504.com/images/large-20799fd0a966e90931a35cbfff69253d.png)

# 二、创建项目

1\. 请确保电脑上已经安装如下软件：

- Java开发工具：JDK
- 集成开发环境：Intellij IDEA或者Eclipse
- 项目构建工具：Maven或者Gradle

需要安装的小伙伴根据自身操作系统查看安装教程：

|               |                      Windows                       |  macOS   |                       Linux                        |
| :-----------: | :------------------------------------------------: | :------: | :------------------------------------------------: |
|     JDK 8     | [点我查看](https://www.icode504.com/posts/1.html)  | 敬请期待 | [点我查看](https://www.icode504.com/posts/55.html) |
| Intellij IDEA | [点我查看](https://www.icode504.com/posts/10.html) | 敬请期待 |                        暂无                        |
|    Eclipse    | [点我查看](https://www.icode504.com/posts/30.html) | 敬请期待 |                        暂无                        |
|     Maven     | [点我查看](https://www.icode504.com/posts/19.html) | 敬请期待 | [点我查看](https://www.icode504.com/posts/56.html) |
|    Gradle     | [点我查看](https://www.icode504.com/posts/20.html) | 敬请期待 | [敬请期待](https://www.icode504.com/posts/57.html) |

2\. 打开Intellij IDEA，创建一个项目：

> 以下提供了Maven和Gradle两种方式创建项目，任选其一创建项目即可。

|                        Maven构建项目                         |                        Gradle构建项目                        |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| ![](https://source.icode504.com/images/image-20240305172709416.png) | ![image-20240305173309106](https://source.icode504.com/images/image-20240305173309106.png) |
| ![](https://source.icode504.com/images/image-20240305173055254.png) | ![](https://source.icode504.com/images/image-20240305173055254.png) |

3\. 导入依赖（这里我使用的是3.1.1版本）

- pom.xml

```xml
<!-- easyexcel -->
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>easyexcel</artifactId>
    <version>3.1.1</version>
</dependency>

<!-- 日志框架slf4j -->
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-api</artifactId>
    <version>1.7.36</version>
</dependency>

<!-- lombok(简化getter/setter、构造器，仅推荐学习阶段使用) -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <version>1.18.24</version>
    <scope>provided</scope>
</dependency>

<!-- 测试工具Junit5 -->
<dependency>
    <groupId>org.junit.jupiter</groupId>
    <artifactId>junit-jupiter-api</artifactId>
    <version>5.8.2</version>
    <scope>test</scope>
</dependency>
```

- build.gradle

```groovy
implementation 'com.alibaba:easyexcel:3.1.1'
implementation 'org.slf4j:slf4j-api:1.7.36'
compileOnly 'org.projectlombok:lombok:1.18.24'
testImplementation 'org.junit.jupiter:junit-jupiter-api:5.8.2'
```

