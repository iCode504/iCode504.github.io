---
title: EasyExcel的表头操作
tags:
  - EasyExcel
category_bar: true
archive: false
abbrlink: 61
description: 本文使用EasyExcel代码实现了无表头数据的Excel文件导出和复杂表头的输出。
banner_img: https://source.icode504.com/images/EasyExcel使用教程.png
index_img: https://source.icode504.com/images/EasyExcel使用教程.png
category:
  - 文档操作
  - EasyExcel
  - 使用EasyExcel将数据写入到Excel文件
date: 2024-03-21 15:29:49
password:
---


[上一节](https://www.icode504.com/posts/60.html)我们使用EasyExcel框架的四种方式将数据输出到Excel文件中，实现了如下图的效果：

![](https://source.icode504.com/images/image-20240319160342595.png)

其中序号、员工号、员工姓名等是各个列的表头（灰色单元格），接下来这一部分我们要对表头进行相关操作。

# 一、输出无表头数据

> 案例：不输出表头，显示效果如下图所示：
>
> ![](https://source.icode504.com/images/image-20240320231754335.png)

EasyExcel框架中有一个类AbstractExcelWriterParameterBuilder，这是一个抽象类，在这个类中有一个方法`needHead`，参数是Boolean类型，如果传入的值是false就可以确保表头不再输出，以下是执行的代码：

```java
@Test
public void test() {
    String filePath = EmployeeUtils.getFilePath();
    EasyExcel.write(filePath, Employee.class)
            // 不输出表头
            .needHead(false)
            .sheet("测试工作表")
            .doWrite(EmployeeUtils.getDataList());
    System.out.println("数据成功写出到Excel文件中");
}
```

此时执行这段代码就不会出现表头信息，符合我们预期目标：

![](https://source.icode504.com/images/image-20240321102207670.png)

# 二、输出复杂表头

> 案例：输出的Excel文件表头如下图所示：
>
> ![](https://source.icode504.com/images/image-20240320113132026.png)

由上述表头我们发现员工信息表和其他属性（例如：序号、员工号等）是一对多的关系，为了更加直观地在代码中显示，我们需要将图中的关系进一步拆解一对一的关系：

```
员工信息表 --> 序号
员工信息表 --> 员工号
员工信息表 --> 员工姓名
员工信息表 --> 年龄
员工信息表 --> 性别
员工信息表 --> 生日
```

这样拆解以后，我们就可以在`@ExcelProperty`中使用`value`属性了，这个属性本身是一个字符串数组，要想发生类似上图表头合并，需要满足如下条件：

- 类中的属性之间必须相邻；
- 属性使用`@ExcelProprety`修饰并且注解中包含`value`属性（字符串数组）；
- 字符串数组中相同的索引值对应的字符串值完全相同。

根据上述内容，我们将实体类Employee属性中的注解做一点改动，代码如下：

```java
package com.icode504.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.*;

import java.util.Date;

/**
 * 员工--实体类
 *
 * @author iCode504
 * @date 2024-03-18
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {

    // 序号
    @ExcelProperty({"员工信息表","序号"})
    private Integer id;

    // 员工号
    @ExcelProperty({"员工信息表", "员工号"})
    private String employeeId;

    // 员工姓名
    @ExcelProperty({"员工信息表", "员工姓名"})
    private String employeeName;

    // 年龄
    @ExcelProperty({"员工信息表", "年龄"})
    private Integer age;

    // 性别（男/女）
    @ExcelProperty({"员工信息表", "性别"})
    private String gender;

    // 生日
    @ExcelProperty({"员工信息表", "生日"})
    private Date birthday;

    // 构造器、getter、setter已省略...
}
```

我们再运行一次EasyExcel代码来导出Excel文件：

```java
@Test
public void test() throws Exception {
    String filePath = EmployeeUtils.getFilePath();
    EasyExcel.write(filePath, Employee.class)
            .sheet("模板")
            .doWrite(EmployeeUtils.getDataList());
    System.out.println("数据成功写出到Excel文件中");
}
```

此时生成的表头符合案例的要求：

![](https://source.icode504.com/images/image-20240320224957864.png)

# 三、知识点总结

EasyExcel的表头操作的知识点总结如下图所示：

![](https://source.icode504.com/images/EasyExcel%E7%9A%84%E8%A1%A8%E5%A4%B4%E6%93%8D%E4%BD%9C.svg)
