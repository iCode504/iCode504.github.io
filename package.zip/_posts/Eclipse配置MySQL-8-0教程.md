---
title: Eclipse配置MySQL 8.0教程
tags:
  - Eclipse
  - MySQL
category_bar: true
archive: false
abbrlink: 46
description: 本文介绍了如何在Eclipse集成开发环境中配置MySQL 8.0数据库。
banner_img: https://source.icode504.com/images/Eclipse配置MySQL 8.0教程.png
index_img: https://source.icode504.com/images/Eclipse配置MySQL 8.0教程.png
category:
  - Eclipse
  - MySQL
date: 2024-02-21 11:08:49
password:
---


请确保电脑本机已经安装MySQL和Eclipse，没有安装的小伙伴根据自己的操作系统点击下方链接查看安装教程（已经安装的小伙伴继续往下看）：

|           |                      Windows                       |                       macOS                        |  Linux   |
| :-------: | :------------------------------------------------: | :------------------------------------------------: | :------: |
| MySQL 8.0 | [点我查看](https://www.icode504.com/posts/18.html) | [点我查看](https://www.icode504.com/posts/68.html) | 敬请期待 |
|  Eclipse  | [点我查看](https://www.icode504.com/posts/30.html) |                      敬请期待                      |    -     |

- Windows检查MySQL安装版本：按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`并回车，在命令行中输入`mysql --version`，确保本机安装的MySQL版本在8.0及以上：


![](https://source.icode504.com/images/image-20240220151342379.png)

- macOS检查MySQL安装版本：如果你是按照上面的链接一步一步安装的MySQL。在安装完成后，重新打开终端，在终端中输入`mysql --version`，即可查看当前MySQL版本信息。

# 一、下载MySQL数据库驱动

1\. 点击右侧链接进入MySQL数据库驱动下载页面：[点我查看](https://downloads.mysql.com/archives/c-j/)

2\. 前面我们检查了MySQL是8.0.xx版本，数据库驱动建议选择8版本、操作系统我选择的是平台独立（Platform Independent）。选择完成后，点击下方ZIP压缩包下载：

![](https://source.icode504.com/images/image-20240221084519626.png)

3\. 将下载好的压缩包解压到一个你熟悉的位置，这里我解压到了D盘：

![](https://source.icode504.com/images/image-20240221084705705.png)

![](https://source.icode504.com/images/image-20240221084851937.png)

# 二、Eclipse配置MySQL

1\. 打开Eclipse，在上方菜单栏选择Window --> Show View --> Other：

![](https://source.icode504.com/images/image-20240131100443322.png)

2\. 双击打开**Data Management**，选择**Data Source Explorer**，完成后点击**Open**：

![](https://source.icode504.com/images/image-20240131100530658.png)

3\. 此时会弹出一个Data Source Explorer窗口，鼠标右键选中第一个**Database Connections**，点击**New**新建一个连接：

![](https://source.icode504.com/images/image-20240131102657948.png)

4\. 连接类型**选择MySQL并选中**，Name和Description自定义，完成后点击**Next**：

![](https://source.icode504.com/images/image-20240220154033412.png)

5\. 点击右上角**加号**修改数据库驱动和连接信息：

![](https://source.icode504.com/images/image-20240131103041407.png)

6\. 选中数据库驱动模板**MySQL JDBC Driver**，此时上方弹出一个错误信息：在本地系统中无法找到`mysql-connector-java-5.1.0-bin.jar`，这说明我们需要将Eclipse原有的数据库驱动改成前面我们下载安装的MySQL的JDBC：

![](https://source.icode504.com/images/image-20240221083249950.png)

7\. 选择**JAR List**，点击右侧的**Clear All**，清空驱动文件（下图列出来的JAR包本地不存在）

![](https://source.icode504.com/images/image-20240221083702299.png)

8\. 点击**Add JAR/Zip**，找到前面我们下载的MySQL JDBC的位置，选中`postgresql-42.6.0.jar`文件，点击**打开**：

![](https://source.icode504.com/images/image-20240131104057823.png)

9\. 找到MySQL数据库驱动包解压位置，并选中文件夹中的JAR包`mysql-connector-j-xxx.jar`（这里xxx指的是版本号）。选择完成后，点击右下角**打开**：

![](https://source.icode504.com/images/image-20240221085426164.png)

10\. 此时数据库驱动JAR包添加成功，并且上方报错信息也消失了：

![](https://source.icode504.com/images/image-20240221085711987.png)

11\. 点击上方的**Properties**，按照下图所给的提示填写好配置信息，完成后点击**OK**：

![](https://source.icode504.com/images/image-20240221090247443.png)

12\. 记不住密码的小伙伴，请将下图的**Save password**勾选上（记住密码），上述内容填写完成后，点击**Test Connection**测试连接：

![](https://source.icode504.com/images/image-20240221101736075.png)

13\. 连接成功，点击**OK**：

![](https://source.icode504.com/images/image-20240221101905828.png)

14\. 点击**Finish**，MySQL安装配置完成，此时我们可以看到名为`mysql`的数据库：

![](https://source.icode504.com/images/image-20240221102428971.png)

15\. 如果想连接其他数据库，鼠标右键点击MySQL，选择最后一个**Properties**，修改数据库属性：

![](https://source.icode504.com/images/image-20240221102727558.png)

16\. 将下图中两处数据库名称修改即可，完成后点击**Apply and Close**：

![](https://source.icode504.com/images/image-20240221103016323.png)

17\. 此时会有一个弹窗提示说数据库配置信息发生变动，是否重新连接，点击**Yes**：

![](https://source.icode504.com/images/image-20240221103111141.png)

18\. 数据库切换成功：

![](https://source.icode504.com/images/image-20240221103230805.png)
