---
title: Eclipse配置PostgreSQL教程（Windows版）
tags:
  - Eclipse
  - PostgreSQL
category_bar: true
date: 2024-01-31 11:01:04
abbrlink: 37
description: Eclipse配置PostgreSQL教程
banner_img: https://source.icode504.com/images/Eclipse配置PostgreSQL教程.png
index_img: https://source.icode504.com/images/Eclipse配置PostgreSQL教程.png
category:
  - [Eclipse, PostgreSQL]
---


请确保电脑本机已经安装PostgresSQL和Eclipse，没有安装的小伙伴根据自己的操作系统点击下方链接查看安装教程（已经安装的小伙伴继续往下看）：

|            |                      Windows                       |  macOS   |  Linux   |
| :--------: | :------------------------------------------------: | :------: | :------: |
| PostgreSQL | [点我查看](https://www.icode504.com/posts/35.html) | 敬请期待 | 敬请期待 |
|  Eclipse   | [点我查看](https://www.icode504.com/posts/30.html) | 敬请期待 | 敬请期待 |

# 一、下载并安装pgJDBC

1\. 按<kbd>Win</kbd>和<kbd>S</kbd>键，在搜索框中搜索Stack Builder并打开：

![](https://source.icode504.com/images/image-20240131100854755.png)

2\. 这里我们选择本地安装的PostgreSQL，完成后点击**下一个**：

![](https://source.icode504.com/images/image-20240131101117119.png)

3\. 按照下图操作，选择pgJDBC：

![](https://source.icode504.com/images/image-20240131101409184.png)

4\. 下载目录自定义，这里我安装在D盘，完成后点击**下一个**：

![](https://source.icode504.com/images/image-20240131101553293.png)

5\. 下载完成，点击**下一个**：

![](https://source.icode504.com/images/image-20240131101620551.png)

6\. 进入pgJDBC安装界面，点击**Next**：

![](https://source.icode504.com/images/image-20240131101713249.png)

7\. 选择一个你熟悉的安装位置，这里我安装在了D盘，完成后点击**Next**：

![](https://source.icode504.com/images/image-20240131101906926.png)

![](https://source.icode504.com/images/image-20240131102038330.png)

![](https://source.icode504.com/images/image-20240131102113012.png)

8\. 点击**Next**，开始安装：

![](https://source.icode504.com/images/image-20240131102151200.png)

9\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20240131102227258.png)

10\. 点击**Finish**，安装完成：

![](https://source.icode504.com/images/image-20240131102245360.png)

11\. 点击**完成**，关闭Stack Builder：

![](https://source.icode504.com/images/image-20240131102428855.png)

# 二、Eclipse配置PostgreSQL

1\. 打开Eclipse，在上方菜单栏选择**Window** --> **Show View** --> **Other**：

![](https://source.icode504.com/images/image-20240131100443322.png)

2\. 双击打开**Data Management**，选择**Data Source Explorer**，完成后点击**Open**：

![](https://source.icode504.com/images/image-20240131100530658.png)

3\. 此时会弹出一个Data Source Explorer窗口，鼠标右键选中第一个**Database Connections**，点击**New**新建一个连接：

![](https://source.icode504.com/images/image-20240131102657948.png)

4\. 连接类型**选择PostgreSQL并选中**，Name和Description自定义，完成后点击**Next**：

![](https://source.icode504.com/images/image-20240131102920348.png)

5\. 点击右上角**加号**修改数据库驱动和连接信息：

![](https://source.icode504.com/images/image-20240131103041407.png)

6\. 选中数据库驱动模板**PostgreSQL JDBC Driver**，此时上方弹出一个错误信息：在本地系统中无法找到`postgresql-8.1-xxxx.jdbc2.jar`，这说明我们需要将Eclipse原有的数据库驱动改成前面我们下载安装的pgJDBC：

![](https://source.icode504.com/images/image-20240131103624152.png)

7\. 选择**JAR List**，点击右侧的**Clear All**，清空驱动文件（下图列出来的JAR包本地不存在）

![](https://source.icode504.com/images/image-20240131103928756.png)

8\. 点击**Add JAR/Zip**，找到前面我们安装的pgJDBC的位置，选中`postgresql-42.6.0.jar`文件，点击**打开**：

![](https://source.icode504.com/images/image-20240131104057823.png)

![](https://source.icode504.com/images/image-20240131104254745.png)

![](https://source.icode504.com/images/image-20240131104425996.png)

9\. 点击上方的**Properties**，按照下图所给的提示填写好配置信息：

![](https://source.icode504.com/images/image-20240131104642198.png)

10\. 记不住密码的小伙伴建议勾选`Save Password`，点击右下角的**Test Connection**，测试一下数据库连接：

![](https://source.icode504.com/images/image-20240131105018333.png)

11\. 此时弹出一个窗口：`Ping succeeded`，说明数据库测试连接成功，点击**OK**：

![](https://source.icode504.com/images/image-20240131105137424.png)

12\. 点击**Finish**，PostgreSQL连接成功：

![](https://source.icode504.com/images/image-20240131105306411.png)

![](https://source.icode504.com/images/image-20240131105549246.png)
