---
abbrlink: '99'
banner_img: https://source.icode504.com/images/Electerm安装、配置与卸载教程（Windows版）.png
categories:
- - 软件安装
  - macOS
  - 服务器&虚拟机
date: '2024-08-15T09:07:18.024464+08:00'
description: 本文简要介绍了在macOS操作系统上安装Electerm的步骤。通过该教程，用户可以轻松下载、安装并配置Electerm，确保后续在macOS平台上享受强大的终端功能和文件管理能力。
index_img: https://source.icode504.com/images/Electerm安装、配置与卸载教程（Windows版）.png
order: ''
tags:
- macOS
- Electerm
title: Electerm安装、配置与卸载教程（macOS版）
updated: '2024-10-15T13:58:43.864+08:00'
---
Electerm 是一款开源免费的终端模拟器，集终端模拟器、文件管理器、SSH 远程连接、SFTP 客户端等功能于一体。它可以在 Windows、macOS 和 Linux 操作系统上运行，为用户提供一个功能丰富、易于使用的终端环境。

通过 Electerm，用户可以在同一窗口中运行多个 SSH 会话，轻松管理远程服务器，并使用各种 Shell 命令。它还支持多种认证方式，包括密码、密钥、双因素认证等，以满足不同用户的需求，使得使用 SSH 会话更加高效方便。

在文件传输方面，Electerm 支持 SFTP 功能，可以方便地传输文件和管理网络连接。它还支持多语言，包括英语、中文等。

接下来介绍一下 macOS 环境下的 Electerm 的安装和简单配置。

# 一、准备操作

在正式下载Electerm安装包时，推荐下载安装如下两个软件：


| 软件名称                     | 安装教程              | 说明                                                                              |
| :--------------------------- | :-------------------- | --------------------------------------------------------------------------------- |
| NDM（Neat Download Manager） | [点我查看](./24.html) | 本文后续内容使用 NDM（Neat Download Manager）下载文件，可以加快下载速度（推荐）。 |

# 二、下载 Electerm

1\. 打开 Electerm 官网：[点我查看](https://electerm.html5beta.com/index-zh_cn.html)

2\. 在下方页面找到 Windows 相关的安装包，鼠标右键选择复制链接地址：

![](https://source.icode504.com/images/a9b3cdfb87b75ab5759586ea0e6320eb.png)

3\. 点击右侧链接进入Github镜像加速站：[点我查看](https://gitdl.cn/)

> 说明：如果上述链接无法进入，请点击[此链接](./25.html#%E4%B8%89%E3%80%81%E4%B8%8B%E8%BD%BD-Github-%E4%B8%AD%E7%9A%84%E5%86%85%E5%AE%B9)进入查看其它镜像加速站。

4\. 打开镜像加速站，将前面复制的链接粘贴到此处，然后点击**下载**即可：

![](https://source.icode504.com/images/17101011d63791e5788d21f4e16c9f64.png)

# 三、安装 Electerm

1\. 打开下载好的安装包，将安装包拖入到应用程序中即可完成安装：

![https://source.icode504.com/images/image-48458ace6275c4ab0977884451b68a7f.gif](https://source.icode504.com/images/image-48458ace6275c4ab0977884451b68a7f.gif)

2\. 安装完成后，在控制台找到Electerm，双击打开：

![](https://source.icode504.com/images/image-a1062be1ee06af09c1dd3901096cd993.png)

# 四、Electerm 的简单配置

> 说明：以下包含“可选”的标题中可以自行修改，并不影响实际使用。

## 4.1 更换主题风格（可选）

在桌面打开 Electerm，默认是黑色界面：

![](https://source.icode504.com/images/image-20240213105358335.png)

如果你不喜欢这个纯黑界面，可以在左侧找到**设置**（小齿轮）对主题进行更改：

![](https://source.icode504.com/images/image-20240213105514644.png)

在设置中，找到 UI 主题（内置了多个主题，也可以自定义主题，这里我选用的是 Github 主题），在下方搜索框中输入 Github，其中第二个搜索结果就是我们想要的：

![](https://source.icode504.com/images/image-20240213110343282.png)

选择 Github 主题，此时最右侧会出现一个对号图标，点击这个图标就是应用这个主题：

![](https://source.icode504.com/images/image-20240213110645152.png)

点击左上角的关闭图标，此时我们发现界面变成了白色风格：

![](https://source.icode504.com/images/image-20240213110745168.png)

![](https://source.icode504.com/images/image-20240213111646109.png)

## 4.2 设置背景图片（可选）

界面上有一个 Electerm 的大 logo，其实这是一张背景图片。软件本身支持修改背景图片。

![](https://source.icode504.com/images/image-20240213111722825.png)

点击左侧菜单，打开**设置**（小齿轮）：

![](https://source.icode504.com/images/image-20240213111908999.png)

在设置下方，找到**终端**，右侧有**终端背景图片**设置：

![](https://source.icode504.com/images/image-20240213112130980.png)

如果你不需要背景图片，就点击以下输入框，此时会弹出一个列表框，选择无背景图片即可：

![](https://source.icode504.com/images/image-20240213112256558.png)

需要更换背景图片的小伙伴，建议是保存在本地的电脑壁纸（虽然 Electerm 支持在线图片链接，但是没有网了以后图片也不会显示）。点击右侧**选择文件**：

![](https://source.icode504.com/images/image-20240213114042874.png)

在本地选择一张壁纸（壁纸建议是简约风，否则花里胡哨可能会影响使用体验）：

![](https://source.icode504.com/images/image-20240213114529925.png)

图片设置好以后，我们可以在下方设置图片的透明度和模糊度：

- 透明度（Opacity），值在 0~1 之间，数值越小，图片的透明度越低。
- 模糊度（Blur），数值越大，图片越模糊。

![](https://source.icode504.com/images/image-20240213115310321.png)

修改后界面效果如下：

![](https://source.icode504.com/images/image-20240213115750587.png)

## 4.3 关闭检查更新

Electerm 更新软件默认会从 Github 下载，但是 Github 对国内用户并不友好（因为网络原因经常访问失败）。如果你不想使用新版本的 Electerm，建议关闭检查更新这一项。

点击右侧的**设置**（小齿轮）：

![](https://source.icode504.com/images/image-20240213111908999.png)

在设置中的 Common，在下方设置中关闭**检查应用程序启动时的更新**：

![](https://source.icode504.com/images/image-20240213120341726.png)

# 五、卸载 Electerm（可选）

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

打开访达，在左侧选择应用程序，找到Electerm拖入到废纸篓即可完成卸载：

![](https://source.icode504.com/images/image-fb53c515d742c104654573b4528c694d.png)
