---
abbrlink: '109'
banner_img: https://source.icode504.com/images/Intellij%20IDEA%20%E6%9C%80%E6%96%B0%E7%89%88%E5%AE%89%E8%A3%85%E9%85%8D%E7%BD%AE%E6%95%99%E7%A8%8B%EF%BC%88Windows%E7%89%88%EF%BC%89.png
categories:
- - 软件安装
  - Windows
  - 集成开发环境
date: '2024-09-29T22:41:51.090+08:00'
description: 本文探讨了程序员在工作中需要掌握的工具Intellij IDEA，包括下载安装、JDK环境配置、创建Java项目、在IDEA运行第一个程序等。
index_img: https://source.icode504.com/images/Intellij%20IDEA%20%E6%9C%80%E6%96%B0%E7%89%88%E5%AE%89%E8%A3%85%E9%85%8D%E7%BD%AE%E6%95%99%E7%A8%8B%EF%BC%88Windows%E7%89%88%EF%BC%89.png
order: ''
tags:
- Windows
- Intellij IDEA
title: Intellij IDEA 最新版安装配置教程（Windows版）
updated: '2024-09-30T15:22:04.698+08:00'
---
Intellij IDEA（以下简称简称IDEA）是Java语言的集成开发环境，在业界公认为是一款优秀的Java开发工具。分为Community社区版（免费）和Untimate终极版（付费）。

IDEA是一款智能编译器。它可以进行智能代码补全、提供问题工具窗口、代码上下文检查操作、实时模板、项目级别代码重构、重复代码检测等功能。

IDEA Untimate版为现代应用程序和Java相关微服务开发框架提供了一流的支持。IDEA对SpringBoot、Jakata EE、JPA等框架提供一流的支持。

其内部支持很多的内置工具，例如：调试器、数据库工具、终端、反编译器、WEB开发、版本控制（Git）、导航和搜索功能等。

下面为大家介绍一下Windows版的Intellij IDEA Untimate版如何安装和使用。

# 一、下载Intellij IDEA

点击右侧链接进入IDEA的官方下载页面：[点我查看](https://www.jetbrains.com.cn/idea/download/?section=windows)，然后点击**下载**最新版的安装包：

![](https://source.icode504.com/images/image-1f944e1e9502b6ae946aafffdd6b222f.png)

# 二、安装Intellij IDEA

1\. 双击打开安装包，出现IDEA欢迎界面后，点击**下一步**：

![](https://source.icode504.com/images/image-45dd36ffd47511488de84ca282d83b5b.png)

2\. 点击**浏览**选择安装路径，建议安装在除C盘外的其他位置，这里我安装在了D盘，完成后点击**下一步**：

![](https://source.icode504.com/images/image-efa2fe0dd261472f39dfb06bf25ed064.png)

![](https://source.icode504.com/images/image-20240103085725550.png)

![](https://source.icode504.com/images/image-1f5ad418bc546b53593cac8b50981d06.png)

3\. 安装选项按照下图所示勾选即可：

![](https://source.icode504.com/images/image-6d2b50eb28a731aef839072d0410036d.png)

4\. 点击**安装**，开始安装Intellij IDEA：

![](https://source.icode504.com/images/image-41dcacc459e4380ef04b8b1d87df676b.png)

5\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-01fd6e56def96f6f8dd7eb6b8a0bd85f.png)

6\. 安装完成，点击**完成**：

![](https://source.icode504.com/images/image-2b8ce30c83524fde69f94ba3f390511b.png)

# 三、激活Intellij IDEA

激活Intellij IDEA一共有三种方式：购买正版、学生认证、个人破解。任选一种方式激活即可，如果资金允许，请支持正版！

## 方式一：官网正版购买许可

1\. 点击右侧链接进入正版IDEA购买页面（支持微信/支付宝，购买时需要提供个人邮箱）：[点我购买](https://www.jetbrains.com.cn/idea/buy/?section=personal&billing=yearly)

2\. 以下是个人使用的收费说明：

- 个人按年购买IDEA1400元，第二年1120元，第三年以后是840元。
- 个人按月购买IDEA140元，连续购买12个月以后，第二年连续订阅打八折，第三年连续订阅打六折。

![](https://source.icode504.com/images/image-20240103092358786.png)

## 方式二：个人破解（适用于平民党）

<font color='#EE0000' size=24>注意：仅供学习使用！仅供学习使用！仅供学习使用！重要的事情说三遍！</font>

> 个人破解这一部分参考了犬小哈老师的教程，感兴趣的小伙伴可以查看原作者编写的教程，写的非常好！[点我查看原文](https://www.quanxiaoha.com/idea-pojie/idea-pojie-202323.html)

1\. 点击右侧链接下载破解补丁：[点我下载](https://icode504.lanzn.com/i9twT2b5niwh)

2\. 将下载的压缩包解压到一个你熟悉的路径中，这里我放到了D盘的Crack文件夹中：

![](https://source.icode504.com/images/image-71a70704eab6aeba51a955d00ceda6ce.png)

3\. 双击打开**IDEA破解**脚本：

![](https://source.icode504.com/images/image-7eaf0726574220ee42111fc6cd0566f0.png)

4\. 破解成功，Intellij IDEA激活至2099年，点击**确定**：

![](https://source.icode504.com/images/image-85c4f423b181110f44bd02e84f2fc222.png)

5\. 破解完成后，如果无法在桌面打开IDEA，可以尝试重启电脑。

# 四、使用Intellij IDEA创建Java项目

> 请确保本地已经安装了JDK，没有安装的小伙伴点击下方任意一个链接查看安装教程：
>
>
> |                       JDK 8                       |                       JDK 11                       |                       JDK 17                       |                       JDK 21                       |
> | :-----------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: |
> | [点我查看](https://www.icode504.com/posts/1.html) | [点我查看](https://www.icode504.com/posts/28.html) | [点我查看](https://www.icode504.com/posts/26.html) | [点我查看](https://www.icode504.com/posts/27.html) |

1\. 打开IDEA，初次使用的小伙伴，会出现一个用户协议窗口，勾选协议，完成后点击**Continue**：

![](https://source.icode504.com/images/image-20240104215643194.png)

2\. 数据共享，点击**Don't Send**，不发送任何数据：

![](https://source.icode504.com/images/image-20240104215809730.png)

3\. 创建项目：点击左侧**Projects**，然后点击**New Project**创建一个新项目：

![](https://source.icode504.com/images/image-b0934c8400699d9e6dabe35c62944661.png)

4\. 按照下图所示操作完成项目的创建：

![](https://source.icode504.com/images/image-ad7ccb94cd44358e6f65d99aa61872ed.png)

5\. 如果出现下面的反馈窗口，点击**No Thanks**即可：

![](https://source.icode504.com/images/image-20240104220327436.png)

5\. 成功创建Java项目后，IDEA会弹出一个每日提示的窗口，勾选**Don't show tips on startup**不再提示，再点击右下角的**Close**关闭：

![](https://source.icode504.com/images/image-20240107112521924.png)

6\. **鼠标右键点击src**文件夹，点击**New**，选择第一个**Java Class**创建Java文件：

![](https://source.icode504.com/images/image-44ce0150ba886ba1da581c5d74919cca.png)

7\. 创建Java文件，自定义Java文件名（类名），命名要符合[标识符命名规范](https://www.icode504.com/posts/3.html#%E6%A0%87%E8%AF%86%E7%AC%A6)：

![](https://source.icode504.com/images/image-4997165cc3d4642e1ab8c7380c6539b0.png)

8\. 在当前类中输入`psvm`或者`main`，即可生成`main`方法：

![在当前类中输入psvm，也可以生成main方法](https://source.icode504.com/images/image-5e5cbe44a561f3f183cb437077be1b1b.gif)

![在当前类中输入main，也可以生成main方法](https://source.icode504.com/images/image-f7cf9bff9bf61464fa8114b759e32596.gif)

9\. 在`main`方法中输入`sout`，即可生成一个换行输出的`System.out.println();`语句：

![在main方法中输入sout可以快速生成一个System.out.println();换行输出语句](https://source.icode504.com/images/image-f745f0eb1ea039893663a12ffa2a1625.gif)

10\. 这里我写了一个简单的Java程序：

```java
public class Demo01 {
	public static void main(String[] args) {
    	System.out.println("昔人已乘黄鹤去，此地空余黄鹤楼。");
        System.out.println("黄鹤一去不复返，白云千载空悠悠。");
        System.out.println("晴川历历汉阳树，芳草萋萋鹦鹉洲。");
        System.out.println("日暮乡关何处是？烟波江上使人愁。");
    }
}
```

效果图如下：

![](https://source.icode504.com/images/image-6c8e2792d42013eacc7574886e5f829d.png)

11\. 运行Java程序，鼠标右键点击代码，点击**Run xxx.main()**（或者直接按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>F10</kbd>）即可运行这个Java程序：

![](https://source.icode504.com/images/image-909a06b5b4f2701bd0988a6c531c76aa.png)

12\. 此时控制台就会输出内容，Java程序成功运行：

![](https://source.icode504.com/images/image-80800901fcde84b9279516b626d9dcdd.png)

# 五、Intellij IDEA的卸载（可选）

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Installer，在程序列表中找到Intellij IDEA，鼠标右键，点击**卸载**：

![](https://source.icode504.com/images/image-6ff9f852cf8c874849dde6b2e82ef74b.png)

2\. 将下面两个框进行勾选。然后点击**卸载**：

![](https://source.icode504.com/images/image-b4e99ff1a243e7a744473b7e4848d8a0.png)

3\. 卸载中，请耐心等待：

![](https://source.icode504.com/images/image-cc5ce554119693eeb494fdca1cd694fd.png)

4\. 卸载完成，点击**关闭**：

![](https://source.icode504.com/images/image-429adeaa2143fdb80b29fd05b7b91ecb.png)

5\. 此时Geek会我们检测出安装残留，我们只需要点击**完成**即可，清除卸载残留：

![](https://source.icode504.com/images/image-32bfa827a4365bd5bd317e6136439021.png)

6\. 清理完毕，关闭Geek即可：

![](https://source.icode504.com/images/image-20240121164930832.png)
