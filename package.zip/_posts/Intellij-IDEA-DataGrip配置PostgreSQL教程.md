---
abbrlink: '36'
banner_img: https://source.icode504.com/images/Intellij-IDEA-DataGrip配置PostgreSQL教程.png
categories:
- - Intellij IDEA
  - PostgresSQL
- - DataGrip
  - PostgresSQL
category_bar: true
date: '2024-01-31T09:14:56+08:00'
description: Intellij IDEA/DataGrip配置PostgreSQL
index_img: https://source.icode504.com/images/Intellij-IDEA-DataGrip配置PostgreSQL教程.png
order: ''
tags:
- Intellij IDEA
- PostgreSQL
- DataGrip
title: Intellij IDEA/DataGrip配置PostgreSQL教程
updated: '2024-08-24T16:50:48.214+08:00'
---
请确保电脑本机已经安装PostgresSQL和Intellij IDEA，没有安装的小伙伴根据自己的操作系统点击下方链接查看安装教程（已经安装的小伙伴继续往下看）：


|              |                      Windows                      |  macOS  |                        Linux                        |
| :-----------: | :------------------------------------------------: | :------: | :-------------------------------------------------: |
|  PostgreSQL  | [点我查看](https://www.icode504.com/posts/35.html) | 敬请期待 | [点我查看](https://www.icode504.com/posts/104.html) |
| Intellij IDEA | [点我查看](https://www.icode504.com/posts/10.html) | 敬请期待 |                      敬请期待                      |

1\. 按照下图所示操作，数据源选择PostgreSQL：

![](https://source.icode504.com/images/image-20240105174627593.png)

2\. 在Driver处，点击**PostgreSQL**，点击**Go to Driver**：

![](https://source.icode504.com/images/image-20240105175052684.png)

3\. 在Driver Files处，点击**加号**，选择**Proviced Dirver**，数据库驱动选择PostgreSQL官网最新稳定版本：

![](https://source.icode504.com/images/image-20240130111433876.png)

4\. 点击**Download**，下载数据库驱动文件：

![](https://source.icode504.com/images/image-20240130111631704.png)

5\. 下载中，请耐心等待：

![](https://source.icode504.com/images/image-20240130111649561.png)

5\. Postgres驱动包添加成功，如下图所示：

![](https://source.icode504.com/images/image-20240130114135936.png)

6\. 点击左上角的Data Sources。用户名Username输入**postgres**，密码是你在安装Postgres的时候设置的密码（我当时设置的是123456）。配置完成后，点击左下角的**Test Connection**测试我们填写的内容是否正确：

![](https://source.icode504.com/images/image-20240130114220813.png)

![](https://source.icode504.com/images/image-20240130094448766.png)

7\. 左下角出现Succeeded弹窗表示Postgres连接成功。重新输入一遍密码，点击**OK**：

![](https://source.icode504.com/images/image-20240130094755483.png)

8\. 连接成功，接下来你就可以在console中写SQL语句了！

![](https://source.icode504.com/images/image-20240130100150910.png)
