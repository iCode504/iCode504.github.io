---
abbrlink: '78'
archive: false
banner_img: null
categories:
- 软件安装
- macOS
- 编程语言
- Java/JDK
category_bar: true
date: '2024-07-14T14:28:10+08:00'
description: macOS环境下安装JDK 8教程
index_img: null
order: ''
password: null
tags:
- Java
- macOS
title: JDK 8安装配置教程（macOS版）
updated: '2024-09-06T10:30:52.587+08:00'
---
JDK，全称Java Development Kit，即Java开发工具包，它是整个Java开发的核心，包含了Java运行环境（JVM+Java系统类库）和Java工具。目前JDK 8、11、17、21是长期稳定支持的版本。

以下是macOS环境下JDK 8的安装和使用教程，以下两种方式任选其一：

# 方式一：使用SDKMAN!安装

1\. 打开终端，请确保macOS上已经安装了SDKMAN!，没有安装的小伙伴可以点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/108.html)

2\. 执行如下命令，查看各大厂商可以安装的JDK相关版本：

```bash
sdk list java
```

下图中提供了各个厂商提供的Java，翻到页面最下方，这里我下载的是ZuluJDK，按照下图中选中复制版本号：

> 提示：上、下键可以翻页，或者按<kbd>PageUp</kbd>或<kbd>PageDown</kbd>翻页，按<kbd>Q</kbd>键退出。

![](https://source.icode504.com/images/image-b5b304b00a39ffda8a82861d3668fdc4.png)

3\. 执行如下命令，安装ZuluJDK：

```bash
sdk install java 版本号-厂商名
```

效果图如下（将前面复制的版本信息粘贴此处）：

![](https://source.icode504.com/images/image-81de7f2d35d7de4a63d3923b67274dfd.png)

4\. 等待一段时间后，JDK安装完成：

![](https://source.icode504.com/images/image-20f70e229e4108efdc136e3cedbcc3c7.png)

5\. 接下来，我们可以分别使用`java`、`javac`、`java -version`查看版本信息：

![](https://source.icode504.com/images/image-fc97bf3c031cf0673f5bbf130412c693.png)

![](https://source.icode504.com/images/image-5b8bc10be92b19950e5095215139e199.png)

![](https://source.icode504.com/images/image-256ec5721d3cf0841b7cce8210f6c07d.png)

# 方式二：正常安装

## 一、安装前准备

检查本机信息：点击左上角苹果logo，点击第一个**关于本机**：

![](https://source.icode504.com/images/image-20240224151904945.png)

这里需要留意一下处理器信息，这里我的电脑使用的是Intel芯片：

![](https://source.icode504.com/images/image-20240224152112087.png)

## 二、下载JDK

以下两种方式二选一下载即可：

### 方式一：网盘下载

根据上方的处理器信息选择对应的下载链接：


|              说明              |                               下载链接                               |
| :-----------------------------: | :------------------------------------------------------------------: |
|  macOS(Intel芯片, x64版本) JDK  | [点我下载](https://pan.baidu.com/s/1GGuNm0rp_BS58ds6jmua_g?pwd=1024) |
| macOS(Intel芯片, arm64版本) JDK | [点我下载](https://pan.baidu.com/s/1pwIRrLqfnDsTJdXTpyUMKA?pwd=1024) |

### 方式二：官网下载（需要注册账号登录，不推荐）

1\. 点击此链接到官网下载页面：[点击进入](https://www.oracle.com/java/technologies/downloads/archive/)

2\. 根据自己的电脑的操作系统点击对应的链接进入，M1及之后的芯片的小伙伴点击**Java SE 8 (8u211 and later)**进入；Intel芯片的小伙伴点击任意一个Java SE 8进入即可。

![](https://source.icode504.com/images/image-20240714125850370.png)

2\. 找到以Java SE Development Kit开头的下载列表，按照下图所示的操作，根据自己的芯片下载JDK安装包：

![](https://source.icode504.com/images/image-20240714130847156.png)

3\. 按图所示点击下载：

![](https://source.icode504.com/images/image-20240714131651565.png)

4\. 需要登录Oracle账号，没有账号的可以注册一个。登陆后即可下载：

![](https://source.icode504.com/images/image-20240714131003147.png)

## 三、安装JDK

1\. 找到下载好的文件，双击文件dmg文件：

![](https://source.icode504.com/images/image-20240714131920803.png)

2\. 双击pkg安装包，开始安装JDK：

![](https://source.icode504.com/images/image-20240714132042344.png)

3\. 进入欢迎页面，点击**继续**：

![](https://source.icode504.com/images/image-20240714132136705.png)

4\. 点击**安装**：

![](https://source.icode504.com/images/image-20240714132229961.png)

5\. 输入本机用户密码，然后点击**安装软件**：

![](https://source.icode504.com/images/image-20240714132349877.png)

6\. 安装中，请耐心等待

![](https://source.icode504.com/images/image-20240714132457319.png)

7\. 安装成功，点击**关闭**：

![](https://source.icode504.com/images/image-20240714132544426.png)

8\. 这里弹出一个提示框，如果后续你还要继续使用JDK安装包，请点击保留，如果不需要，就点击移动到废纸篓。

## 四、检查JDK相关命令是否在终端中可用

1\. 打开终端，输入`javac`和`java`，会出现下图内容：

![](https://source.icode504.com/images/image-20240714133154774.png)

![](https://source.icode504.com/images/image-20240714133231247.png)

2\. 输入`java -version`即可查看当前JDK版本信息：

![](https://source.icode504.com/images/image-20240714133339950.png)
