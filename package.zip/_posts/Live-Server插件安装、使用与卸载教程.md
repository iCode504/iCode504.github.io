---
title: Live Server插件安装、使用与卸载教程
tags:
  - VS Code
  - Live Server
category_bar: true
archive: false
abbrlink: 44
description: 这篇教程提供Live Server插件的简明安装、使用与卸载指南，帮助用户编写代码并且在浏览器上实时显示
banner_img: https://source.icode504.com/images/Live Server插件安装、使用与卸载教程.png
index_img: https://source.icode504.com/images/Live Server插件安装、使用与卸载教程.png
category:
  - VS Code
  - Live Server
date: 2024-02-06 11:00:22
password:
---


# 一、下载安装Live Server插件

1\. 打开VS Code左侧插件商店，搜索Live Server并**安装**：

![](https://source.icode504.com/images/image-20240206101011065.png)

2\. 安装完成后，点击插件右下角的小齿轮，点击**扩展设置**：

![](https://source.icode504.com/images/image-20240206104022501.png)

3\. 找到**Custom Browser**，在这里可以选择你要使用的浏览器。这里我选择的是chrome（需要保证电脑本地已经安装了浏览器）：

- null是系统默认的浏览器。
- 带PrivateMode是以隐私保护模式打开浏览器。

![](https://source.icode504.com/images/image-20240206104446439.png)

# 二、Live Server使用演示

1\. 在VS Code中创建一个HTML文件：`page01.html`，代码如下图所示（浏览器页面中无内容），**鼠标右键点击Open with Live Server**：

![](https://source.icode504.com/images/image-20240206101705146.png)

2\. 此时我在body标签内写内容，可以在右侧浏览器页面中实时显示：

![](https://source.icode504.com/images/240206001.gif)

# 三、卸载Live Server插件（可选）

{% note danger %}

这一部分会将插件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{% endnote %}

1\. 打开左侧VS Code左侧插件商店，找到已经安装的Live Server，点击齿轮，然后点击卸载：

![](https://source.icode504.com/images/image-20240206100359816.png)

2\. 点击**需要重新加载**。至此，Live Server卸载成功：

![](https://source.icode504.com/images/image-20240206100553238.png)
