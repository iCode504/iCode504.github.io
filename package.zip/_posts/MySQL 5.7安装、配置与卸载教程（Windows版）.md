---
abbrlink: '114'
banner_img: https://source.icode504.com/images/Windows%E5%AE%89%E8%A3%85%E3%80%81%E9%85%8D%E7%BD%AE%E3%80%81%E5%8D%B8%E8%BD%BDMySQL%E6%95%99%E7%A8%8B.png
categories:
- 软件安装
- Windows
- 数据库
date: '2024-11-04T15:11:18.110067+08:00'
description: 本教程提供MySQL在Windows上的安装、配置与卸载指南，包括下载、安装、配置环境变量、启动MySQL服务、连接MySQL数据库等步骤，以及如何卸载MySQL。
index_img: https://source.icode504.com/images/Windows%E5%AE%89%E8%A3%85%E3%80%81%E9%85%8D%E7%BD%AE%E3%80%81%E5%8D%B8%E8%BD%BDMySQL%E6%95%99%E7%A8%8B.png
order: ''
tags:
- Windows
- MySQL
title: MySQL 5.7安装、配置与卸载教程（Windows版）
updated: '2024-11-05T10:06:29.505+08:00'
---
MySQL是一个关系型数据库管理系统，目前为Oracle旗下产品，它具有开源、体积小、速度快的优点，许多网站使用的都是MySQL数据库。

简单而言，MySQL数据库核心功能就是用来存储数据的。

MySQL数据库分为社区版和商业版，这里介绍的是社区版的安装教程：

# 一、下载MySQL

1\. 打开MySQL官网下载链接：[点我查看](https://downloads.mysql.com/archives/installer/)

2\. 按照下图所示操作选择相应的MySQL版本下载，这里我选择的Windows MySQL 5.7.43版本。

![](https://source.icode504.com/images/f87a608c553b65e905edd9499e4bb9d5.png)

3\. 下载中，请耐心等待。

# 二、安装并配置MySQL

安装MySQL过程中，**请保持网络畅通**！！！

1\. 双击打开下载好的安装器，启动需要一些时间，请耐心等待：

![](https://source.icode504.com/images/ea36438253e80bc563e8594f74521445.png)

2\. 如果有如下提示更新窗口，选择No不更新：

![](https://source.icode504.com/images/9bd090875adb9482462c514b23530757.png)

3\. 安装类型选择**Custom**，然后点击**Next**：

![](https://source.icode504.com/images/image-20240220111156356.png)

4\. 按照下图所示操作，选择安装`MySQL Server 5.7.43 - X64`，完成后直接点击**Next**：

![](https://source.icode504.com/images/a6190afba6d6e8ad9f971d1f96cad7b8.gif)

> 说明：如何修改路径（小白可以忽略下列内容，直接跳到第5步）
>
> 如果您想修改MySQL的安装路径，如下图，可以点击下方**Advanced Options**：
>
> ![](https://source.icode504.com/images/image-20240220111320444.png)
>
> 按照下图所示，选择安装路径，为避免后续过程中出现问题，**安装路径建议只包含英文字符**；下面的是MySQL数据存储路径，如果不懂这方面的内容，建议不要修改这个路径。配置完成后后点击**OK**：
>
> ![](https://source.icode504.com/images/image-20240220111711714.png)
>
> 安装路径和存储路径配置完成后，会弹出一个弹窗，点击**OK**即可：
>
> ![](https://source.icode504.com/images/26872ea77b79c17ba9720d218b7246d9.png)
>
> 此时点击**Next**：
>
> ![](https://source.icode504.com/images/92bcec1f0b0d294af0fd22ef3a524910.png)
>
> 选择**Yes**继续安装：
>
> ![](https://source.icode504.com/images/752b4f28f4034415a7b637d879a05598.png)

5\. 点击**Execute**：

![](https://source.icode504.com/images/396a7c1c327b276a10d3e97e65392bac.png)

6\. 安装中，请耐心等待：

![](https://source.icode504.com/images/7c02e7df4977727df874aa8bba76deda.png)

7\. 出现下图提示**Complete**以后，MySQL安装完成。直接点击**Next**：

![](https://source.icode504.com/images/4115e922b7dfe0869df389e5ed9ebf6e.png)

8\. 接下来开始配置MySQL，点击**Next**：

![](https://source.icode504.com/images/0928d235c34af697576778f8d27ba4db.png)

9\. 初次安装MySQL的小白请注意，下图的**Port请务必配置成3306**，完成后点击**Next**：

> 注意：如果您的电脑上已经安装了其他版本的MySQL，并且已经占用了3306端口，您需要将端口号修改为其他值。

![](https://source.icode504.com/images/175539c8d47f5a74f88d39c26dd44731.png)

10\. 设置root账户密码，这里强烈建议**将密码设置成你最熟悉的密码**，否则后续恢复密码比较麻烦。这里我设置成了`123456`。设置完成后点击**Next**：

![](https://source.icode504.com/images/fa7a1ad26250ddd0612602925ac36ff1.png)

11\. 在Windows中开启服务，直接点击**Next**即可：

![](https://source.icode504.com/images/948e88c0fcf258d870c1fbfaeecc3026.png)

12\. 服务器文件权限按照默认配置**选择第一个**即可，点击**Next**：

![](https://source.icode504.com/images/fa7fd399d00606ce36f3ebb4e9cf3fa0.png)

13\. 点击**Execute**，MySQL安装器就会为我们配置上述内容。配置过程中，请耐心等待：

![](https://source.icode504.com/images/c77227fad2d1b7a6bb43b40f67016294.png)

14\. 出现下图信息，说明MySQL配置成功，点击**Finish**完成配置：

![](https://source.icode504.com/images/e0f7643d31dd59ebe6752b51a8484229.png)

15\. 点击**Next**：

![](https://source.icode504.com/images/cb9301f85542d4fb7bf6b4a31e7d7917.png)

16\. 点击**Finish**，MySQL配置完成。

![](https://source.icode504.com/images/59868e65757851c80d0a79a96fa471e0.png)

# 三、配置MySQL环境变量

1\. 初次安装MySQL的小白，找到前面安装的MySQL路径的bin目录，按照下图操作复制路径：

> （此条内容小白请忽略）安装在其他位置的小伙伴找到MySQL的安装路径，进入bin文件夹后复制文件路径。

![](https://source.icode504.com/images/00005.gif)

2\. 在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

3\. 点击**高级系统设置**：


|   Windows 11   | ![](https://source.icode504.com/images/image-20240101010932039.png) |
| :------------: | ------------------------------------------------------------------- |
| **Windows 10** | ![](https://source.icode504.com/images/image-20240101011132186.png) |

4\. 点击**环境变量**：

![](https://source.icode504.com/images/9b32c83db0d6df2c2f698e9d67d0edfd.png)

5\. 在下方系统变量找到Path，双击进入：

![](https://source.icode504.com/images/image-20230512223639743.png)

6\. 按照下图所示操作，粘贴前面复制的MySQL安装路径，然后一路点击确定即可。

![](https://source.icode504.com/images/3e7273345232c91e2f87e0f4c9b3dd53.png)

7\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，点击进入，在命令提示行中输入`mysql -u root -p`，按回车后会提示让你输入密码。这个密码是前面我们安装MySQL的时候设置的密码，输入完成后按回车即可。完成后出现下图界面表示MySQL安装成功！

> 说明：由于我的电脑上安装了两个MySQL，其中MySQL 5.7使用的端口号是13306，因此在执行命令时需要添加`-P 13306`选项。如果您的电脑中只安装了一个MySQL，并且使用MySQL默认端口号3306，默认不需要写上述端口号配置项，继续执行`mysql -u root -p`即可

![](https://source.icode504.com/images/f641b8555a3a1ca9fc349546467cab9c.png)

# 四、卸载MySQL（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

以下两种卸载方式任选其一即可。

{% endnote %}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](./31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. **鼠标右键**点击下方任务栏的Windows图标，选择**计算机管理**：

![](https://source.icode504.com/images/1d6f0f58a6eb948f5c653f82820886de.png)

2\. 按照下图所示操作，停止MySQL57对应的服务：

![](https://source.icode504.com/images/403f6ef2d08d66a4628f7ac32ccddb1e.png)

3\. 打开Geek Installer，在程序列表中找到MySQL相关的内容，鼠标右键，依次点击卸载：

![](https://source.icode504.com/images/abd574849eaf97f643736d832b92597a.png)

4\. 卸载完成后，Geek Installer会检测卸载残留，如果数据不重要的话，直接清理即可。

![](https://source.icode504.com/images/f25121cc3e8eac7f1b6ce87219f4d668.png)

6\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`regedit`，进入注册表编辑器：

![](https://source.icode504.com/images/fb1ab9987de7fc28173ed4072df2364c.png)

7\. 依次删除下面和MySQL 5.7有关注册表：

```
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\Eventlog\Application\MySQL服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\MySQL57服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet002\Services\Eventlog\Application\MySQL服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\ControlSet002\Services\MySQL服务 目录删除
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Eventlog\Application\MySQL服务目录删除
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MySQL服务 目录删除
```

8\. 完成后重启电脑，MySQL 5.7卸载完成！
