---
title: MySQL 8.0安装、配置与卸载教程（macOS版）
tags:
  - MySQL
  - macOS
category_bar: true
archive: false
abbrlink: 68
description: >-
  本教程提供MySQL在macOS上的安装、配置与卸载指南，包括下载、安装、配置环境变量、启动MySQL服务、连接MySQL数据库等步骤，以及如何卸载MySQL。
banner_img: https://source.icode504.com/images/Windows安装、配置、卸载MySQL教程.png
index_img: https://source.icode504.com/images/Windows安装、配置、卸载MySQL教程.png
category:
  - 软件安装
  - macOS
  - 数据库
date: 2024-04-29 23:39:36
password:
---


MySQL是一个关系型数据库管理系统，目前为Oracle旗下产品，它具有开源、体积小、速度快的优点，许多网站使用的都是MySQL数据库。

简单而言，MySQL数据库核心功能就是用来存储数据的。

MySQL数据库分为社区版和商业版，这里介绍的是社区版的安装教程：

# 一、安装前检查

检查本机信息：点击左上角苹果logo，点击第一个**关于本机**：

![](https://source.icode504.com/images/image-20240224151904945.png)

这里需要留意一下处理器信息，这里我的电脑使用的是Intel芯片：

![](https://source.icode504.com/images/image-20240224152112087.png)

# 二、下载MySQL

1\. 打开MySQL官网下载链接：[点我查看](https://downloads.mysql.com/archives/community/)

2\. 按照下图所示选择对应版本的MySQL安装包下载，这里我选择的是8.0.30版本的MySQL：

![](https://source.icode504.com/images/image-20240224152756696.png)

# 三、安装并配置MySQL

安装MySQL过程中，**请保持网络畅通**！！！

1\. 双击打开dmg磁盘影像文件：

![](https://source.icode504.com/images/image-20240224154757639.png)

2\. 进入磁盘映像文件中，双击打开pkg软件安装包：

![](https://source.icode504.com/images/image-20240224154853841.png)

3\. 此时会弹出一个错误信息：**无法打开“mysql-8.0.30-macos12-86_64.pkg”，因为它来自身份不明的开发者。**（没有这个错误信息并且能正常打开上述软件包的小伙伴请跳转到**第8步**）我们需要解决这个问题：

![](https://source.icode504.com/images/image-20240224155004670.png)

4\. 点击左上角苹果logo，然后点击**系统设置**：

![](https://source.icode504.com/images/image-20240224155139125.png)

5\. 点击**左侧隐私与安全性**，向下找安全性中有一个提示信息：已阻止使用“mysql-8.0.30-macos12-86_64.pkg”，因为它来自身份不明的开发者。点击提示信息下方的**仍要打开**：

![](https://source.icode504.com/images/image-20240224155406642.png)

6\. 输入本机的用户名和密码，完成后点击**修改设置**：

![](https://source.icode504.com/images/image-20240224155514630.png)

7\. 再次双击打开pkg软件安装包，此时会弹出如下的提示信息，点击**打开**：

![](https://source.icode504.com/images/image-20240224155622622.png)

8\. 此时会弹出一个信息：**此软件包将运行一个程序以确定该软件能否安装**，选择**允许**：

![](https://source.icode504.com/images/image-20240224155700068.png)

9\. 进入MySQL安装器欢迎页面，点击右下角**继续**：

![](https://source.icode504.com/images/image-20240224155745310.png)

10\. 进入软件许可协议页面，点击右下角的**继续**：

![](https://source.icode504.com/images/image-20240224155810677.png)

11\. 点击**同意**，继续安装：

![](https://source.icode504.com/images/image-20240224155823918.png)

12\. 点击**安装**，安装MySQL：

![](https://source.icode504.com/images/image-20240224155915966.png)

13\. 输入用户名和密码，然后点击**安装软件**：

![](https://source.icode504.com/images/image-20240224160017901.png)

14\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20240224160032278.png)

15\. 进入配置页面，加密方式选择第一个**Use Strong Password Encryption**，然后点击**Next**：

![](https://source.icode504.com/images/image-20240224160125824.png)

16\. 为root用户设置密码。勾选**Start MySQL Server once the installation is complete.**（MySQL配置完成后开启服务）。完成后点击**Finish**：

> 密码要求至少8位，并且由字母、数字和其他字符混合而成。

![](https://source.icode504.com/images/image-20240224160705939.png)

17\. 此时需要再次输入一次用户名和密码，然后点击**好**：

![](https://source.icode504.com/images/image-20240224160832172.png)

18\. 配置中，请耐心等待：

![](https://source.icode504.com/images/image-20240224160843908.png)

19\. 安装完成，点击**关闭**：

![](https://source.icode504.com/images/image-20240224160936245.png)

20\. 不需要安装包的小伙伴，可以点击**移至废纸篓**：

![](https://source.icode504.com/images/image-20240224161023547.png)

# 四、配置MySQL环境变量

为了后续我们打开终端后直接使用MySQL命令登录数据库，我们需要配置一下环境变量。

1\. 按<kbd>Command</kbd>和<kbd>空格</kbd>，搜索终端并打开。

2\. 在当前目录下创建一个`mysql_env.sh`文件，执行如下命令：

```bash
vim mysql_env.sh
```

3\. 按<kbd>i</kbd>键进入编辑模式，复制下面的内容，在Vim编辑器中鼠标右键粘贴，效果如下图所示：

```shell
#MYSQL
PATH=/usr/local/mysql/bin
export PATH
```

>   说明：如果你的MySQL安装在了其他位置，请将第二行等号右面的值改成你的安装路径。

![](https://source.icode504.com/images/image-20240429232916930.png)

4\. 按一下<kbd>Esc</kbd>键，然后输入`:wq`保存并退出。

5\. 执行如下命令，让环境变量配置生效：

```bash
source mysql_env.sh
```

6\. 执行如下命令登录`root`用户：

```bash
mysql -u root -p
```

此时输入密码不会显示在命令行中，下图界面说明`root`用户登录成功！

![](https://source.icode504.com/images/image-20240429233700930.png)
