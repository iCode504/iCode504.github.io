---
abbrlink: '90'
banner_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
categories:
- - 数据库
  - 非关系型数据库(NoSQL)
  - Redis
date: '2024-08-04T23:07:35.793260+08:00'
description: 本文主要包含如下内容：Redis简单介绍和具体的学习大纲，里面列举了Redis相关文章的链接
index_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
order: '0'
tags:
- Redis
title: Redis学习前言
updated: '2024-08-30T15:47:03.107+08:00'
---
Redis是一种开源的内存数据库，具有高性能、丰富的数据结构和简单易用的特点。它不仅支持键值对存储，还提供了列表、集合、有序集合和哈希等多种数据类型，使得处理复杂数据更加灵活高效。Redis常用于缓存、会话管理、实时分析、消息队列等场景，因其极快的读写速度和高可用性，成为许多互联网企业的首选。通过学习Redis，您将能够掌握如何优化系统性能，设计高效的数据存储方案，并应对大规模、高并发的应用需求。

以下是我个人整理的Redis学习笔记，希望能帮到你：

# 第一部分 Redis基础知识

## Redis 单机版

### 一、Redis入门知识


| 教程名称                                                 | 链接                                               |
| -------------------------------------------------------- | -------------------------------------------------- |
| Redis相关内容介绍                                        | 敬请期待                                           |
| Redis安装教程（Linux版）                                 | [点我查看](https://www.icode504.com/posts/83.html) |
| Redis远程连接工具TinyRDM安装、配置和卸载教程（Window版） | [点我查看](https://www.icode504.com/posts/85.html) |
| Redis远程连接工具TinyRDM安装、配置和卸载教程（macOS版）  | 敬请期待                                           |

### 二、Redis数据类型


| 教程名称                                  | 链接                                                |
| ----------------------------------------- | --------------------------------------------------- |
| Redis数据类型简介                         | 敬请期待                                            |
| Redis的key（键）相关操作                  | [点我查看](https://www.icode504.com/posts/86.html)  |
| Redis数据类型之字符串String               | [点我查看](https://www.icode504.com/posts/87.html)  |
| Redis数据类型之哈希Hash                   | [点我查看](https://www.icode504.com/posts/89.html)  |
| Redis数据类型之列表List                   | [点我查看](https://www.icode504.com/posts/91.html)  |
| Redis数据类型之集合Set                    | [点我查看](https://www.icode504.com/posts/92.html)  |
| Redis数据类型之有序集合Sorted Set（ZSet） | [点我查看](https://www.icode504.com/posts/93.html)  |
| Redis数据类型之位图Bitmap                 | [点我查看](https://www.icode504.com/posts/103.html) |
| Redis数据类型之基数统计HyperLogLog        | [点我查看](https://www.icode504.com/posts/106.html) |
| Redis数据类型之地理空间Geospatial         | 敬请期待                                            |
| Redis数据类型之流Stream                   | 敬请期待                                            |
| Redis数据类型之位域BitField               | 敬请期待                                            |

### 三、Redis持久化机制


| 教程名称                                 | 链接     |
| ---------------------------------------- | -------- |
| Redis持久化机制之RDB（Redis Database）   | 敬请期待 |
| Redis持久化机制之AOF（Append Only File） | 敬请期待 |
| Redis混合持久化（RDB + AOF）             | 敬请期待 |
| Redis纯缓存模式                          | 敬请期待 |

### 四、Redis事务和管道


| 教程名称  | 链接     |
| --------- | -------- |
| Redis事务 | 敬请期待 |
| Redis管道 | 敬请期待 |

### 五、Redis发布和订阅（了解即可）

撰写中，敬请期待

## Redis 集群版

### 七、Redis主从模式（replication）

撰写中，敬请期待

### 八、Redis哨兵模式（sentinel）

撰写中，敬请期待

### 九、Redis集群模式（cluster）

撰写中，敬请期待

### 十、SpringBoot集成Redis

撰写中，敬请期待

# 第二部分 Redis 进阶篇

撰写中，敬请期待

# 参考

链接中的知识点主要参考如下内容：

1. [Redis官方文档](https://redis.io/docs/latest/)
2. [【尚硅谷-周阳老师】Redis实战课程+面试题](https://www.bilibili.com/video/BV13R4y1v7sP)
