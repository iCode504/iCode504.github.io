---
abbrlink: '89'
banner_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
categories:
  - [数据库, 非关系型数据库(NoSQL), Redis, Redis数据类型]
date: '2024-07-31T06:34:32.871042+08:00'
description: Redis哈希类型介绍及其常用的命令
index_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
order: '50'
tags:
- Redis
title: Redis数据类型之哈希类型Hash
updated: '2024-08-05T22:40:07.526+08:00'
---
想学习更多Redis相关知识，请点击右侧链接查看Redis学习笔记：[点我查看](https://www.icode504.com/posts/90.html)

# 一、Redis哈希类型介绍

Redis的哈希（Hash）类型记录的是多个属性（field）及其对应的值（value）的集合，它本身仍然是键值对（key-value），但是value变为由多个field-value组成的结构，类似Java中的`Map<String, Map<String, Object>>`，下图是Redis哈希类型存储结构示意图：

![](https://source.icode504.com/images/image-eecffbe113d8b40c145632b548403706.png)

应用场景：早期购物车的应用。

- 新增商品使用HSET命令；
- 添加当前商品数量使用HINCRBY命令；
- 获取商品总数HLEN命令；
- 全部选择使用HGETALL命令；

# 二、Redis哈希类型常用命令

1\. 添加和修改key：

```bash
HSET key field value [field value ...]
```

该命令默认返回的是添加/修改field的个数：

![](https://source.icode504.com/images/image-cc58e26839d6f986cc6de8ef3b4eb1fb.png)

2\. 如果当前key中属性field不存在则创建，存在则不创建：

```bash
HSETNX key field value [field value ...]
```

![https://source.icode504.com/images/image-1cfb6a17bfe021a8169bb20c0f9f722e.png](https://source.icode504.com/images/image-1cfb6a17bfe021a8169bb20c0f9f722e.png)

3\. 获取当前的key中属性field对应的value

```bash
HGET key field
```

![](https://source.icode504.com/images/image-b8e6af5ed05803707bcf49d4621d8c85.png)

~~4. 添加和修改key（该命令已经在Redis 4.0.0以后已过时，推荐使用前面的HSET命令）~~

```bash
HMSET key field value [field value ...]
```

![https://source.icode504.com/images/image-8bfc512527b09d0918cd470b5605ed05.png](https://source.icode504.com/images/image-8bfc512527b09d0918cd470b5605ed05.png)

5\. 批量获取key中多个属性field对应的value

```bash
HGET key field [field ...]
```

![https://source.icode504.com/images/image-7ddfdc27260741f8f4514de943117f13.png](https://source.icode504.com/images/image-7ddfdc27260741f8f4514de943117f13.png)

6\. 获取当前key所有属性field对应的value：

```bash
HGETALL key
```

![https://source.icode504.com/images/image-5675c5babff9315db80d476f5307c056.png](https://source.icode504.com/images/image-5675c5babff9315db80d476f5307c056.png)

7\. 删除某一个key中的一个或多个属性field：

```bash
HDEL key field [field ...]
```

该命令默认返回的是删除数量：

![https://source.icode504.com/images/image-76ca30147ab2b6e4e39aba0c99aa445b.png](https://source.icode504.com/images/image-76ca30147ab2b6e4e39aba0c99aa445b.png)

8\. 获取当前key所拥有的属性field的数量：

```bash
HLEN key
```

![https://source.icode504.com/images/image-1f7f715bde5db10cb704763671d05863.png](https://source.icode504.com/images/image-1f7f715bde5db10cb704763671d05863.png)

9\. 判断当前key中里面是否存在某个属性field：

```bash
HEXISTS key field
```

![https://source.icode504.com/images/image-9d7ca9906140236a1bcf9aa7455b0db3.png](https://source.icode504.com/images/image-9d7ca9906140236a1bcf9aa7455b0db3.png)

10\. 获取当前key所有属性field名称：

```bash
HKEYS key
```

![https://source.icode504.com/images/image-1f4de46415af27494e4111960adb5677.png](https://source.icode504.com/images/image-1f4de46415af27494e4111960adb5677.png)

11. 获取当前key所有属性对应的值value：

```bash
HVALS key
```

![https://source.icode504.com/images/image-02a60584eb3b472d2c55be2de7969c36.png](https://source.icode504.com/images/image-02a60584eb3b472d2c55be2de7969c36.png)

12\. 将当前key中某个属性field对应的**整数值**进行增加操作：

```bash
HINCRBY key field increment
```

该命令默认返回的是增加后的结果：

![https://source.icode504.com/images/image-4d6c76c473713f84c87341b8be05a548.png](https://source.icode504.com/images/image-4d6c76c473713f84c87341b8be05a548.png)

使用HINCRBY也可以执行减少操作，将increment对应的值改成负数即可：

![https://source.icode504.com/images/image-4e4661b57cad5ec06992439634323bbf.png](https://source.icode504.com/images/image-4e4661b57cad5ec06992439634323bbf.png)

如果key不存在，那么则执行创建操作；如果key存在，而field不存在，此时会创建一个field，并对field的值由0设置为对应的值：

![https://source.icode504.com/images/image-4988ba12daa7df5cad133c4681d52855.png](https://source.icode504.com/images/image-4988ba12daa7df5cad133c4681d52855.png)

13\. 将当前key中某个属性field对应的小数值进行增加操作：

```bash
HINCRBYFLOAT key field increment
```

HINCRBYFLOAT命令的特性基本上和HINCRBY命令相同：

![https://source.icode504.com/images/image-52b730c8cc642cf39681fd9a7a751c89.png](https://source.icode504.com/images/image-52b730c8cc642cf39681fd9a7a751c89.png)

# 三、使用Redis哈希类型的注意事项

1\. 大部分的Redis哈希类型的命令的时间复杂度是$O(1)$，少部分命令，例如：

- HKEYS
- HVALS
- HGETALL

这些命令的时间复杂度是$O(n)$，因为它们需要遍历当前key中所有的fields。

2\. 哈希类型理论上可以存储$2^{32}-1$个键值对，但是实际上，这个存储上限取决于你的Redis实际在内存中占用的空间大小。
