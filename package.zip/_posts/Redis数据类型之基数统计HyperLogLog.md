---
abbrlink: '106'
banner_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
categories:
- 数据库
- 非关系型数据库(NoSQL)
- Redis
- Redis数据类型
date: '2024-08-29T16:24:18.522149+08:00'
description: Redis基数统计类型HyperLogLog介绍和常用命令
index_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
order: '100'
tags:
- Redis
title: Redis数据类型之基数统计HyperLogLog
updated: '2024-08-30T16:00:51.228+08:00'
---
想学习更多Redis相关知识，请点击右侧链接查看Redis学习笔记：[点我查看](https://www.icode504.com/posts/90.html)

# 一、Redis 基数统计类型（HyperLogLog）介绍

Redis HyperLogLog是一种概率型数据结构，用于统计当前集合的近似基数，它以完美的准确性换取了高效的空间利用率。

> 这里说的基数指的是集合中不重复元素数量。

统计集合中唯一数据项的数量通常和内存使用量成正比。也就是说，查询的唯一数据项的数量越多，消耗的内存也越多。一种简单暴力的方法就是我们记住都存储了那些元素，以避免多次计数，但是很显然，这并不是一个现实的选择。

有一种可以通过内存换取精度的算法，这个算法会返回一个带有标准误差的统计基数。Redis在使用HyperLogLog统计数据的情况下，标准误差小于1%。使用这个算法的好处在于，你不需要考虑统计数据所消耗内存的问题，所消耗的内存量是恒定的，最多也不超过12KB。如果你的数据很小，所需要的内存量也要比12KB小很多。

HyperLogLog最多使用**12KB**的内存空间，标准误差是**0.81%**。

从技术层面而言，HyperLogLog是一种不同的数据结构，但实际上编码仍然是字符串（String）：

![](https://source.icode504.com/images/image-b377ad022070b3d4538e10c50b6b9eca.png)

应用场景：

- 统计网站、文章等UV；

> UV，英文全称Unique Visitor，独立访客，一般理解为客户端IP，需要去重。
>
> 例如：某个IP今天访问了50次网站[https://www.icode504.com](https://www.icode504.com)，那么该网站在最终统计UV时，该IP的访问次数是1次。

- 统计用户搜索网站关键词数量；
- 统计用户每天搜索不同词条的次数；
- ……

# 二、Redis 基数统计类型（HyperLogLog）常用命令

1\. 添加指定一个或多个元素：

```bash
PFADD key [element [element ...]]
```

![](https://source.icode504.com/images/image-61b2bab03b649a7e0f345eaefb04491b.png)

2\. 统计当前HyperLogLog的基数估算值：

```bash
PFCOUNT key [key ...]
```

PFCOUNT统计基数时，如果数据量较大时会存在最大0.81%误差。

- 如果参数只有一个key，那么统计的是当前集合的近似基数，如果key不存在，那么返回结果是0。

![](https://source.icode504.com/images/image-0732657f8c6dd7bb566bbc49b81ac4b3.png)

- 如果参数有多个key，此时这些HyperLogLog先进行并集运算，再存储到一个临时的HyperLogLog，统计好数量以后，返回最终统计的近似基数：

![](https://source.icode504.com/images/image-60427d59d0d06e71a91fcc8f1840510d.png)

3\. 将多个HyperLogLog合并为一个HyperLogLog（并集运算）：

```bash
PFMERGE destkey sourcekey ...
```

![](https://source.icode504.com/images/image-c31916fcd8d7887e294e9af22016c49b.png)
