---
abbrlink: '92'
banner_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
categories:
- 数据库
- 非关系型数据库(NoSQL)
- Redis
- Redis数据类型
date: '2024-08-06T08:37:51.939234+08:00'
description: Redis集合类型介绍及其常用的命令
index_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
order: '70'
tags:
- Redis
title: Redis数据类型之无序集合类型Set
updated: '2024-08-08T13:41:49.463+08:00'
---
想学习更多Redis相关知识，请点击右侧链接查看Redis学习笔记：[点我查看](https://www.icode504.com/posts/90.html)

# 一、Redis集合类型介绍

**Redis集合（Set）中的成员是唯一且无序的**，成员（Member）是Redis集合的组成单位，多个成员组成了集合。Redis集合类型在以下场景中使用效率较高：

- 记录当前用户访问网站页面时的IP地址；
- 社交APP中推荐可能认识的人；
- 查看微信朋友圈点赞的朋友；

# 二、Redis集合类型常用命令

## 2.1 单个集合操作命令

1\. 添加一个或多个成员：

```bash
SADD key member [member ...]
```

返回结果是成功添加到当前集合成员的个数：

![https://source.icode504.com/images/image-7cef9761aa2b9fc3670a4f27f0c2d53e.png](https://source.icode504.com/images/image-7cef9761aa2b9fc3670a4f27f0c2d53e.png)

2\. 遍历集合中所有的成员：

```bash
SMEMBERS key
```

![https://source.icode504.com/images/image-a9b70a94d0b56a40dce689e0f2b67755.png](https://source.icode504.com/images/image-a9b70a94d0b56a40dce689e0f2b67755.png)

3\. 判断当前成员是否在集合中：

```bash
SISMEMBER key member
```

如果当前集合中存在该成员，返回结果是1；如果不存在，返回结果是0：

![https://source.icode504.com/images/image-325cf1a904c2c15f701c28584e6ee82b.png](https://source.icode504.com/images/image-325cf1a904c2c15f701c28584e6ee82b.png)

4\. 删除一个或多个成员：

```bash
SREM key member [member ...]
```

默认返回的是成功删除的成员数量：

![https://source.icode504.com/images/image-cce5054ee9a745b0a403f4d8d6215dcd.png](https://source.icode504.com/images/image-cce5054ee9a745b0a403f4d8d6215dcd.png)

5\. 获取集合中成员数量：

```bash
SCARD key
```

![https://source.icode504.com/images/image-fa2c920cae97b9df5c2dab47cb3f0661.png](https://source.icode504.com/images/image-fa2c920cae97b9df5c2dab47cb3f0661.png)

6\. 从集合中随机展现1个或多个成员作为展示（**不执行删除操作**）：

```bash
SRANDMEMBER key [count]
```

count可以分成如下情况（假设集合的长度是`set.length`并且$set.length \geq 1$）

- 如果count没有值，那么随机展示一个成员；
- 如果count在$[1, set.length)$中，那么展示count个成员；
- 如果$count\geq set.length$，那么展示当前集合所有的成员；
- 如果$count<0$，此时随机展示|count|个元素，展示过程中，可能出现成员重复的情况：

以下是SRANDMEMBER的使用演示：

![https://source.icode504.com/images/image-f25c93d5fa489c4acab46e42c375084f.png](https://source.icode504.com/images/image-f25c93d5fa489c4acab46e42c375084f.png)

7\. 从集合中随机弹出一个或多个成员：

```bash
SPOP key [count]
```

如果不指定count，默认只弹出一个成员；指定count可以弹出多个成员：

![https://source.icode504.com/images/image-5a3391a5b8a7dc2203ade48b472e168e.png](https://source.icode504.com/images/image-5a3391a5b8a7dc2203ade48b472e168e.png)

## 2.2 多个集合操作命令

1\. 将当前集合中已经存在某个成员赋值给另一个集合：

```bash
SMOVE source destination member
```

![](https://source.icode504.com/images/image-c26af97efba88bf7e2a595852cb865ee.png)

2\. 集合的差集运算（$A-B$）：

```bash
SDIFF key [key ...]
```

![https://source.icode504.com/images/image-acef2a21c121fcd6954763c73553768c.png](https://source.icode504.com/images/image-acef2a21c121fcd6954763c73553768c.png)

3\. 集合的并集运算（$A\cup B$）：

```bash
SUNION key [key ...]
```

![https://source.icode504.com/images/image-e8c9847b0aae57d8d4fec7d52492bf36.png](https://source.icode504.com/images/image-e8c9847b0aae57d8d4fec7d52492bf36.png)

4\. 集合的交集运算（$A \cap B$）：

```bash
SINTER key [key ...]
```

![https://source.icode504.com/images/image-eb6fe0b6d739b14db810df5e96d35505.png](https://source.icode504.com/images/image-eb6fe0b6d739b14db810df5e96d35505.png)

# 三、Redis集合类型的使用事项

1\. Redis集合最大可以存储$2^{32}-1$个元素。

![https://source.icode504.com/images/image-2462e9a545ecbe5797ef4616dcaeb797.png](https://source.icode504.com/images/image-2462e9a545ecbe5797ef4616dcaeb797.png)

2\. 大多数和集合相关的命令在执行过程中效率较高。然而，如果集合中几十万几百万的数据时，需要谨慎使用SMEMBERS命令，因为命令在执行过程中的时间复杂度是$O(n)$。为了解决上述问题，可以使用SSCAN命令（后续会讲到）获取到集合中所有成员。
