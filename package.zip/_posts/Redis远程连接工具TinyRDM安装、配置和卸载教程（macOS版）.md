---
abbrlink: '110'
banner_img: https://source.icode504.com/images/Redis远程连接工具TinyRDM安装、配置和卸载教程（Window版）.png
categories:
- 软件安装
- macOS
- TinyRDM
date: '2024-09-30T13:56:56.555185+08:00'
description: 本教程详细介绍了在macOS系统上安装、配置和卸载Redis远程连接工具TinyRDM的步骤，包括下载安装包、配置连接Redis实例以及卸载程序的操作指南，帮助用户轻松管理Redis数据库。
index_img: https://source.icode504.com/images/Redis远程连接工具TinyRDM安装、配置和卸载教程（Window版）.png
order: ''
tags:
- Redis
- macOS
- TinyRDM
title: Redis远程连接工具TinyRDM安装、配置和卸载教程（macOS版）
updated: '2024-09-30T15:13:44.872+08:00'
---
TinyRDM是一款轻量级的Redis数据库管理工具，提供了用户友好的图形界面，便于开发者和数据库管理员进行Redis数据库的连接、管理和监控。它支持多种Redis命令操作，提供丰富的可视化功能，直观地展示数据结构和存储信息。TinyRDM简洁高效，适合日常的Redis管理工作。

以下是macOS环境下安装Tiny RDM教程：

# 一、准备操作

1\. 请确保Linux操作系统上安装了Redis，需要安装的小伙伴点击右侧链接查看安装教程：[点我查看](./83.html)

2\. 检查本机信息：点击左上角苹果logo，点击第一个**关于本机**：

![](https://source.icode504.com/images/image-20240224151904945.png)

这里需要留意一下处理器信息，这里我的电脑使用的是Intel芯片：

![](https://source.icode504.com/images/image-20240224152112087.png)

# 二、下载RDM

1\. 打开Tiny RDM官网：[点我查看](https://redis.tinycraft.cc/zh/)

2\. 鼠标移到**下载安装**按钮，使用Intel芯片的小伙伴点击蓝色框链接下载，使用M1及之后的芯片的小伙伴点击绿色框链接下载：

![](https://source.icode504.com/images/image-912eed7de70f93a1c913f9f9aad2e120.png)

# 三、安装Tiny RDM

1\. 打开dmg文件后，将Tiny RDM拖入到Applications中即可完成安装：

![](https://source.icode504.com/images/image-1250bf5e08e01647c68f560a1be3f8a8.gif)

2\. 在程序坞中找到Tiny RDM并打开：

![](https://source.icode504.com/images/image-83cdfa7a1d06315fe99cdf484ad555de.png)

3\. 此时会弹出一个错误信息：**无法打开“Tiny RDM”，因为它来自身份不明的开发者。**（没有这个错误信息并且能正常打开上述软件包的小伙伴请此链接查看后续步骤：[点我查看](./110.html#%E5%9B%9B%E3%80%81%E4%BD%BF%E7%94%A8Tiny-RDM%E8%BF%9C%E7%A8%8B%E8%BF%9E%E6%8E%A5Redis)）我们需要解决这个问题：

![](https://source.icode504.com/images/image-a1ee1e6ad1c45188fda07bed08c013e3.png)

4\. 点击左上角苹果logo，然后点击**系统设置**：

![](https://source.icode504.com/images/image-20240224155139125.png)

5\. 点击**左侧隐私与安全性**，向下找安全性中有一个提示信息：已阻止使用“Tiny RDM”，因为它来自身份不明的开发者。点击提示信息下方的**仍要打开**：

![](https://source.icode504.com/images/image-f8f9f6de304816c7f2ef712073070e48.png)

6\. 输入本机的用户名和密码，完成后点击**修改设置**：

![](https://source.icode504.com/images/image-20240224155514630.png)

7\. 此时会弹出一个提示，直接点击**打开**即可，此时就可以正常启动Tiny RDM了：

![](https://source.icode504.com/images/image-486edc8b66dd637581a97279babfd92c.png)

# 四、使用Tiny RDM远程连接Redis

1\. 在桌面上打开Tiny RDM，点击左下角的加号，新建一个Redis连接：

![](https://source.icode504.com/images/image-8eb086d385bd77677e61b291464260bf.png)

2\. 按照下图所示操作，配置Redis的连接配置，完成后点击左下角的**测试连接**：

![](https://source.icode504.com/images/image-5f52a47a8b58ea3606d615f8dbd4737c.png)

3\. 如果下方弹出提示“成功连接到Redis服务器”就说明前面的Redis配置没有问题，此时我们点击右下角的确认就可以使用Redis了：

![](https://source.icode504.com/images/image-2e1872a9dac580830efd657e8e03d8cb.png)

4\. 双击左侧的Redis连接，再点击控制台，我们就可以正常使用Redis命令了：

![](https://source.icode504.com/images/image-e69cbbaec6fcf640e0fca44ae8e6d89b.png)

![](https://source.icode504.com/images/image-ce17051a4ad9fa5e8e7760faea13b289.png)

# 五、卸载Tiny RDM

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](./31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开程序最左边的访达，在最左侧点击应用程序：

![](https://source.icode504.com/images/image-20240714213011161.png)

2\. 找到Tiny RDM，按照下图所示操作将 IDEA 拖入到废纸篓中：

![](https://source.icode504.com/images/image-9fcda45ef1d40d96d581bfeee4820a29.gif)

3\. 打开废纸篓，鼠标右键点击Tiny RDM图标，选择**立即删除**，Tiny RDM就成功卸载了：

![](https://source.icode504.com/images/image-5426bfded19e272978d8b688647d592b.png)

此时会弹出一个弹窗提示，点击**删除**即可彻底卸载：

![](https://source.icode504.com/images/image-1321d3a887520019dfeb6f8fb9d10a71.png)
