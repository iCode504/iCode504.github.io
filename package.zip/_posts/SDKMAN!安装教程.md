---
abbrlink: '108'
banner_img: https://source.icode504.com/images/image-4b4c0944dfb6fc11f6d98d3605522599.png
categories:
- - 软件安装
  - macOS
  - 软件包管理工具
- - 软件安装
  - Linux
  - 软件包管理工具
date: '2024-09-04T21:32:40.682+08:00'
description: SDKMAN! 是一个用于管理开发人员工具的多平台命令行工具，支持版本切换和安装。它简化了JVM、Gradle、Maven等SDK的安装和更新，适用于Linux、macOS和Windows子系统。
index_img: https://source.icode504.com/images/image-4b4c0944dfb6fc11f6d98d3605522599.png
order: ''
tags:
- SDKMAN!
- 软件包管理工具
title: SDKMAN!安装教程
updated: '2024-09-05T17:31:11.598+08:00'
---
[SDKMAN!](https://sdkman.io/)，全称The Software Development Kit Manager，中文翻译过来就是**软件开发工具包管理器**。以下是官网对这款工具的介绍（个人翻译）：

认识一下SDKMAN!——你的可靠伙伴，它可以高效管理Unix系统上众多的软件开发工具包。假设您的系统上存在不同版本的软件开发工具包（SDKs），需要以一种无压力的方式在他们之间切换，SDKMAN!以简单易用的命令行界面（CLI）和API能介入上述过程。以前称作GVM，Groovy enVironment Managener（Groovy环境管理器），SDKMAN!从类似工具apt、pip、RVM、rbenv甚至是Git上获取灵感。将其视为您的一个乐于助人的朋友，随时为您准备简化SDK管理。

- 源于开发者，为开发人员着想。简化SDK生命周期，不需要再寻找下载源，提取归档或添加修改`_HOME`和`PATH`等环境变量。
- 一站式直接搞定所有和Java相关工具下载安装。可以安装基于JVM的软件开发工具包，例如：Java、Scala、Kotlin和Groovy、Ant、Gradle、Grails、Maven、SBT、Spark、Spring Boot、Vert.x和其他框架工具也支持。
- 轻量级。SDKMAN!使用Rust和bash编写，并且系统上只需要有`curl`、`zip`和`unzip`三个依赖即可。甚至可以和ZSH一起工作。
- 多平台。跨各种基于UNIX平台无缝操作，包括**macOS、Linux、Windows下的Linux子系统**（WSL）。
- APIs。通过使用我们的开放的Broker API，可以轻松编写新的客户端。软件提供者可以通过安全的Vendor API来发布和声明自己的软件版本。
- 开源。SDKMAN!的研发离不开开源社区成员们的努力。Apache 2.0下的协议。

接下来就为大家介绍一下SDKMAN!的安装和使用：

# 一、准备操作

请确保您的操作系统是Linux/macOS/WSL，需要安装的小伙伴可以根据自己的需要查看安装教程：


|                       CentOS                       |                       Ubuntu                       |                       Debian                       |                        WSL                        |
| :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: |
| [点我查看](https://www.icode504.com/posts/94.html) | [点我查看](https://www.icode504.com/posts/51.html) | [点我查看](https://www.icode504.com/posts/52.html) | [点我查看](https://www.icode504.com/posts/42.html) |

# 二、安装SDKMAN!

## 方式一：国内用户安装

> 说明：推荐国内用户使用，我在官方脚本上稍微做了一下改进。

1\. 打开命令行，执行如下命令即可安装SDKMAN!

```bash
curl -s "https://gitee.com/iCode504/my-sdkman/raw/master/install.sh" | bash
```

2\. 安装完成，执行如下命令让SDKMAN!相关命令生效：

```bash
source "$HOME/.sdkman/bin/sdkman-init.sh"
```

3\. 执行如下命令即可查看SDKMAN!的版本：

```bash
sdk v
```

![](https://source.icode504.com/images/image-8a3663e0c689f82dba9e907ea23a1d64.png)

## 方式二：正常安装

> 说明：国内用户不推荐使用，因为需要从Github上下载安装包，Github在国内访问速度较慢，下载可能会失败。

安装SDKMAN!非常简单，只需要在命令行（macOS请打开终端执行命令）界面运行几行代码就OK了。

1\. 请先确保电脑本机上已经安装了`curl`、`zip`、`unzip`、`axel`

- CentOS：

```shell
yum -y install curl zip unzip
```

- Ubantu/Debian：

```shell
apt -y install curl zip unzip
```

2\. 打开命令行窗口，在命令行中输入如下命令并执行：

```shell
curl -s "https://get.sdkman.io" | bash
```

因为这款软件是下载源在国外，下载速度较慢，请耐心等待！

3\. 出现下面提示即说明SDKMAN!安装成功：

![](https://source.icode504.com/images/image-20231227153819937.png)

如果安装失败，执行如下命令删除残留文件重新执行上一步命令：

```bash
rm -rf ./sdkman
```

4\. 我们在命令行再执行如下命令，方便后续我们使用SDKMAN!相关的命令：

```shell
source "$HOME/.sdkman/bin/sdkman-init.sh"
```

5\. 此时在命令行输入如下命令，就可以看到SDKMAN!的版本信息：

```shell
sdk v
```

![](https://source.icode504.com/images/image-20231227154230369.png)

# 三、卸载SDKMAN!（可选）

卸载SDKMAN!也非常简单！只需要几步就可以完成：

1\. （可选）如果后续还想使用SDKMAN!，可以对当前`./sdkman`目录打包成tar文件：

```shell
tar zcvf ~/sdkman-backup_$(date +%F-%kh%M).tar.gz -C ~/ .sdkman
```

2\. 使用`rm -rf`命令强制删除：

```shell
rm -rf ~/.sdkman
```
