---
title: Tomcat安装配置教程（Windows版）
tags:
  - Tomcat
  - Windows
category_bar: true
archive: false
abbrlink: 64
description: 本文介绍了Tomcat下载与安装，配置环境变量和启动，添加了Tomcat启动过程中乱码的解决方案。
banner_img: https://source.icode504.com/images/Tomcat安装配置教程（Windows版）.png
index_img: https://source.icode504.com/images/Tomcat安装配置教程（Windows版）.png
category: 
  - 软件安装
  - Windows
  - 服务器&虚拟机
date: 2024-04-07 17:07:48
password:
---


Apache Tomcat（以下简称Tomcat）是一个开源的、轻量级的、容器式的Java Servlet容器。它是由Apache软件基金会开发的，用于托管Java Servlets和JavaServer Pages（JSP）的Web应用程序。Tomcat提供了一个环境，使开发者能够运行Java代码，以便构建动态的Web应用程序。作为一个Servlet容器，Tomcat可以在服务器上运行Java Servlets和JSP页面，通过处理HTTP请求和响应来动态生成网页内容。它是Java企业版（Java EE）规范的一个实现，并且易于安装和配置，因此被广泛用于Java Web应用程序的开发和部署。Tomcat还具有良好的可扩展性和灵活性，可以与其他Java框架和工具集成，以满足不同的需求。

以下是Windows环境下Tomcat的下载、安装与配置教程：

# 一、安装前准备

1\. 检查电脑上是否安装JDK，如果没有安装，请查看JDK安装教程：[点我查看](https://zhuanlan.zhihu.com/p/626465440)

2\. 如果电脑上已经安装JDK，按<kbd>Win</kbd> 和<kbd>R</kbd>键，输入`cmd`，然后点击**确定**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230508205645141.png)

3\. 输入`java -version`，按一下`回车`，查看JDK安装信息，如果有下面提示信息，说明JDK安装成功

![img](https://mypicture0706.oss-cn-beijing.aliyuncs.com/v2-3fca64e63e8d136f76373193158d9089_720w.webp)

4\. 推荐使用NDM（Neat Download Manager）下载文件，可以加快下载速度（推荐）。如需使用此款软件的小伙伴，可以查看这篇教程：[下载神器NDM（Neat Download Manager）安装配置教程（适用于Windows和MacOS）](https://www.icode504.com/posts/24.html)

# 二、下载并安装Tomcat

1\. 点击右侧链接进入Tomcat官网下载页面：[点我查看](https://archive.apache.org/dist/tomcat/)

2\. 这里我下载的是Tomcat 8版本，点击`tomcat-8`文件夹：

![](https://source.icode504.com/images/image-20240328171551789.png)

3\. 这里我选择的是8.5.100版本的Tomcat：

![](https://source.icode504.com/images/image-20240328171745250.png)

4\. 点击第一个文件夹`bin`进入：

![](https://source.icode504.com/images/image-20240328171822840.png)

5\. 按照下图所示下载安装包：

![](https://source.icode504.com/images/image-20240328172006970.png)

6\. 将下载好的Tomcat安装包解压，建议解压在C盘以外的位置，路径只包含英文字符，这里我解压到了D盘：

![](https://source.icode504.com/images/image-20240328173336823.png)

7\. 至此，Tomcat安装完成。

# 三、配置环境变量

1\. 找到Tomcat的解压位置，出现bin、conf、lib等文件夹，点击上方路径，**鼠标右键**点击**复制**：

![](https://source.icode504.com/images/image-20240328173701038.png)

2\. 打开文件夹，在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://source.icode504.com/images/Snipaste_2024-01-01_01-07-23.png)

3\. 点击**高级系统设置**：

|   Windows 11   | ![](https://source.icode504.com/images/image-20240101010932039.png) |
| :------------: | ------------------------------------------------------------ |
| **Windows 10** | ![](https://source.icode504.com/images/image-20240101011132186.png) |

4\. 点击**环境变量**：

![](https://source.icode504.com/images/image-20230314134716166.png)

5\. 在下方系统变量中，点击**新建**：

![](https://source.icode504.com/images/image-20230314134919881.png)

6\. 新建环境变量，变量名填写**CATALINA_HOME**，将前面复制的路径粘贴到变量值。按照图示操作即可：

![](https://source.icode504.com/images/image-20240416134746024.png)

7\. 双击**Path**进入：

![](https://source.icode504.com/images/image-20230314135756989.png)

8\. 按照图示操作即可，然后一路点击确定。

![](https://source.icode504.com/images/image-20240328174131191.png)

# 四、启动Tomcat

1\. 找到Tomcat安装路径，然后点击进入`bin`文件夹，然后双击`startup.bat`文件启动Tomcat：

![](https://source.icode504.com/images/image-20240407160936012.png)

2\. 出现最后一行提示说明Tomcat启动成功：

![image-20240328174458119](https://source.icode504.com/images/image-20240328174458119.png)

3\. 如需关闭Tomcat，只需要将当前窗口关闭即可。

# 五、Tomcat启动过程中乱码问题解决（可选）

在上一部分内容中，Tomcat启动窗口的中文内容出现了乱码现象，其本身原因是因为控制台默认的编码集是`GBK`，而Tomcat日志配置文件中设置的编码集是`UTF-8`，二者编码集并不一致从而导致了上述现象。当然这不影响我们正常使用Tomcat，要想解决二者编码集不一致的问题，要么将Tomcat日志编码集修改成和系统中编码集保持一致，要么系统的编码集和Tomcat的编码集保持一致。这里我使用的是第一种方案（第二种方案需要改系统的注册表，比较麻烦不说，很有可能一改就翻车）：

1\. 打开Tomcat安装路径，点击`conf`文件夹进入：

![](https://source.icode504.com/images/image-20240328174800314.png)

2\. 鼠标右键点击`logging.properties`，打开方式选择记事本打开：

![](https://source.icode504.com/images/image-20240328175337169.png)

![](https://source.icode504.com/images/image-20240328175414633.png)

3\. 按<kbd>Ctrl</kbd>和<kbd>H</kbd>键，进入替换页面，替换内容填写**UTF-8**，替换为填写**GBK**，然后点击**全部替换**。完成后关闭替换窗口：

![](https://source.icode504.com/images/image-20240407160507929.png)

4\. 按<kbd>Ctrl</kbd>和<kbd>S</kbd>键保存文件。此时再按照第四部分内容重新启动Tomcat，此时输出的中文内容就不会出现乱码现象了：

![](https://source.icode504.com/images/image-20240407160813956.png)

# 六、参考

- 解决Tomcat中文乱码问题——windows平台：https://cloud.tencent.com/developer/article/2181734
