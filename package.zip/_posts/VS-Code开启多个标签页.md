---
title: VS Code开启多个标签页
tags:
  - VS Code
category_bar: true
archive: false
abbrlink: 54
description: VS Code在设置中开启多个标签页和多个标签页换行显示
category:
  - VS Code
  - 使用技巧
date: 2024-03-01 13:43:43
banner_img:
index_img:
password:
---


# 一、VS Code开启多个标签页

VS Code在打开多个文件时，总是使用一个页签显示，这对于切换多个标签页的小伙伴很不友好

![](https://source.icode504.com/images/240301006.gif)

打开左下角小齿轮，点击设置：

![](https://source.icode504.com/images/image-20240301115459948.png)

在左侧找到工具台-->编辑管理，将**Enable Preview From Quick Open**取消勾选：

![](https://source.icode504.com/images/image-20240301115739501.png)

# 二、VS Code开启多个标签页换行显示

在设置上方搜索框中搜索wrapTabs，将第一个搜索结果**Workbench > Editor: Wrap Tabs**勾选：

![](https://source.icode504.com/images/image-20240301133726842.png)

此时打开多个标签页时就会换行显示了：

![](https://source.icode504.com/images/240301007.gif)
