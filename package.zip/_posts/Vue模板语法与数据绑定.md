---
title: Vue模板语法与数据绑定
tags:
  - Vue
category_bar: true
archive: true
abbrlink: 910428078
password: 123456
date: 2024-02-11 09:32:07
description:
banner_img:
index_img:
category: [Vue, Vue基础知识]
---


# 一、模板语法

## 1.1 插值语法

Vue实例中的数据要想显示到容器中，插值语法是<u>实现数据绑定一种实现方式</u>。Vue使用的是Mustache语法（双大括号）实现**文本**插值，在容器中示例语法如下：

```html
<span>你好，我是{{name}}<span>
```

其中，`{{name}}`就是插值表达式。插值表达式必须要写成JS表达式的形式。

1\. 在`{{}}`中，如果内部写的是变量名，需要和Vue实例中`data`定义的内部属性一一对应。以上面内容为例，插值表达式中的变量名`name`必须要在对应的Vue实例的`data`属性对象中定义，否则会提示这个插值表达式并没有在Vue实例中定义。

2\. 当然，双大括号`{{}}`中也可以写JS表达式（编写过程中需要遵守JS表达式规则），例如：`1 + 1`、`new Date().getTime()`在JS中都算作表达式，可以出现在插值语法中。

```html
<div id="app">
    {{name}}的第一个程序，{{1 + 1}}, {{new Date().getTime()}}
</div>

<script>
  new Vue({
    el: '#app',
    data: {
      name: 'iCode504'
    }
  });
</script>
```

![](https://source.icode504.com/images/image-20231127175936830.png)

3\. 插值语法只能替换普通文本，如果你在Vue示例中定义了HTML语句，最终只会以普通文本的效果进行展示，没有HTML自身的效果：

```html
<div id="app">
    {{htmlContent}}
</div>

<script>
  new Vue({
    el: "#app",
    data() {
      return {
        // 带有CSS样式的HTML语句到容器中渲染
        htmlContent: '<span style="color: #FF0000;">这是一段HTML内容</span>'
      };
    },
  });
</script>
```

运行效果最终会以普通文本显示：

![](https://source.icode504.com/images/image-20240206141036897.png)

要想解决这一问题，我们需要使用`v-html`指令（该指令后续会讲到）对源代码进行改造：

```html
<div id="app">
    <!-- 使用v-html指令 -->
    <span v-html="htmlContent"></span>
</div>

<script>
  new Vue({
    el: "#app",
    data() {
      return {
        htmlContent: '<span style="color: #FF0000;">这是一段HTML内容</span>'
      };
    },
  });
</script>
```

此时我们就可以在页面查看到CSS样式了：

![](https://source.icode504.com/images/image-20240206142451171.png)

要谨慎使用`v-html`指令，因为随意添加HTML语句可能会导致[XSS攻击](https://baike.baidu.com/item/XSS%E6%94%BB%E5%87%BB/954065?fr=ge_ala)，只能对可信的HTML内容进行插值，绝不可对用户提供的内容使用插值语法。

## 1.2 指令语法

Vue中的指令（Directives）是以`v-`作为前缀（例如：`v-bind`、`v-if`等等都是Vue内置的指令）。指令的主要作用是当表达式的值发生改变时所产生的影响作用于页面（DOM）。例如：

```html
<p v-if="seen">这是一段内容</p>
```

根据表达式`seen`的结果是否插入/删除`p`标签中的元素。

一个指令可以接受一个“参数”（这里说的参数指的是HTML标签中的属性），在指令后面使用冒号表示。例如：

```html
<input type="text" v-bind:value="content" />
```

上述案例中`value`即是HTML标签`input`的属性，也是`v-bind`指令对应的参数。上述指令的作用是将Vue实例中data属性对象中的content属性值渲染到`input`标签框中。

# 二、数据绑定

Vue中有两种数据绑定的方式：单向数据绑定和双向数据绑定。

## 2.1 单向数据绑定v-bind

1\. 单项数据绑定，简称单项绑定（v-bind）：数据只能从Vue实例中的data流向页面。

语法格式：<font color='#39C5BB'>v-bind:属性名="data中的属性名"</font>或者<font color='#39C5BB'>:属性名="data中的属性名"</font>

> 这里说的属性名指的是HTML标签的属性名称；data中的属性名称指的是Vue实例中data对象的属性名称。

![](https://source.icode504.com/images/Vue%E5%8D%95%E9%A1%B9%E6%95%B0%E6%8D%AE%E7%BB%91%E5%AE%9A.drawio.svg)

```html
<div id="app">
  <input type="text" v-bind:value="content" />
</div>
<script>
  new Vue({
    el: "#app",
    data: {
      content: "你好，我是iCode504，程序猿一枚，请多指教",
    },
  });
</script>
```

运行效果如下图所示：

![](https://source.icode504.com/images/image-20240206162120434.png)

如何证明单项数据绑定：在当前页面按<kbd>F12</kbd>打开开发者工具，在最右侧找到Vue，此时我们可以看到Root节点（也就是根节点）data对象中定义的内容：

![](https://source.icode504.com/images/image-20240206162328547.png)

我们可以对data中的属性值进行修改：双击`content`属性值进行修改，点击右侧的保存按钮（或者直接按回车<kbd>Enter</kbd>），我们发现页面中输入框的内容也随之发生了变动：

![](https://source.icode504.com/images/240206002.gif)

反过来，我们在页面的输入框中输入内容，下面Vue实例的data对象中的属性值并没有发生变化：

![](https://source.icode504.com/images/240206003.gif)

2\. `v-bind`有简化写法：语法格式`:参数`。例如：`v-bind:href="xxx"`可以简写为`:href="xxx"`，xxx同样要写成JS表达式，并且可以直接读取到data中对应的属性。

```html
<div id="app">
  <!-- 简化写法 -->
  <input type="text" :value="content" />
</div>

<script>
  new Vue({
    el: "#app",
    data: {
      content: "你好，我是iCode504，程序猿一枚，请多指教！",
    },
  });
</script>
```

## 2.2 双向数据绑定v-model

双向绑定（`v-model`）：数据不仅能从data流向页面，还可以从页面流向data。

语法格式：<font color='#39C5BB'>v-model:属性名="data中的属性名"</font>或者<font color='#39C5BB'>v-model="data中的属性名"</font>（后者属于简化写法，推荐使用）

> 语法格式中的属性名指的是HTML标签对应的属性名，大多数情况下是`input`标签中的`value`属性。

![](https://source.icode504.com/images/Vue%E5%8F%8C%E5%90%91%E6%95%B0%E6%8D%AE%E7%BB%91%E5%AE%9A.drawio.svg)

```html
<div id="app">
  <input type="text" v-model:value="content" />
</div>

<script>
  new Vue({
    el: "#app",
    data: {
      content: "你好，我是iCode504，程序猿一枚，请多指教！",
    },
  });
</script>
```

证明双向数据绑定：按<kbd>F12</kbd>打开开发者工具，在右侧找到Vue开发者工具。首先我们在上方的输入框中随意修改内容会导致下方Vue实例中的数据发生变动：

![](https://source.icode504.com/images/240207001.gif)

同理，修改Vue实例中的数据，也会导致输入框中的数据发生变动：

![](https://source.icode504.com/images/240207002.gif)

双向绑定一般都应用在表单类元素上（包含value属性的标签），例如：`input`、`select`等。

`v-model:value`可以简写成`v-model`，因为`v-model`默认收集的就是标签中默认包含value属性的值。上述内容的输入框中的写法可以简化：

```html
<input type="text" v-model="content" />
```

`v-model`本质是语法糖。

> 语法糖是一种编程语言的设计特性，提供了一种更简洁、更易读的语法形式，使得代码编写更加方便，但本质上并没有引入新的功能或改变语言的行为。这种语法上的改进使得程序员能够以更直观的方式表达自己的意图，而不必使用更繁琐的语法结构。
>
> 通俗来说，语法糖就像是给程序员提供的一种甜蜜的“糖衣”，让他们在编写代码时感到方便，但这并不会改变程序的基本逻辑和功能。这样的设计旨在提高代码的可读性和编写效率，使得开发者更容易理解和维护代码。
>
> 我们还是以上述内容为例。如果没有`v-model`指令，我们可能需要写很多原生的JS代码来实现上述效果。但是当我们使用`v-model`命令以后，我们只需要对包含`value`属性之前写一个`v-model`指令，大大减少了代码量，并且也能实现双向绑定的效果。
