---
title: Winodws Subsystem for Linux（WSL）安装教程
tags:
  - WSL
  - Windows
category_bar: true
abbrlink: 42
description: 本文介绍了在Windows系统上安装配置WSL的详细步骤，让用户能够轻松在Windows平台上运行Linux Ubantu环境。
category: 
  - 软件安装
  - Windows
  - 服务器&虚拟机
date: 2024-02-05 10:18:53
banner_img:
index_img:
---


WSL，全称Windows Subsystem for Linux，中文翻译过来是Windows环境下的Linux子系统。可以在Windows电脑上运行Linux环境，不需要单独安装VMWare等虚拟机软件，使用WSL的目的是为同时使用Windows和Linux操作系统的开发人员提供高效体验。

你可以使用WSL安装并运行各种Linux的发行版，例如：Ubantu、Debian、Kali等，并且在提供命令行工具（Bash）运行Linux命令。

官网提供了更多关于WSL的介绍，感兴趣的小伙伴可以点击右侧链接查看：[点我查看](https://learn.microsoft.com/zh-cn/windows/wsl/about)

接下来就讲一下WSL的安装与使用：

# 一、安装前检查

1\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`并点击**确定**，进入命令行窗口。在命令行中输入`winver`查看操作系统版本，请确保操作系统是**Windows 10**和**Windows 11**，并且版本在**2004版本以后**，这里我的操作系统是22H2版本，符合安装要求：

![](https://source.icode504.com/images/image-20240202135450995.png)

2\. 电脑从来没有安装过WSL（也就是说你之前从没听说过有这个东西）

3\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`control`并回车，右上角查看类别改成**小图标**，点击**程序与功能**：

![](https://source.icode504.com/images/image-20240202142340458.png)

3\. 选择**启动或关闭Windows功能**：

![](https://source.icode504.com/images/image-20240202142540342.png)

4\. 勾选**适用于Linux的Windows子系统**，完成后点击**确定**：

![](https://source.icode504.com/images/image-20240202142612124.png)

# 二、安装WSL

1\. 打开Windows应用商店（Microsoft Store）。

![](https://source.icode504.com/images/image-20240202142905182.png)

2\. 在上方搜索框中输入你想要的Linux发行版，这里我安装的是Ubantu 长期支持版（LTS）：

![](https://source.icode504.com/images/image-20240202143659607.png)

3\. 进入详情页后，点击**安装**，请耐心等待：

![](https://source.icode504.com/images/image-20240202143750193.png)

4\. 下载完成，点击**打开**：

![](https://source.icode504.com/images/image-20240202143847804.png)

5\. Ubantu正在安装，请耐心等待（期间不要关闭这个窗口）：

![](https://source.icode504.com/images/image-20240202143923385.png)

6\. 等待了1~3分钟以后，此时Ubantu系统要我们自己输入用户名（英文名称要符合Unix的命名规则，命名规则可以自行百度）：

![](https://source.icode504.com/images/image-20240202144259062.png)

7\. 进入输入密码界面，注意密码默认是不显示在控制台的，一共需要输入两次（如果你记不住密码，建议将密码设置成123456）。输入完毕后，你就可以在Windows上正常使用Linux啦！

![](https://source.icode504.com/images/image-20240202144643586.png)

# 四、修改WSL主题风格（可选）

{% note success %}

感兴趣的小伙伴按照下面内容自己动手修改。

{% endnote %}

1\. <kbd>Ctrl</kbd>和鼠标滚轮可以调整窗口和字体大小。

2\. **鼠标右键**点击WSL上方白色部分，点击**属性**，可以修改界面风格：

![](https://source.icode504.com/images/image-20240202145311680.png)

3\. 在字体窗口自行调整字体类型和大小，这里我选择的是Consolas字体（Windows自带，挺好看的），大小20号：

![](https://source.icode504.com/images/image-20240202145530346.png)

# 五、卸载WSL（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{% endnote %}

1\. 按<kbd>Win</kbd>键，找到Ubantu，鼠标右键点击**卸载**：

![](https://source.icode504.com/images/image-20240202143332649.png)

2\. 点击**卸载**，过一会以后应用列表Ubantu的图标就会消失，卸载完成：

![](https://source.icode504.com/images/image-20240202143404859.png)

# 六、安装WSL可能会出现的问题

如果在微软商店安装Ubantu并打开的时候报错：

```
Installing, this may take a few minutes…
WslRegisterDistribution failed with error: 0x8007019e
The Windows Subsystem for Linux optional component is not enabled. Please enable it and try again.
See https://aka.ms/wslinstall for details.
Press any key to continue…
```

可以参考这篇文章，之前我也遇到过，就是按照博主的方案解决了：https://blog.csdn.net/qq_17576885/article/details/126707239
