---
title: Windows通过命令行关闭某个端口
tags:
  - Windows
  - 常用操作
category_bar: true
archive: false
abbrlink: 76
description: Windows通过命令行关闭某个端口
category:
  - 常用操作
  - Windows
date: 2024-06-29 11:31:56
banner_img:
index_img:
password:
---


按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，按回车键进入命令行界面。

![](https://source.icode504.com/images/image-20240629111918689.png)

如果你想关闭某个端口号，需要先查找这个端口号对应的PID，执行如下命令：

```powershell
netstat -ano|findstr 端口号
```

这里我要关闭的是9068号端口，执行后得到两个结果，最右侧的一列就是进程的PID，这里我需要关闭PID是17952对应的进程：

![](https://source.icode504.com/images/image-20240629112229955.png)

执行如下命令即可关闭PID对应的进程：

```powershell
taskkill /PID PID号 /F
```

执行效果如下图，此时PID为17952对应的进程就关闭了：

![](https://source.icode504.com/images/image-20240629112537455.png)
