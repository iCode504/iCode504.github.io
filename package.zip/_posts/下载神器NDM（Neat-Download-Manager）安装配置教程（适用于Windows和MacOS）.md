---
abbrlink: '24'
banner_img: https://source.icode504.com/images/下载神器NDM（Neat Download Manager）安装配置教程（适用于Windows和MacOS）-封面.png
categories:
- - 软件安装
  - Windows
  - 常用工具
- - 软件安装
  - macOS
  - 常用工具
date: '2023-12-28T15:26:50+08:00'
description: NDM（Neat Download Manger）是一款免费小巧的网络资源下载器。它支持Windows和MacOS，和浏览器相比，它的优势是下载文件速度非常快，是一款好用的下载神器。本文主要讲述了NDM的安装、配置和浏览器插件配置，并对同一个文件下载，NDM下载文件的时间和浏览器自身下载文件的时间做出对比。
index_img: https://source.icode504.com/images/下载神器NDM（Neat Download Manager）安装配置教程（适用于Windows和MacOS）-封面.png
order: ''
tags:
- Windows
- macOS
- Neat Download Manager
- NDM
title: 下载神器NDM（Neat Download Manager）安装配置教程（适用于Windows和macOS）
updated: '2024-09-28T15:43:48.684+08:00'
---
Neat Download Manager（以下简称 NDM）是一款免费小巧的网络资源下载器。说白了就是和迅雷、IDM（Internet Download Manager）类似。和 IDM 相比，NDM 占用空间非常小（安装空间就 2M 左右），并且支持 Windows 和 MacOS 操作系统。它可以对单个文件进行多线程下载（将单个文件切割成多份下载，大幅加快下载速度）。

多线程下载是 NDM 的一大优势，更多内容可以到官网页面了解：[点我进入官网](https://www.neatdownloadmanager.com/index.php/en/)

以下是 Windows 和 macOS 环境下安装 NDM 教程：

# 一、下载 NDM

1\. 打开 NDM 官网：[点我查看](https://www.neatdownloadmanager.com/index.php/en/)

2\. 根据自己的操作系统下载 NDM，这里我下载的是 Windows 版的，点击左边的下载（macOS 点击右侧链接下载）：

![](https://source.icode504.com/images/image-427df2cf376b372a09c0f19dbca05e00.png)

# 二、安装 NDM（Windows）

1\. 双击打开安装包，选择安装路径，这里我安装了 D 盘：

![](https://source.icode504.com/images/image-20231228111448526.png)

![](https://source.icode504.com/images/image-20231228111637064.png)

![](https://source.icode504.com/images/image-20231228111658143.png)

2\. 根据自身情况是否创建桌面图标，完成后点击 **Next**：

![](https://source.icode504.com/images/image-20231228111828907.png)

3\. 点击**Install**开始安装：

![](https://source.icode504.com/images/image-20231228111852068.png)

4\. 安装中，请耐心等待。

5\. 安装完成，点击**Finish**直接启动：

![](https://source.icode504.com/images/image-20231228112031479.png)

6\. NDM 界面如下图所示：

![](https://source.icode504.com/images/image-20231228112107266.png)

# 三、安装 NDM（macOS）

1\. 双击打开下载好的安装包，将 NDM 拖入到 Applications 中，完成安装：

![](https://source.icode504.com/images/image-20240417140248009.png)

2\. 在应用程序中双击打开 NDM：

![](https://source.icode504.com/images/image-20240417140743668.png)

3\. 此时会弹出一个提示，点击**打开**：

![](https://source.icode504.com/images/image-20240417140835641.png)

4\. NDM 界面如下图所示：

![](https://source.icode504.com/images/image-20240417140941812.png)

# 四、配置 NDM

接下来，我们对 NDM 做一些简单配置，点击右上角的小齿轮（Settings），打开 NDM 设置：

![](https://source.icode504.com/images/image-20231228112157668.png)

1\. 最大连接数推荐设置为 32，让 NDM 在下载文件时拉满带宽，加快下载速度：

![](https://source.icode504.com/images/image-20231228112309663.png)

2\. 按照下图所示选择文件下载位置和临时文件下载位置：

> Windows 用户推荐将下载位置选择在除C盘以外的其他位置，例如：D盘。
>
> macOS 用户推荐将下载位置选择在你熟悉的位置。

![](https://source.icode504.com/images/image-20231228112529398.png)

3\. 完成后点击 OK 即可，对 NDM 的配置就完成了。

# 五、给浏览器安装 NDM 插件

接下来，我们给浏览器安装 NDM 插件，方便后续我们在浏览器下载内容是让 NDM 能嗅探到，直接调用 NDM 代替浏览器下载文件。

以下提供了三个浏览器安装插件的方式：Chrome 浏览器、火狐浏览器、Edge 浏览器。大家根据实际情况任选其一即可。

## 5.1 Chorme 浏览器

1\. 由于国内无法访问谷歌应用商店，因此正常方式无法获得 NDM 插件。这里我为大家分享了 NDM 插件，点击右侧链接下载插件：[点我下载](https://icode504.lanzouw.com/ikPCA1j6omkd)

2\. 按照下图所示操作，打开扩展程序管理页面：

![](https://source.icode504.com/images/image-20231228113739950.png)

3\. 打开右上角的**开发者模式**：

![](https://source.icode504.com/images/image-20231228113846887.png)

4\. 将刚才下载好的插件直接拖入到界面中，上方会有一个弹窗，点击**添加扩展程序**即可：

![](https://source.icode504.com/images/231228001.gif)

5\. 至此，NDM 插件就已经安装完成了。

![](https://source.icode504.com/images/image-20231228114300605.png)

## 5.2 火狐浏览器

1\. 点击右上角，选择扩展与主题（或者直接按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>A</kbd>），搜索**NeatDownloadManger**并按回车键搜索：

![](https://source.icode504.com/images/image-20231228115328017.png)

2\. 搜索结果中，找到**NeatDownloadManger Extension**，点击进入：

![](https://source.icode504.com/images/image-20231228115418650.png)

3\. 添加到 FireFox：

![](https://source.icode504.com/images/image-20231228115540347.png)

4\. 右上角会有一个小弹窗，点击**添加**：

![](https://source.icode504.com/images/image-20231228115610110.png)

5\. 添加成功，点击**好的**：

![](https://source.icode504.com/images/image-20231228115653250.png)

## 5.3 Edge 浏览器

1\. 打开 Edge 浏览器，点击右上角的三个小点，点击扩展：

![](https://source.icode504.com/images/image-20231228150457486.png)

2\. 选择倒数第二个，**管理扩展**：

![](https://source.icode504.com/images/image-20231228150538422.png)

3\. 在扩展页面左侧选择**获取 Microsoft Edge 扩展**：

![](https://source.icode504.com/images/image-20231228150628199.png)

4\. 在扩展商店搜索 **NeatDownloadManager**，完成后按回车就能看到搜索结果，点击**获取**即可：

![](https://source.icode504.com/images/image-20231228150918779.png)

5\. 选择**添加扩展**：

![](https://source.icode504.com/images/image-20231228151039221.png)

6\. 右上角出现如下弹窗信息就说明 NDM 插件添加成功：

![](https://source.icode504.com/images/image-20231228151125225.png)

# 六、试一下 NDM 有多快

以下是演示内容。这里我找了一个大一点 MySQL 的安装包（约 1.3G）下载来演示：

![](https://source.icode504.com/images/image-20231228134507751.png)

使用 NDM 下载：速度直接拉满，我这台电脑使用 NDM 下载上述文件用时 2 分 39 秒，感兴趣的小伙伴可以观看：[NDM 下载文件视频（未剪辑版）](https://pan.baidu.com/s/1yRZk0dI6i6AqQXiuvrpoeQ?pwd=w4jk)。

如果使用浏览器本身下载：速度就差了一大截，下载速度维持在 500KB\~1.3M 左右，下载用时 19 分 22 秒，感兴趣的小伙伴可以观看：[浏览器下载文件视频（未剪辑版）](https://pan.baidu.com/s/1tSky3oSyQ4Pq2nYJrctvJg?pwd=nxwn)。
