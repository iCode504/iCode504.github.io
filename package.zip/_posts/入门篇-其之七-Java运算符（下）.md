---
title: 入门篇-其之七-Java运算符（下）
date: 2023-12-08 17:33:33
tags: Java
abbrlink: 9
category: iCode504的Java学习空间
description: 本文主要讲述了Java三元运算符的使用、三元运算符和if语句的区别、运算符的优先级展示和括号运算符如何提升运算符的级别。
index_img: https://source.icode504.com/images/3183310-20231024090839060-2083851096.png
---

# 一、三元运算符的使用

三元运算符（也称作三目运算符），使用`:`和`?`表示，其格式为：**布尔表达式 ? 表达式1 : 表达式2**

- 如果布尔表达式的计算结果是`true`，那么执行表达式1；否则，如果布尔表达式的计算结果是`false`，则执行表达式2。
- **表达式1和表达式2计算结果的数据类型必须要和左侧变量定义的数据类型保持一致**。例如：表达式1和表达式2的计算结果都是`double`类型，那么左侧定义的变量类型也是`double`。

以下是三元运算符作用原理图：

![未标题-1](https://source.icode504.com/images/%E6%9C%AA%E6%A0%87%E9%A2%98-1.jpg)

以下是三元运算符在代码中的使用：

```java
/**
 * 三元运算符的使用
 *
 * @author ZhaoCong
 * @date 2023-10-25 11:57:21
 */
public class Ternary {
    public static void main(String[] args) {
        byte byteValue1 = 20;
        byte byteValue2 = 30;

        byte result1 = byteValue1 > byteValue2 ? byteValue1 : byteValue2;
        System.out.println("result1 = " + result1);

        double doubleValue1 = 40.13;
        double doubleValue2 = 30.28;

        double result2 = doubleValue1 == doubleValue2 ? doubleValue1 : doubleValue2;
        System.out.println("result2 = " + result2);

        String strValue1 = "";
        String result3 = strValue1.length() == 0 ? "strValue1的长度是0" : "strValue1的长度不是0";
        System.out.println("result3 = " + result3);
    }
}
```

运行结果：

![](https://source.icode504.com/images/image-20231027105629436.png)

三元运算符可以嵌套使用，但不推荐，原因是可读性变差。

```java
String strValue = "iCode504";
int length = strValue.length();
// 不推荐嵌套的写法
String result = length > 0 ? length < 10 ? "strValue的长度在0~10之间" : "strValue的长度超过10" : "strValue的长度为0";
System.out.println("result = " + result);
```

嵌套式写法做进一步简化处理：

```java
String strValue = "iCode504";
int length = strValue.length();
String result = length > 0 && length < 10 ? "strValue的长度在0~10之间" : "strValue的长度不在0~10之间";
System.out.println(result);
```

# 二、三元运算符和if语句的区别

共同点：三元运算符和`if`语句的作用都是用作条件判断。但二者也存在一些差别：

1\. 语法层面：在大多数情况下，三元运算符语法是一行语句，`if`语句可能是多行。例如：判断一个字符串的长度是否为0，以下分别是三元运算符和`if`语句的写法：

```java
// 三元运算符写法
String strValue = "iCode504";
String result = strValue.length() == 0 ? "strValue的长度为0" : "strValue的长度不为0";
```

```java
// if写法
String strValue = "iCode504";
String result;
if (strValue.length() == 0) {
    result = "strValue的长度为0";
} else {
    result = "strValue的长度不为0";
}
```

2\. 代码可读性：对于简单的条件判断，使用三元运算符确实可以简化代码，但是如果是复杂条件或者嵌套，那么三元运算符会让代码变得更加复杂难以理解。

3\. 灵活性：`if`语句中可以在代码块中放入更多的表达式，但是三目运算符的表达式只能存在一个。

总体来说，三目运算符和`if`语句都有各自的优点和使用场景。在简单的情况下，使用三目运算符比较方便；在复杂情况下，使用`if`语句更合适。

# 三、运算符的优先级

前面学过很多的运算符：例如算术运算符、比较运算符、逻辑运算符等等，如果这些运算符进行混合运算时，存在着一个优先级，即谁先计算，谁后计算的问题。数学中存在这样一条规定：先乘除，后加减。也就是说，乘和除是同一级别，二者的计算级别要比加和减的级别高。这条规定在Java中也完全适用。

以下是运算符的优先级顺序表（由高到低，这张表了解即可，不需要额外记忆）：

| 运算符                                                       | 关联性   |
| ------------------------------------------------------------ | -------- |
| ()   []                                                      | 从左向右 |
| !   ~   ++   --   正负号                                     | 从右向左 |
| *   /   %                                                    | 从左向右 |
| +   -                                                        | 从左向右 |
| <<   >>   >>>                                                | 从左向右 |
| <   <=   >   >=   instanceof                                 | 从左向右 |
| ==   !=                                                      | 从左向右 |
| &                                                            | 从左向右 |
| ^                                                            | 从左向右 |
| \|                                                           | 从左向右 |
| &&                                                           | 从左向右 |
| \|\|                                                         | 从左向右 |
| ?:                                                           | 从右向左 |
| =   +=   -=   *=   /=   %=   &=   \|=   ^=   <<=   >>=   >>>= | 从右向左 |

**使用括号()可以提升运算符的优先级**。例如：

```java
int value1 = 30;
int value2 = 28;
int value3 = 17;
int result1 = value1 * value2 + value3;		// 先乘除，后加减
int result2 = value1 * (value2 + value3);	// 有括号的优先计算
```

原本加号的运算等级要比乘号的等级要低，但是给加法表达式加上括号以后，加法表达式优先计算，然后再计算乘除法。

