---
title: 第一个Vue程序
tags:
  - Vue
category_bar: true
archive: true
category:
  - Vue
  - Vue基础知识
password: 123456
abbrlink: 2391573034
date: 2024-02-06 14:35:45
description:
banner_img:
index_img:
---

# 一、准备阶段

| 准备内容            | 操作                                                         |
| ------------------- | ------------------------------------------------------------ |
| vue.js文件          | [点击下载vue.js源代码](https://v2.cn.vuejs.org/js/vue.js)    |
| 安装VS Code         | [Visual Studio Code安装配置教程（Windows版）](https://www.icode504.com/posts/38.html) |
| 安装Vue 开发者工具  | [浏览器下载安装Vue开发者工具插件](https://www.icode504.com/posts/925751481.html) |
| Live Server插件安装 | [Live Server插件安装教程](https://www.icode504.com/posts/44.html) |

1\. 创建一个专门写Vue代码的文件夹，这里我创建文件夹名称是vue-study。

![](https://source.icode504.com/images/image-20240206110536378.png)

2\. 为了以后更方便使用vue文件，将刚才下载后的`vue.js`单独放到一个文件夹，这里我单独创建`js`文件夹用于存放`vue.js`。

![](https://source.icode504.com/images/image-20240206110727602.png)

![](https://source.icode504.com/images/image-20240206110857991.png)

4\. 返回上一级目录并复制此路径：

![](https://source.icode504.com/images/image-20240206111245720.png)

5\. 打开VS Code，点击左上角**文件** --> **打开文件夹**：

![](https://source.icode504.com/images/image-20240206111433205.png)

6\. 将前面复制路径在上方路径栏中粘贴并回车，点击**选择文件夹**：

![](https://source.icode504.com/images/image-20240206111830010.png)

# 二、第一个Vue程序

1\. 创建一个HTML文件，这里我命名为`page01.html`。

2\. 在`head`标签中创建`script`标签，引入`vue.js`：

```html
<script src="../js/vue.js"></script>
```

3\. 在`body`中写一个带有选择器的`div`容器。选择器使用id选择器、类选择器都可，选择器名称可以自定义。这里我是用的是id选择器，名称为`app`。`div`里面的内容如下，其中`{{name}}`是插值表达式（后续会讲到）

```html
<div id="app">
  {{name}}的第一个程序
</div>
```

4\. 在`div`下方创建`script`标签，创建Vue实例

```html
<script>
  new Vue()
</script>
```

此时我们就创建了一个Vue对象，但是它貌似并没有和上面我们创建的`div`容器进行绑定。因为使用Live Server进行预览时，只是得到了我们在`div`标签里面的内容：

![](https://source.icode504.com/images/image-20231127144549223.png)

此时我们需要想办法让二者进行绑定。

5\. 此时我们需要在Vue对象中使用到两个属性：`el`和`data`

- `el`全称`element`，用于指定当前Vue实例为哪个容器服务，值通常为CSS选择器字符串（`document.getElementById(xxx)`）。
- `data`用于存储数据，数据类型是JS的对象，数据供`el`指定的容器去使用。

如果我们想把`div`标签中的`{{name}}`替换成我们想要的内容，需要在`data`中创建一个属性`name`，此时它对应的值可自定义，这里我就使用`iCode504`对原有的`{{name}}`进行替换。

```html
<script>
  new Vue({
    el: "#app",
    data: {
      name: "iCode504"
    }
  });
</script>
```

此时我们再运行代码，发现`div`中的`{{name}}`替换成了我在Vue中`data`对象`name`属性对应的值了。

![](https://source.icode504.com/images/image-20231127145415137.png)

# 三、第一个Vue程序的说明

## 3.1 关闭Vue开发模式提醒

在运行Vue实例时，我们会在浏览器控制台默认会看到如下内容：

![](https://source.icode504.com/images/image-20231127160356752.png)

这段内容提醒我们我们运行的Vue程序正处于开发模式，如果不想让这段内容出现在控制台，可以在创建Vue实例之前添加如下内容即可：

```js
Vue.config.productionTip = false
```

如果上述操作仍然无效，直接打开源代码，<kbd>Ctrl</kbd><kbd>F</kbd>搜索`productionTip`，默认值是`true`。我们只需要将其改为`false`即可：

![](https://source.icode504.com/images/image-20240206134158736.png)

## 3.2 Vue实例和容器一一对应

一个Vue实例对应一个容器，不存在一对多，多对一的情况。

> 假设一个Vue容器对应两个容器，它只渲染第一个容器，其他容器里面的内容不渲染。

```html
<div class="app">
  {{name}}的第一个程序
</div>

<div class="app">
  {{name}}的第一个程序
</div>
<script>
  new Vue({
    el: '.app',
    data: {
      name: 'iCode504'
    }
  })
</script>
```

运行结果：

![](https://source.icode504.com/images/image-20231127162417615.png)

> 假设一个容器对应两个Vue，默认会使用第一个Vue实例对页面内容进行渲染。

```html
<div class="app">
  {{name}}的第一个程序    <br>
  {{cat}}
</div>

<script>
  // 两个Vue实例绑定一个容器
  new Vue({
    el: '.app',
    data: {
      name: 'iCode504'
    }
  })

  new Vue({
    el: '.app',
    data: {
      cat: '这里有一只小猫咪'
    }
  })
</script>
```

![](https://source.icode504.com/images/image-20231127162912738.png)

控制台出现了Vue的警告信息，它提示我们`{{cat}}`并没有在Vue实例中定义，但是在渲染过程中出现了。这是因为容器默认使用的是第一个Vue实例进行渲染，而第一个Vue实例并没有在`data`中定义`cat`属性和对应的值，此时出现这个Vue警告就显得比较合理了。

**真实开发中只有一个Vue实例**。

