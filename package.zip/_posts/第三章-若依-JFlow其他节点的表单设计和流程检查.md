---
title: 第三章 若依-JFlow其他节点的表单设计和流程检查
date: 2023-12-11 10:35:35
tags: [若依, JFlow]
description: 本文主要讲述了其他节点导入之前节点的表单，并在表单的基础上进一步设计。设计完成后，对流程进行检查并查看检查信息。
category: [工作流框架, JFlow]
abbrlink: 17
---

> 若依-JFlow框架如何拉取、配置并运行请查看这篇文章：[《第一章 若依-JFlow的配置与启动》](http://www.icode504.com/posts/15.html)
>
> 如何创建业务场景、流程图和单节点表单设计请查看这篇文章：[《第二章 若依-JFlow流程模型设计》](http://www.icode504.com/posts/16.html)

上一节我们讲述了如何创建一个业务场景和流程模型，如何创建一个流程，如何设置单个节点的表单。

![](https://source.icode504.com/images/image-20231208103559698.png)

这一节我们就设置所有节点人员的表单。并检查相关的流程。

# 一、设置各节点人员审批表单

## 1.1 部门领导审批节点表单设计

部门领导审批当前员工的请假申请单时，没有修改员工填写的申请信息权限，因此在审批时，部门领导看到的员工信息表单是只读状态，他只有审批通过/驳回的权限。

驳回需要填写驳回理由，也就是说当点击驳回时，触发填写驳回原因事件，这些在JFlow框架中全部都能实现。

鼠标右键点击部门领导节点，点击**设计表单**，出现如下页面：

![](https://source.icode504.com/images/image-20231208104024130.png)

我们需要再重新绘制一遍员工请假申请单的内容吗？并不是，JFlow为我们提供了节点内容的选项。

1\. 点击右上角的**导入导出**

![](https://source.icode504.com/images/image-20231208104153563.png)

2\. 进入导入导出页面以后，选择导入方式为**从流程节点表单导入**：

![](https://source.icode504.com/images/image-20231208104255122.png)

3\. 选择第一个节点，我们之前设计的表单；开启**是否只读**，导入后的表单内容全部设置为只读状态，然后点击**执行从节点表单导入**即可。

![](https://source.icode504.com/images/image-20231208104433275.png)

4\. 此时弹出框会弹出一个提示，点击确定，覆盖原有节点内容即可：

![](https://source.icode504.com/images/image-20231208104552660.png)

5\. 出现如下内容就说明上一个节点的内容导入成功，点击确定，关闭导入窗口。

![](https://source.icode504.com/images/image-20231208104631504.png)

6\. 此时就出现了上一个节点（员工填写请假单）设计的表单内容，并且全部设置只读：

![](https://source.icode504.com/images/image-20231208104815228.png)

7\. 此时我们在左侧组件最下方，找打审核分组，拖到请假单的下方：

![231208001](https://source.icode504.com/images/231208001.gif)

8\. 此时表单下方的审核分组中就会出现审核意见、审核人、审核日期。但是我们需要对表单内容进行修改：

![](https://source.icode504.com/images/image-20231208105403289.png)

- 首先我们先将审核日期设置为只读：

![](https://source.icode504.com/images/image-20231208105544768.png)

- 审核人默认显示方式改成登陆人员姓名，即`@WebUser.Name`

![](https://source.icode504.com/images/image-20231208143308747.png)

- 审核意见也不符合前面我们预期的要求，选中审核意见组件，点击右侧图标删除组件。
- 在左侧组件库中拉入一个枚举单选到部门经理审核组件框中，此时弹出一个添加枚举类型字段的窗口，在右上角点击新建：

![](https://source.icode504.com/images/image-20231208110047034.png)

- 枚举内容按照下图填写即可，然后点击右上角保存，关闭此窗口：

![](https://source.icode504.com/images/image-20231208110154390.png)

- 枚举值选择第一个：

![](https://source.icode504.com/images/image-20231208110409316.png)

- 弹出框内容点击确定即可：

![](https://source.icode504.com/images/image-20231208110449181.png)

- 点击保存，然后再点击关闭即可：

![](https://source.icode504.com/images/image-20231208110543956.png)

- 再选中部门经理审核意见组件，将内容设置为必填：

![](https://source.icode504.com/images/image-20231208110733501.png)

9\. 此时我们再对部门经理审核意见组件绑定驳回填写驳回原因事件。

- 向审批框中再拖入一个文本框，命名为驳回理由。

![231208002](https://source.icode504.com/images/231208002.gif)

- 选中部门经理审核意见组件，点击蓝色齿轮进入设置，设置联动如下图所示：

> 说明：设置一次列表值以后，一定要在在右上角点击一次保存。如果你设置了三次以后，再点击保存，此时只对最后一次修改生效。

![](https://source.icode504.com/images/image-20231208143815630.png)

![](https://source.icode504.com/images/image-20231208143848071.png)

![](https://source.icode504.com/images/image-20231208143736417.png)

- 驳回理由按照下图所示设置：

![](https://source.icode504.com/images/image-20231208144458457.png)

10\. 至此，部门经理审核组件框内的所有组件全部设计完成。

![](https://source.icode504.com/images/image-20231208144635810.png)

## 1.2 人事签字备案节点、总经理审批节点表单设计

这三个节点的表单设计和部门领导审批节点的表单设计步骤基本相同。

1\. 导入节点的内容选择上一个节点内容即可：

2\. 拖入审批组件，设计表单。

3\. 添加人事经理审批意见组件（组件是枚举单选），内容设置如下：

![](https://source.icode504.com/images/image-20231208112907328.png)

4\. 添加一个文本框，文本框名称填写格式：职位名称+驳回理由，以人事经理审批为例，这个文本框的名称是人事经理驳回理由，其他角色亦同理。

![](https://source.icode504.com/images/image-20231208145630246.png)

![](https://source.icode504.com/images/image-20231208145656696.png)

![](https://source.icode504.com/images/image-20231208145719723.png)

5\. 设计完成后的请假单如下图所示：

- 人事签字备案节点表单：

![](https://source.icode504.com/images/image-20231208145122221.png)

- 总经理审批节点界面：

![](https://source.icode504.com/images/image-20231208153534633.png)

## 1.3 查看请假单节点表单设计

查看请假单节点对应的表单就比较简单了，设计时只需要导入总经理审批节点的内容即可，不需要做任何修改：

![](https://source.icode504.com/images/image-20231208114525358.png)

查看请假单节点的表单内容如下，内容全部是只读状态：

![](https://source.icode504.com/images/image-20231208154932112.png)

# 二、检查流程

点击流程上方的检查按钮，系统会对流程和表单内容进行检查：

![](https://source.icode504.com/images/image-20231208114932402.png)

检查完成后，会出现如下的检查结果，如果没有红色的错误信息，就说明我们的流程和表单设计没有问题：

![](https://source.icode504.com/images/image-20231208115111283.png)

至此，我们已经完成了所有节点的表单设计与检查，下一部分我们来测试执行整个请假流程。

![](https://source.icode504.com/images/image-20231205174128064.png)

