---
abbrlink: '113'
banner_img: https://source.icode504.com/images/296081f3bec4c0188ea1ae44fc8ac842.png
categories:
- Docker
- 镜像拉取
date: '2024-10-30T08:38:18.936970+08:00'
description: 本文通过Github拉取Dockerhub中的镜像，然后再推送到阿里云镜像仓库，从而解决无法拉取镜像的问题
index_img: https://source.icode504.com/images/296081f3bec4c0188ea1ae44fc8ac842.png
order: ''
tags:
- Docker
- Docker hub
- Github
title: 通过Github拉取Docker hub中的镜像
updated: '2024-10-30T11:48:01.447+08:00'
---
本文参考自技术爬爬虾关于Dockerhub镜像拉取的解决方案，以下是原作者的B站视频页和Github仓库，喜欢的话请支持一下原作者！


|                     Bilibili原视频                     | Bilibili账号                                     |                              Github                              |
| :-----------------------------------------------------: | ------------------------------------------------ | :--------------------------------------------------------------: |
| [点我查看](https://www.bilibili.com/video/BV1Zn4y19743) | [点我查看](https://space.bilibili.com/316183842) | [点我查看](https://github.com/tech-shrimp/docker\_image\_pusher) |

我们在使用`docker pull`命令时，即使配置了registry-mirrors，也经常出现无法连接或者链接超时的问题：

![](https://source.icode504.com/images/f7b30615d6fce620f3aba7a04b004bce.png)

要想解决这一问题，我们需要通过Github从Dockerhub拉取镜像，然后再将镜像数据推送到阿里云镜像仓库，由于阿里云镜像仓库位于国内，从阿里云镜像仓库拉取个人镜像速度非常快，以下是相关教程：

# 一、准备操作

在正式开始之前，我们需要执行如下操作：

1\. 开启对Github和Dockerhub的访问。请根据自己电脑操作系统查看对应教程：


|        Windows        |         macOS         |
| :-------------------: | :-------------------: |
| [点我查看](./25.html) | [点我查看](./80.html) |

开启加速后，可以点击下面两个网站：


|             Github             |              Dockerhub              |
| :----------------------------: | :---------------------------------: |
| [点我查看](https://github.com) | [点我查看](https://hub.docker.com/) |

2\. 登录并注册阿里云、Github，以下是这两个网站的入口和相关说明：


|        |                        网站入口                        | 说明                                                                                        |                                   参考图片                                   |
| :----: | :----------------------------------------------------: | :------------------------------------------------------------------------------------------ | :--------------------------------------------------------------------------: |
| 阿里云 | [点我查看](https://account.aliyun.com/login/login.htm) | 可以使用支付宝、淘宝等阿里系软件注册/扫码登录。为了更好使用阿里云，推荐小伙伴进行实名认证。 | ![](https://source.icode504.com/images/6ce5025fbd4650632288964f36b12b73.png) |
| Github |          [点我查看](https://github.com/login)          | 可以使用QQ邮箱、网易邮箱、谷歌邮箱等注册                                                    | ![](https://source.icode504.com/images/82227d6e957764e2348dd302aa1e26ce.png) |

3\. 这里我使用Electerm连接到服务器，需要安装的小伙伴，请根据自己电脑操作系统查看对应教程：


|        Windows        |         macOS         |
| :-------------------: | :-------------------: |
| [点我查看](./47.html) | [点我查看](./99.html) |

# 二、阿里云相关操作

1\. 点击右侧链接进入容器镜像服务（个人版）控制台界面：[点我查看](https://cr.console.aliyun.com/cn-hangzhou/instance/dashboard)

2\. 按照下面的步骤创建命名空间：

![](https://source.icode504.com/images/d7ac782770a2ce84ee920bcdafcb6965.png)

![](https://source.icode504.com/images/3c7b51dbf6ce0bf9ceef4a35c7d2e930.png)

3\. 按照下图所示操作，绑定Github账号：

![](https://source.icode504.com/images/d35c5341ed2de9ca8f88161c6b785202.png)

![](https://source.icode504.com/images/add540bd6debced1033fd773fc9c33b6.png)

![](https://source.icode504.com/images/a1484225053e42bfa518416b0b1f04b4.png)

4\. 设置访问阿里云镜像仓库密码，请按照下图所示操作：

![](https://source.icode504.com/images/399182feeb418a2e3a938b7a8fd2990d.png)

![](https://source.icode504.com/images/993166426d5e117ae7e33338b3f56700.png)

# 三、Github相关操作

1\. 点击进入Docker镜像推送仓库：[点我查看](https://github.com/tech-shrimp/docker_image_pusher)

2\. 按照下图所示操作将项目Fork到自己的仓库：

![](https://source.icode504.com/images/9450729456cb2bfbe1a0112953fc132f.png)

![](https://source.icode504.com/images/10df083aad94b630d2673a9bbce8b3c7.png)

3\. 此时项目成功Fork到我们自己的仓库中，点击**Settings**：

![](https://source.icode504.com/images/6d8847e3586ed13c0c62248995f62a75.png)

4\. 配置环境变量。按照下图所示操作，进入配置环境变量界面：

![](https://source.icode504.com/images/be83a9ba3bea2ce3ba505c01bcac4fdc.png)

5\. 请按照下图所示操作将4个Name-Secret对存储到Github：


|            Name            |                            在阿里云如何找到Secret                            |                                 Github效果图                                 |
| :------------------------: | :--------------------------------------------------------------------------: | :--------------------------------------------------------------------------: |
|    ALIYUN\_NAME\_SPACE    | ![](https://source.icode504.com/images/ec23060555f9d896f0dc2a6e90964d5f.png) | ![](https://source.icode504.com/images/2c20eb57f3c8ebd22526367885caa542.png) |
|   ALIYUN\_REGISTRY\_USER   | ![](https://source.icode504.com/images/7cb2cdd2ce10b886926793ccfe81ea51.png) | ![](https://source.icode504.com/images/9a3d44fcf971ff6740535ac2cc0b074e.png) |
| ALIYUN\_REGISTRY\_PASSWORD | ![](https://source.icode504.com/images/e2b9a94dbf8270aae261e12d34458a5f.png) | ![](https://source.icode504.com/images/9fdc34a284da1f14814b922e8262eb8f.png) |
|      ALIYUN\_REGISTRY      |                      registry.cn-hangzhou.aliyuncs.com                      | ![](https://source.icode504.com/images/6b5dae7b2f12bad1eb9767952a1b7871.png) |

至此，阿里云和Github的配置完成！接下来，我们就试着拉取一个镜像。

# 四、将Dockerhub中的镜像通过Github推送到阿里云镜像仓库

> 说明：这里我拉取的是Redis相关镜像，其他镜像也可以参考下面的步骤：

1\. 进入前面我们Fork的项目，点击上方的**Actions**，然后点击I understand my workflows, go ahead and enable them.同意协议：

![](https://source.icode504.com/images/b1a21df53443800df3fdddf7e5929906.png)

2\. 按照下图所示操作，进入到image.txt文件中：

![](https://source.icode504.com/images/b8c99bda80915730630bbac3db55b76c.png)

![](https://source.icode504.com/images/603aa5dc43800cceab7c564e4d652b24.png)

3\. 点击右上角的小铅笔，进入编辑模式：

![](https://source.icode504.com/images/c8528fa76bb0b5002bd8d897bbc44fed.png)

4\. 将文件中的内容全部清空，后续替换为我们自己的镜像名和版本：

![](https://source.icode504.com/images/42e5c52016915c983ed960e3f3e74aba.png)

5\. 打开Dockerhub官网：[点我查看](https://hub.docker.com/)

> 说明：由于国内网络原因，Dockerhub加载较慢，请耐心等待！

6\. 在上方搜索框中搜索Redis，按一下回车，第一个就是Redis官方镜像：

![](https://source.icode504.com/images/a4aa22cf2e0ffc94ba61a13fb940a619.png)

7\. 点击Tags即可查看所有镜像：

![](https://source.icode504.com/images/5a60858df4b1d017c87862a2845387a7.png)

8\. 这里我想拉取7.4.1、7.4、7.2.6三个版本的镜像：直接复制镜像名和版本号即可（前面的`docker pull`不要复制）：

![](https://source.icode504.com/images/ac71b13a8da1878b5758a5a9c63665a3.png)

![](https://source.icode504.com/images/a74db4aea877bf3ba178651ab8d910aa.png)

![](https://source.icode504.com/images/88856df36515399b0d631081d33c6cbc.png)

9\. 将前面复制的镜像名和版本号依次粘贴到images.txt中，效果图如下：

![](https://source.icode504.com/images/9da31bc037cca6a6fb27922b586cb5cf.png)

10\. 如果没有什么问题，点击右上角的**Commit changes**提交代码：

![](https://source.icode504.com/images/8d25655bd9601a3f9861536282d2aaa4.png)

11\. 此时会弹出一个窗口，点击**Commit changes**：

![](https://source.icode504.com/images/bfc634e07bec4ad1fee067bce0229c1f.png)

12\. 点击上方的Actions，即可查看镜像拉取和推送到阿里云的过程，如果出现绿色的对号，就说明镜像已经成功推送到阿里云镜像仓库：

> 如果项目构建失败，可能是如下原因：
>
> - 镜像或者版本号错误
> - 前面配置的Name-Secret配置不正确

![](https://source.icode504.com/images/e66242153624c7e3127bcd20955cbcf1.png)

13\. 点击进入阿里云容器镜像服务控制台：[点我查看](https://cr.console.aliyun.com/cn-hangzhou/instance/repositories)。此时我们可以看到Dockerhub镜像通过Github成功推送到了阿里云镜像仓库，点击进入：

![](https://source.icode504.com/images/d2f283e0fac7ed0b9e82071e4b3257f3.png)

14\. 接下来我们就可以按照阿里云给出的步骤一步一步拉取镜像了：

![](https://source.icode504.com/images/76aab6b2fc030dfbabf1af6b7708e70a.png)

15\. 使用Electerm连接到Linux服务器，登录到阿里云镜像仓库：

```bash
docker login --username=阿里云用户名 registry.cn-hangzhou.aliyuncs.com
```

效果图如下，需要输入密码（不在控制台显示），登录成功如下图所示：

![](https://source.icode504.com/images/e0a9df9c76ae5a3bb237997727a8876c.png)

16\. 从镜像仓库中拉取镜像：

```bash
docker pull registry.cn-hangzhou.aliyuncs.com/icode504-docker-repo/redis:[镜像版本号]
```

其中镜像版本号获取方式如下图：

![](https://source.icode504.com/images/b20498cf87bbec016cb6a4738b9ef87c.png)

效果图如下，拉取镜像走的是国内的网络，速度非常快且可靠！

![](https://source.icode504.com/images/82567e834c3c2b0044c3fbd0ac07905e.gif)
