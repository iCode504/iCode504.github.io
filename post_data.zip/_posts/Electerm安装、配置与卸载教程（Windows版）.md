---
title: Electerm安装、配置与卸载教程（Windows版）
tags:
  - Electerm
  - Windows
category_bar: true
archive: false
abbrlink: 47
description: >-
  本文简要介绍了在Windows操作系统上安装Electerm的步骤。通过该教程，用户可以轻松下载、安装并配置Electerm，确保后续在Windows平台上享受强大的终端功能和文件管理能力。
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Electerm安装、配置与卸载教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Electerm安装、配置与卸载教程（Windows版）.png
category:
  - 软件安装
  - Windows
  - 服务器&虚拟机
date: 2024-02-21 11:32:19
password:
---

Electerm 是一款开源免费的终端模拟器，集终端模拟器、文件管理器、SSH 远程连接、SFTP 客户端等功能于一体。它可以在 Windows、macOS 和 Linux 操作系统上运行，为用户提供一个功能丰富、易于使用的终端环境。

通过 Electerm，用户可以在同一窗口中运行多个 SSH 会话，轻松管理远程服务器，并使用各种 Shell 命令。它还支持多种认证方式，包括密码、密钥、双因素认证等，以满足不同用户的需求，使得使用 SSH 会话更加高效方便。

在文件传输方面，Electerm 支持 SFTP 功能，可以方便地传输文件和管理网络连接。它还支持多语言，包括英语、中文等。

接下来介绍一下 Windows 环境下的 Electerm 的安装和简单配置。

# 一、下载 Electerm

> 本文后续内容使用 NDM（Neat Download Manager）下载文件，可以加快下载速度（推荐）。如需使用此款软件的小伙伴，可以查看这篇教程：[下载神器 NDM（Neat Download Manager）安装配置教程（适用于 Windows 和 MacOS）](https://www.icode504.com/posts/24.html)
>
> 已经安装的小伙伴请直接往下看。

1\. 打开 Electerm 官网：[点我查看](https://electerm.html5beta.com/index-zh_cn.html)

2\. 在下方页面，找到 Windows 相关的安装包，我们选择第一个：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240617000159595.png)

# 二、安装 Electerm

1\. 双击打开安装包，进入欢迎界面，选择**为使用这台电脑的任何人安装（所有用户）**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213104457865.png)

2\. 点击**浏览**选择安装位置，这里我安装在了 D 盘。完成后点击安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213104628885.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213104832549.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213104912247.png)

3\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213105024765.png)

4\. 安装完成，点击**完成**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213105113276.png)

# 三、Electerm 的简单配置

> 说明：以下包含“可选”的标题中可以自行修改，并不影响实际使用。

## 3.1 更换主题风格（可选）

在桌面打开 Electerm，默认是黑色界面：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213105358335.png)

如果你不喜欢这个纯黑界面，可以在左侧找到**设置**（小齿轮）对主题进行更改：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213105514644.png)

在设置中，找到 UI 主题（内置了多个主题，也可以自定义主题，这里我选用的是 Github 主题），在下方搜索框中输入 Github，其中第二个搜索结果就是我们想要的：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213110343282.png)

选择 Github 主题，此时最右侧会出现一个对号图标，点击这个图标就是应用这个主题：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213110645152.png)

点击左上角的关闭图标，此时我们发现界面变成了白色风格：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213110745168.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213111646109.png)

## 3.2 设置背景图片（可选）

界面上有一个 Electerm 的大 logo，其实这是一张背景图片。软件本身支持修改背景图片。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213111722825.png)

点击左侧菜单，打开**设置**（小齿轮）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213111908999.png)

在设置下方，找到**终端**，右侧有**终端背景图片**设置：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213112130980.png)

如果你不需要背景图片，就点击以下输入框，此时会弹出一个列表框，选择无背景图片即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213112256558.png)

需要更换背景图片的小伙伴，建议是保存在本地的电脑壁纸（虽然 Electerm 支持在线图片链接，但是没有网了以后图片也不会显示）。点击右侧**选择文件**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213114042874.png)

在本地选择一张壁纸（壁纸建议是简约风，否则花里胡哨可能会影响使用体验）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213114529925.png)

图片设置好以后，我们可以在下方设置图片的透明度和模糊度：

- 透明度（Opacity），值在 0~1 之间，数值越小，图片的透明度越低。
- 模糊度（Blur），数值越大，图片越模糊。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213115310321.png)

修改后界面效果如下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213115750587.png)

## 3.3 关闭检查更新

Electerm 更新软件默认会从 Github 下载，但是 Github 对国内用户并不友好（因为网络原因经常访问失败）。如果你不想使用新版本的 Electerm，建议关闭检查更新这一项。

点击右侧的**设置**（小齿轮）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213111908999.png)

在设置中的 Common，在下方设置中关闭**检查应用程序启动时的更新**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213120341726.png)

## 3.4 将 PowerShell 换成命令提示符 cmd（可选）

Electerm 在 Windows 环境下默认使用的是 PowerShell，如果你经常使用的是普通的命令提示行（cmd），也可以在 Electerm 中设置。

点击右侧的**设置**（小齿轮）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213111908999.png)

在设置下方，找到 Common，右侧设置中找到默认 ExecWindows，将里面的内容替换成`System32/cmd.exe`：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213121100847.png)

重启 Electerm，此时成功切换成命令提示行（cmd）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213121325959.png)

# 四、卸载 Electerm（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{% endnote %}

> 注意：本文使用到 Geek Uninstaller 卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开 Geek Uninstaller，找到 Electerm，鼠标右键选中并点击卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213102955160.png)

2\. 进入卸载界面，点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213103036789.png)

3\. 卸载中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213103211137.png)

4\. 点击**完成**，Electerm 卸载完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213103301823.png)

5\. 此时打开 Geek Uninstaller，会清理卸载残留，点击**完成**

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213103421082.png)

6\. 至此，Electerm 卸载成功，直接关闭这个窗口即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213103523562.png)
