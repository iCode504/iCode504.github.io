---
title: Intellij IDEA安装Scala插件并运行Scala程序
tags:
  - Intellij IDEA
  - Scala
category:
  - Intellij IDEA
  - Scala
description: 在Intellij IDEA中安装Scala插件，创建Scala项目以及文件，并运行Scala程序。
banner_img: 'https://icode504.oss-cn-beijing.aliyuncs.com/Intellij IDEA配置并运行Scala-封面.png'
index_img: 'https://icode504.oss-cn-beijing.aliyuncs.com/Intellij IDEA配置并运行Scala-封面.png'
abbrlink: 14
date: 2023-12-10 23:01:08
---

> 说明：安装前请确保本机已经安装了Intellij IDEA和Scala：[Intellij IDEA的安装配置教程（Windows版）](http://www.icode504.com/posts/10.html)、[Scala 2安装与配置教程（Windows版）](http://www.icode504.com/posts/13.html)

# 一、安装Scala插件

1\. 按<kbd>Ctrl</kbd>+<kbd>Alt</kbd>+<kbd>S</kbd>键，进入IDEA设置。

2\. 找到左侧的Plugins，选择Markplace，搜索Scala，选择第一个进行安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231209221212784.png)

3\. 安装完成后，点击Restart IDE，重启IDEA：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231209221335618.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231209221349578.png)

# 二、创建Scala文件并运行

1\. 点击左上角的`File --> New --> New Project`创建项目：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210205758723.png)

2\. 请确保本机已安装JDK，在新建界面选择Scala，在左下角点击Create：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210210112201.png)

3\. 点击Browse，选择Scala开发工具包：

> 没有安装Scala的小伙伴，点击右侧链接查看Scala安装教程：[点我查看](http://www.icode504.com/posts/13.html)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210210410201.png)

4\. 找到Scala的安装路径并选中，然后点击OK：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210210629651.png)

5\. 下面的界面就说明IDEA成功识别Scala的软件开发工具包，此时点击Next：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210210811446.png)

6\. 自定义项目名称和模块路径，路径推荐全英文路径，模块名称和项目名称保持一致即可，完成后点击Finish：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210211231071.png)

7\. 鼠标右键点击`src`文件夹，创建Scala文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210211934691.png)

8\. 这里文件名称使用英文名称并且是大驼峰式命名法（即每个单词首字母大写），文件类型选择Object

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210211715021.png)

9\. 输入`main`，IDEA就为我们生成一个`main`方法：

![](https://icode504.oss-cn-beijing.aliyuncs.com/23121001.gif)

10\. 然后在`main`方法中输入`println()`，`println()`方法用于控制台输出内容，在小括号内添加一对英文双引号，然后在双引号内添加任何你想要输出的内容，完整代码如下所示：

```scala
object MyFirstScalaProgram {
    def main(args: Array[String]): Unit = {
        println("这是iCode504第一个Scala程序")
    }
}
```

与Java语言不同的是，Scala中的语句不需要以分号作为结尾，上述代码中`println()`方法最后就不需要加分号。

11\. 鼠标右键，点击`Run xxx`即可运行（或者按快捷键运行，这里我设置的快捷键是<kbd>Ctrl</kbd><kbd>Shirt</kbd><kbd>F10</kbd>）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210213158770.png)

12\. 在控制台输出如下内容就说明Scala程序运行成功！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231210213259239.png)

