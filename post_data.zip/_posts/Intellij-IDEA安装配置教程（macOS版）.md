---
title: Intellij IDEA安装配置教程（macOS版）
tags:
  - macOS
  - Intellij IDEA
category_bar: true
archive: false
abbrlink: 79
description: >-
  Intellij IDEA安装与配置教程（macOS版）探讨了程序员在工作中需要掌握的工具Intellij
  IDEA，包括下载安装、JDK环境配置、创建Java项目、在IDEA运行第一个程序等。
banner_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/3183310-20231030115323179-10251545.png
index_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/3183310-20231030115323179-10251545.png
category:
  - 软件安装
  - macOS
  - 集成开发环境
date: 2024-07-14 21:51:01
password:
---

Intellij IDEA（简称 IDEA）是 Java 语言的集成开发环境，在业界公认为是一款优秀的 Java 开发工具。分为 Community 社区版（免费）和 Untimate 终极版（付费）。

IDEA 是一款智能编译器。它可以进行智能代码补全、提供问题工具窗口、代码上下文检查操作、实时模板、项目级别代码重构、重复代码检测等功能。

IDEA 终极版为现代应用程序和 Java 相关微服务开发框架提供了一流的支持。IDEA 对 SpringBoot、Jakata EE、JPA 等框架提供一流的支持。其内部支持很多的内置工具，例如：调试器、数据库工具、终端、反编译器、WEB 开发、版本控制（Git）、导航和搜索功能等。

以下是 macOS 环境下 Intellij IDEA 安装和使用：

# 一、安装前操作

检查本机信息：点击左上角苹果 logo，点击第一个**关于本机**：

![](https://source.icode504.com/images/image-20240224151904945.png)

这里需要留意一下处理器信息，这里我的电脑使用的是 Intel 芯片：

![](https://source.icode504.com/images/image-20240224152112087.png)

# 二、安装 Intellij IDEA

1\. 进入 IDEA 的官方下载页面，[点我查看](https://www.jetbrains.com.cn/idea/download/other.html)。向下找，找到 2021.1.3 版本（事实上，要下载的版本和最新版本使用 Java 编写代码的差异并不大）

![](https://source.icode504.com/images/image-20240714200819541.png)

2\. 按照下图所示操作，根据自己电脑所属的芯片，下载 IDEA 安装包：

![](https://source.icode504.com/images/image-20240714201351730.png)

3\. 双击打开 dmg 安装包：

![](https://source.icode504.com/images/image-20240714202000237.png)

4\. 将 IDEA 图标拖到 Applications 中：

![](https://source.icode504.com/images/240714001.gif)

5\. 等待一段时间后，IDEA 安装完成（上一步的窗口可以关闭了），双击打开 IDEA：

![](https://source.icode504.com/images/image-20240714202540154.png)

6\. 此时会弹出一个是否打开提示框，点击**打开**即可：

![](https://source.icode504.com/images/image-20240714202719791.png)

7\. 出现数据分享窗口后，选择**Don't Send**：

![](https://source.icode504.com/images/image-20240714202840090.png)

8\. 是否导入 IDEA 相关设置，这里我们选择第二个**Do not import settings**（不导入相关设置），然后点击 OK：

![](https://source.icode504.com/images/image-20240714203008407.png)

9\. 进入激活页面，我们下载的是 IDEA Ultimate 版，正常是需要按月或者按年支付费用的。此处我们先按照下图进行 30 天的免费试用：

![](https://source.icode504.com/images/image-20240714203201339.png)

> 如需正版，请点击右侧链接到官网购买（需要注册账号）：[点我进入](https://www.jetbrains.com.cn/idea/buy/?section=personal&billing=yearly)

10\. 出现下方这个页面以后，就说明我们 30 天使用申请成功，此时点击**Continue**：

![](https://source.icode504.com/images/image-20240714203307772.png)

11\. 进入 IDEA 欢迎界面以后，点击**Plugins**进入插件下载页面：

![](https://source.icode504.com/images/image-20240714203433311.png)

12\. 点击右上角小齿轮，点击**Manage Plugin Repositories**：

![](https://source.icode504.com/images/image-20240714203742327.png)

13\. 点击左上角的加号，复制下方链接并粘贴到输入框中，然后点击**OK**：

```
https://plugins.zhile.io
```

![](https://source.icode504.com/images/image-20240714204038845.png)

14\. 此时在插件下载页面中搜索**IDE Eval Reset**，然后点击**Install**：

> `IDE Eval Reset`插件的作用是无限延长 IDEA 的试用期。正常 IDEA 给我们的试用是 30 天，使用这款插件以后，只要快到了需要激活 IDEA 的时间，他就会自动延长一个月的试用期。从理论上来讲，安装这款插件以后，理论上就可以实现永久使用。
>
> 这款插件仅限于在 IDEA 2021.2.2 以下的版本使用，往后的版本中不适用。

![](https://source.icode504.com/images/image-20240714204528046.png)

15\. 出现此弹框时，点击**Accept**，此时 IDEA 会安装此插件：

![](https://source.icode504.com/images/image-20240714204615056.png)

16\. 至此，IDEA 安装和简单的配置已经完成了。此插件具体使用详见下一部分内容。

![](https://source.icode504.com/images/image-20240714204657381.png)

# 三、试用 Intellij IDEA 编写并运行 Java 程序

1\. 请确保本地已经安装了 JDK，如果没有安装的，查看此文章一步一步安装即可：[点我查看](http://www.icode504.com/posts/78.html)。

2\. 打开终端，输入`java -version`命令表示电脑上已经成功安装并配置了 JDK：

![](https://source.icode504.com/images/image-20240714133339950.png)

3\. 创建项目：点击左侧**Projects**，然后点击**New Project**：

![](https://source.icode504.com/images/image-20240714205132577.png)

4\. 点击左侧创建 Java 项目，此时 IDEA 会自动为我们检测本机是否安装 JDK，下图表示本机已经成功安装了 JDK（1.8.0_401 版本），确认无误后点击**Next**：

![](https://source.icode504.com/images/image-20240714205428656.png)

5\. 直接点击**Next**：

![](https://source.icode504.com/images/image-20240714205515637.png)

6\. 填写项目名称，建议是英文名称，项目存储路径建议是英文路径并且自己后续可以找到的位置，完成后点击**Finish**：

![](https://source.icode504.com/images/image-20240714205848653.png)

7\. 进入 IDEA 主界面以后，会弹出一个每日小提示窗口，按照下图所示操作将其永久关闭：

![](https://source.icode504.com/images/image-20240714210041158.png)

8\. 在左侧文件夹中，鼠标右键点击**src**蓝色文件夹，选择第一个**New**，再选择**Java Class**，创建一个 Java 文件：

![](https://source.icode504.com/images/image-20240714210404123.png)

9\. 文件的命名必须符合 Java 类的命名规范：[点我进入，查找标识符部分，查看标识符命名规范](https://zhuanlan.zhihu.com/p/654107809)

![](https://source.icode504.com/images/image-20240714210541388.png)

10\. 输入`psvm`或者`main`，然后直接回车就可以生成`main`方法：

![](https://source.icode504.com/images/240714002.gif)

![](https://source.icode504.com/images/240714003.gif)

11\. 在`main`方法里输入`sout`然后点击回车，就会生成一个换行输出的语句：

![](https://source.icode504.com/images/240714004.gif)

12\. 此时我们可以在程序中写点内容进行输出，效果图如下：

![](https://source.icode504.com/images/image-20240714211413352.png)

13\. 运行 Java 程序：这里的运行就直接包括了编译和运行两个操作，以下两种方式任选其一：

方式一：鼠标右键，点击**Run MyFirstProgram**：

![](https://source.icode504.com/images/image-20240714211459256.png)

方式二：使用快捷键，这里我使用的快捷键是<kbd>⌃</kbd><kbd>⇧</kbd><kbd>R</kbd>，具体的快捷键详见自己鼠标右键后`Run xxx`后面对应的快捷键执行即可。

运行结果如下：

![](https://source.icode504.com/images/image-20240714212131203.png)

14\. IDE Eval Reset 插件的无限期使用：点击上方**Help**，然后点击最下面的**Eval Reset**：

![](https://source.icode504.com/images/image-20240714212109347.png)

15\. 按照下图所示进行勾选，然后点击**Reset**，此时 IDEA 会自动重启。

![image-20240714212329830](https://source.icode504.com/images/image-20240714212329830.png)

16\. 此时会出现一个提示弹窗，点击 Yes，就会重启，此时 IDEA 的试用期就会延长：

![](https://source.icode504.com/images/image-20240714212415949.png)

17\. 是否退出，点击 Exit，IDEA 重启：

![](https://source.icode504.com/images/image-20240714212511062.png)

# 四、Intellij IDEA 的卸载（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{% endnote %}

1\. 打开程序最左边的访达，在最左侧点击应用程序：

![](https://source.icode504.com/images/image-20240714213011161.png)

2\. 找到 Intellij IDEA，按照下图所示操作将 IDEA 拖入到废纸篓中：

![](https://source.icode504.com/images/240714005.gif)

3\. 打开废纸篓，鼠标右键点击 Intellij IDEA 图标，选择**立即删除**，IDEA 就成功卸载了：

![](https://source.icode504.com/images/image-20240714213454446.png)

![](https://source.icode504.com/images/image-20240714213523268.png)

4\. 清理残留数据：打开终端，执行如下命令，进入到 Library 目录下：

> xxx 表示当前用户的用户名，这里直接替换成本机用户的用户名即可

```bash
cd /Users/xxx/Library
```

![](https://source.icode504.com/images/image-20240714214052411.png)

5\. 依次执行如下命令，清理残留数据：

```bash
rm -rf Preferences/JetBrains/IntelliJIdea*
rm -rf Caches/JetBrains/IntelliJIdea*
rm -rf Application\ Support/JetBrains/IntelliJIdea*
rm -rf Logs/JetBrains/IntelliJIdea*
```

![](https://source.icode504.com/images/image-20240714214721811.png)

macOS版Intellij IDEA清理卸载残留参考自犬小哈清理IDEA卸载残留教程：https://www.quanxiaoha.com/idea/uninstall-idea.html#mac