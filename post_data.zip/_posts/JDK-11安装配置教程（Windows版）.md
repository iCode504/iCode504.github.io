---
title: JDK 11安装配置教程（Windows版）
date: 2024-01-11 17:07:36
tags: [Java, Windows]
category: 
  - 软件安装
  - Windows
  - 编程语言
  - Java/JDK
abbrlink: 28
description: Windows环境下安装JDK 11教程
---

> JDK，全称Java Development Kit，即Java开发工具包，它是整个Java开发的核心，包含了Java运行环境（JVM+Java系统类库）和Java工具。目前JDK 8、11、17、21是长期稳定支持的版本。

接下来为大家讲解一下JDK 11如何安装与使用。

# 一、下载JDK

以下两种方式二选一下载即可：

## 方式一：网盘下载

请选择任意一个链接，选择任意一个安装包下载即可：

| [点击下载](https://pan.baidu.com/s/1FjQlCUulceJWOQP96qQvjQ?pwd=mclj) | [备用下载1](https://pan.baidu.com/s/1K4gR2k152JWimdxEADvp2g?pwd=1024) | [备用下载2](https://pan.baidu.com/s/1-KFO-_GQOsF2M-PVzKt24w?pwd=1024) |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111162958652.png)

## 方式二：官网下载（需要注册账号登录，不推荐）

1\. 点击此链接到官网下载页面：[点击进入](https://www.oracle.com/java/technologies/javase/jdk11-archive-downloads.html)

2\. 在下载页面，选择一个版本的JDK下载，这里我选择的是11.0.20版本的JDK。在下面找到Windows版本，这里我选择的是exe文件下载。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111164500464.png)

3\. 按图所示点击下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111164519079.png)

4\. 需要登录Oracle账号，没有账号的可以注册一个。登陆后即可下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101133536759.png)

# 二、安装JDK

1\. 双击打开JDK安装包，进入安装界面，点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111164925746.png)

2\. 更改JDK的安装路径，这里我安装在了D盘（为了避免后续使用过程中出现各种各样的问题，建议安装路径是全英文的）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111164941122.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111165150762.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111165212543.png)

3\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111165226556.png)

4\. 安装完成，点击**关闭**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111165249045.png)

> 对于首次安装的新手小白，请继续往下看；如果是老手，可以选择性往下看。

# 三、配置JDK

1\. 找到JDK的安装路径，出现bin、conf等文件夹，点击上方路径，**鼠标右键**点击**复制**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111165445818.png)

2\. 打开文件夹，在左侧此电脑**鼠标右键**点击此电脑，点击**属性**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/Snipaste_2024-01-01_01-07-23.png)

3\. 点击**高级系统设置**：

|   Windows 11   | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101010932039.png) |
| :------------: | ------------------------------------------------------------ |
| **Windows 10** | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101011132186.png) |

4\. 点击**环境变量**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002218161.png)

5\. 在下方系统变量，点击**新建**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002302057.png)

6\. 配置系统变量，按照图示操作即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111165721488.png)

7\. 双击Path进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002655185.png)

8\. 按照图示操作即可，然后一路点击确定：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002812677.png)

9\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，点击确定，进入命令行：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101003131968.png)

10\. 在命令行中，分别输入`javac`、`java`、`java -version`，如果有如下提示就说明JDK 11安装成功了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111165930479.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111170010337.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240111170348792.png)

