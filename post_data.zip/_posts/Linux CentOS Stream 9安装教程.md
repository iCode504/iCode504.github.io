---
abbrlink: '94'
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Linux CentOS安装教程.png
categories:
  - [系统安装, CentOS]
date: '2024-08-08T14:26:10.983741+08:00'
description: 本文提供了在VMware Workstation上安装和配置CentOS虚拟机的详细步骤，指导用户完成从下载镜像到系统初始化等各个环节，帮助用户快速搭建CentOS环境。
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Linux CentOS安装教程.png
order: ''
tags:
- CentOS
- CentOS Stream
title: Linux CentOS Stream 9安装教程
updated: '2024-08-08T15:44:19.622+08:00'
---
CentOS是一种基于Linux的免费、开源的操作系统，它是Red Hat Enterprise Linux（RHEL）源代码的重建版本。CentOS致力于提供稳定、可靠的服务器操作系统，广泛应用于企业级服务器和Web服务器。它具有强大的安全性和稳定性，并且提供长期支持（LTS）版本，使其成为企业级应用程序和服务的首选。CentOS还拥有庞大的软件包仓库，用户可以方便地安装和管理各种应用程序和工具。

接下来为大家介绍一下CentOS 9 Stream的安装和配置：

# 一、安装前准备

请确保电脑中已经安装了VMware和Electerm，如果没有安装的小伙伴可以点击下面的链接查看安装教程：


| 需要安装的软件名称                                        | 链接                                               |
| --------------------------------------------------------- | -------------------------------------------------- |
| 虚拟机软件VMware Workstation                              | [点我查看](https://www.icode504.com/posts/41.html) |
| 远程连接软件Electerm                                      | [点我查看](https://www.icode504.com/posts/47.html) |
| 下载器Neat Download Manager（推荐安装，可以加快下载速度） | [点我查看](https://www.icode504.com/posts/24.html) |

建议电脑预留50G的存储空间。

# 二、下载CentOS镜像

1\. 点击进入官网的下载页面：[点我查看](https://www.centos.org/download/)

2\. 这里我的电脑使用的是x64架构，点击红色框链接下载；如果你的电脑是arm64的，点击蓝色框链接下载：

![https://source.icode504.com/images/image-3fbca6912002c23ce704e1ce723a73ad.png](https://source.icode504.com/images/image-3fbca6912002c23ce704e1ce723a73ad.png)

3\. 安装包文件大小有10G，使用NDM下载需要15\~20分钟，请耐心等待。

# 三、创建CentOS虚拟机

1\. 打开VMware，按<kbd>Ctrl</kbd>和<kbd>N</kbd>键，新建虚拟机。

2\. 进入新建虚拟机向导以后，选择第二个**自定义(高级)**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213123956847.png)

3\. 点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213124330853.png)

4\. 安装客户机操作系统选择**稍后安装操作系统**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213134527045.png)

5\. 客户机操作系统选择**Linux**，版本选择**CentOS 8 64位**（截止至2024年8月，目前VMWare并没有提供最新的CentOS 9版本），完成后点击**下一步**：

![https://source.icode504.com/images/image-24aacb9a76fa1fdfbd0464c8cde27d5f.png](https://source.icode504.com/images/image-24aacb9a76fa1fdfbd0464c8cde27d5f.png)

6\. 自定义虚拟机名称和安装位置。安装位置建议安装在一个空间比较大的盘，这里我安装在了J盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135011029.png)

![https://source.icode504.com/images/image-7161e5a6220102ffd2e556852012b89b.png](https://source.icode504.com/images/image-7161e5a6220102ffd2e556852012b89b.png)

![https://source.icode504.com/images/image-338358b4bd721cd5269b04fcc09533ea.png](https://source.icode504.com/images/image-338358b4bd721cd5269b04fcc09533ea.png)

7\. 处理器配置时处理器数量和内核数量不能超过电脑自身的数量，否则虚拟机无法运行。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135358478.png)

如何检查电脑本机的CPU信息：按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，即可查看到CPU信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135636008.png)

8\. 设置虚拟机内存，内存大小按照VMware的要求设置在一定范围之内。这里我设置内存大小为2GB（2048M），完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153034658.png)

9\. 网络类型选择**网络地址转换(NAT)**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153239112.png)

10\. I/O控制器类型按照系统默认选择即可，然后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153335558.png)

11\. 虚拟磁盘类型按照默认选择即可，完成后点击**下一步**：

![https://source.icode504.com/images/image-68636df3e9dfd9185b2c31d8b16cf87f.png](https://source.icode504.com/images/image-68636df3e9dfd9185b2c31d8b16cf87f.png)

12\. 选择磁盘按照系统默认选择即可，然后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153601825.png)

13\. 最大磁盘大小建议设置在20GB及以上，这里我设置了50GB，磁盘分配按照默认勾选即可。完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153741099.png)

14\. 指定磁盘文件位置可以自定义。这里需要设置的小伙伴点击**浏览**可以更改。不需要更改的小伙伴点击**下一步**：

![https://source.icode504.com/images/image-41dfb400add6042e19a483670c1f1512.png](https://source.icode504.com/images/image-41dfb400add6042e19a483670c1f1512.png)

15\. 点击**完成**，虚拟机创建完成：

![https://source.icode504.com/images/image-e6b1949c2aee0161542061c4cc812c36.png](https://source.icode504.com/images/image-e6b1949c2aee0161542061c4cc812c36.png)

16\. 点击**编辑虚拟机设置**：

![https://source.icode504.com/images/image-d85fcbc47360f95a90b0239e1f09260d.png](https://source.icode504.com/images/image-d85fcbc47360f95a90b0239e1f09260d.png)

17\. 进入虚拟机设置后，左侧设备选择**CD/DVD**，设备状态勾选**启动时连接**，连接选择**使用ISO映像文件**，点击**浏览**：

![https://source.icode504.com/images/image-940945e57f14fc10a9cdbf501bc75bcc.png](https://source.icode504.com/images/image-940945e57f14fc10a9cdbf501bc75bcc.png)

18\. 找到前面我们下载的CentOS镜像并选中，完成后点击右下角**打开**：

![https://source.icode504.com/images/image-7fefd899917c9190862e49f966f2e99d.png](https://source.icode504.com/images/image-7fefd899917c9190862e49f966f2e99d.png)

19\. 镜像配置成功，点击**确定**：

![https://source.icode504.com/images/image-4057504488b9e4bde56bea204499cfc9.png](https://source.icode504.com/images/image-4057504488b9e4bde56bea204499cfc9.png)

# 四、开启虚拟化

1\. 开启刚刚创建好的虚拟机，此时VMware会弹出一个错误信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214629072.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113330696.png)

2\. 此时按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，虚拟化并未开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113646198.png)

3\. 重新启动电脑，具体进入BIOS可以根据自身电脑品牌型号进入。这里我的电脑使用的是华硕，开机过程中一直按<kbd>F2</kbd>键即可进入BIOS，再点击右下角**Advanced Mode**，进入高级模式：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227133747848.png)

4\. 按照下图所示操作，点击**高级**，将**Intel Virtualization Technology**配置项开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134148071.png)

5\. 按<kbd>F10</kbd>键保存上述配置并重启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134402192.png)

6\. 按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，左上角找到**性能**，发现虚拟化成功开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227114535913.png)

# 五、安装CentOS操作系统

1\. 开启刚刚创建好的虚拟机：

![https://source.icode504.com/images/image-5b80b3b4af1a2aae180460e8cf482b94.png](https://source.icode504.com/images/image-5b80b3b4af1a2aae180460e8cf482b94.png)

2\. 进入安装界面，选择**Install CentOS Stream 9**并按回车键：

![https://source.icode504.com/images/image-762728f09151dce75621e335c2692424.png](https://source.icode504.com/images/image-762728f09151dce75621e335c2692424.png)

3\. 安装语言选择**中文**，**简体中文（中国）**，完成后点击**继续**：

![https://source.icode504.com/images/image-e6f03fd2ba39347ece0256ca9d704450.png](https://source.icode504.com/images/image-e6f03fd2ba39347ece0256ca9d704450.png)

4\. 在右上角系统中，点击**安装位置**：

![https://source.icode504.com/images/image-47f98aae79d5d379f9038122cedd176d.png](https://source.icode504.com/images/image-47f98aae79d5d379f9038122cedd176d.png)

5\. 进入安装目标位置，点击左上角**完成**：

![https://source.icode504.com/images/image-deba2ed893e1b8b8de5f4ae083e74f97.png](https://source.icode504.com/images/image-deba2ed893e1b8b8de5f4ae083e74f97.png)

6\. 点击**网络和主机名**：

![https://source.icode504.com/images/image-f72488576dc3eca3e020e0f9c0a23b86.png](https://source.icode504.com/images/image-f72488576dc3eca3e020e0f9c0a23b86.png)

7\. 开启**以太网（ens160）**，确保虚拟机能连接网络。然后点击**完成**：

![https://source.icode504.com/images/image-6c71221cdd36e34149862ca67808bc72.png](https://source.icode504.com/images/image-6c71221cdd36e34149862ca67808bc72.png)

8\. 点击**软件选择**：

![https://source.icode504.com/images/image-d32a9f17f7e04e5a1f5b4ada4069dc16.png](https://source.icode504.com/images/image-d32a9f17f7e04e5a1f5b4ada4069dc16.png)

9\. 选择**Minimal Install**（最小安装），然后点击左上角**完成**：

![https://source.icode504.com/images/image-823eee7f2be7e0a7dd9146c947fd4464.png](https://source.icode504.com/images/image-823eee7f2be7e0a7dd9146c947fd4464.png)

10\. 点击为最高权限用户root设置密码：

![https://source.icode504.com/images/image-36c329335fc3c1c0106135751c16bcd5.png](https://source.icode504.com/images/image-36c329335fc3c1c0106135751c16bcd5.png)

11\. 为root用户设置密码，按照下图所示操作即可：

![https://source.icode504.com/images/image-4d4ada39a542c9777ffcdb3fedfd985e.png](https://source.icode504.com/images/image-4d4ada39a542c9777ffcdb3fedfd985e.png)

12\. 点击**开始安装**：

![https://source.icode504.com/images/image-5fa8e6968fe08e83003f58dcff993088.png](https://source.icode504.com/images/image-5fa8e6968fe08e83003f58dcff993088.png)

13\. 安装中，请耐心等待：

![https://source.icode504.com/images/image-3e706498a027bbaae95c3404c3d1ca9a.png](https://source.icode504.com/images/image-3e706498a027bbaae95c3404c3d1ca9a.png)

14\. 安装完成，点击**重启系统**：

![https://source.icode504.com/images/image-5c7f129af39b30b2a95bb902b16323fc.png](https://source.icode504.com/images/image-5c7f129af39b30b2a95bb902b16323fc.png)

15\. 重启后，进入CentOS命令行界面，用户名输入 `root`，输入前面我们设置的密码（密码不会在命令行中显示），完成后按回车：

![https://source.icode504.com/images/image-0dd7d90f94e4a6fb2679ebc73de36c8c.png](https://source.icode504.com/images/image-0dd7d90f94e4a6fb2679ebc73de36c8c.png)

16\. CentOS登录成功：

![https://source.icode504.com/images/image-a34d2af1515182011f9a2fd4bdb046b2.png](https://source.icode504.com/images/image-a34d2af1515182011f9a2fd4bdb046b2.png)

# 六、使用SSH工具（Electerm）远程连接CentOS

1\. 输入下面的命令，查看虚拟机的ip地址：

```bash
ip addr
```

![https://source.icode504.com/images/image-5c8dbf3389976dd57196205ea7a3614f.png](https://source.icode504.com/images/image-5c8dbf3389976dd57196205ea7a3614f.png)

2\. 打开Electerm，点击左侧的书签：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213171858078.png)

3\. 按照下图操作填写连接信息：

![https://source.icode504.com/images/image-e402a86783e27de1aabe5eb685e779be.png](https://source.icode504.com/images/image-e402a86783e27de1aabe5eb685e779be.png)

4\. 向下找，点击**测试连接**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221134731866.png)

等待一段时间后，如果上方出现一个 `connection is ok`，说明前面填写内容没有问题：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221134841255.png)

如果出现的时 `connection is failed`，说明填写的内容有问题，需要更改后再次测试连接。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221135000261.png)

5\. 测试连接成功后，点击**保存并连接**后，此时我们就可以在Electerm中登录root用户并执行命令了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221135129497.png)

![https://source.icode504.com/images/image-f81938d58cc5b9ee0d6861767eaaea71.png](https://source.icode504.com/images/image-f81938d58cc5b9ee0d6861767eaaea71.png)
