---
abbrlink: '35'
banner_img: https://source.icode504.com/images/postgresql-banner.jpg
categories: []
category:
- 软件安装
- Windows
- 数据库
category_bar: true
date: '2024-01-30T16:25:54+08:00'
description: 本文提供详细的步骤指导，帮助用户在Windows系统上顺利安装、配置和卸载PostgreSQL数据库软件。
index_img: https://source.icode504.com/images/postgresql-banner.jpg
order: ''
tags:
- PostgreSQL
- Windows
title: PostgreSQL安装、配置与卸载教程（Windows版）
updated: '2024-08-22T16:05:26.778+08:00'
---
PostgreSQL是基于[POSTGRES 4.2](https://dsf.berkeley.edu/postgres.html)版本的对象-关系型数据库，由加州大学伯克利分校计算机系研发。POSTGRES开创了许多先进理念，这些概念后来才在一些数据库系统中出现（他们的[官网](https://www.postgresql.org/)标题宣传的是世界上最先进的开源关系型数据库）。

PostgreSQL是原伯克利代码的后代，它是开源的，支持大部分SQL标准并提供很多现代化特性：复杂查询、外键、触发器、更新视图等。

此外，用户能以多种方式扩展PostgreSQL，例如可以添加新数据类型、新函数、新操作符等。由于自由的许可，PostgreSQL可以被任何人使用、修改、发布。

以下是Windows环境下PostgreSQL的安装、配置与卸载教程：

# 一、下载PostgreSQL

1\. 进入官网下载链接：[点我进入](https://www.enterprisedb.com/downloads/postgres-postgresql-downloads)（网页加载可能比较慢，请耐心等待）

2\. 根据自己的操作系统下载，这里我选择Windows版15.4版本：

![]()

# 二、安装PostgreSQL

1\. 双击打开安装包，进入欢迎界面，点击**Next**：

![](https://source.icode504.com/images/20240822160736.png)

2\. 选择安装路径，建议安装路径是全英文的（小白安装可以不用修改此路径），完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240105161313262.png)

3\. 选择组件：这里安装器为我们默认勾选了四个组件，简单解释一下这些组件的作用。


| 组件名称           | 说明                                                                                       |
| ------------------ | ------------------------------------------------------------------------------------------ |
| PostgreSQL Server  | PostgreSQL数据库服务器（首次安装必须勾选）                                                 |
| pgAdmin 4          | pgAdmin 4是PostgreSQL图形管理界面，用来管理PostgreSQL数据库和服务器，可以在内部编写SQL语句 |
| Stack Builder      | Stack Builder通过下载安装工具、驱动和应用，可以补充PostgreSQL未安装的内容。                |
| Command Line Tools | PostgreSQL的命令行工具，如果需要使用pgAdmin 4，需要安装命令行工具                          |

如果你是新手小白，按照系统默认勾选即可，然后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230911145322812.png)

4\. 选择数据存储路径：第2步如果选择了安装路径，那么这一步就按照系统默认安装位置即可（不用修改），点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240105163356163.png)

5\. 为超级管理员设置密码。注意：如果你记不住密码，就将密码设置成123456即可，完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230911145851183.png)

7\. PostgreSQL默认端口是**5432**，保持默认即可，不用修改。点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230911150036442.png)

8\. 地区按照系统默认选择**Default Locale**，完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230911150143566.png)

9\. 对前面安装选项进行确认，如果没有问题点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240105164020363.png)

10\. 点击**Next**，开始安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230911150301037.png)

11\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230911150326605.png)

12\. 安装完毕，点击**Finish**。Postgres安装完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130105919293.png)

# 三、卸载PostgreSQL

{% note danger %}
这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！
{% endnote %}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Uninstaller，找到PostgreSQL 15，鼠标右键，点击**卸载**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130101637247.png)

2\. 此时卸载模式，默认选择第一个**Entire Application**（完全卸载），点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130101833493.png)

3\. 卸载中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130101938418.png)

4\. 此时弹出一个卸载成功的小窗口，点击OK：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130102132979.png)

5\. 在Geek Uninstaller中清理注册表等卸载残留，点击**完成**，卸载残留清理完毕。至此，Postgres卸载完成。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240130102238678.png)
