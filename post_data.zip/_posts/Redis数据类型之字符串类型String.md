---
abbrlink: '87'
archive: false
banner_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
categories:
- 数据库
- 非关系型数据库(NoSQL)
- Redis
- Redis数据类型
category_bar: true
date: ''
description: Redis字符串类型介绍及其常用的命令
index_img: https://source.icode504.com/images/Redis安装教程（Linux版）.png
order: '40'
tags:
- Redis
title: Redis数据类型之字符串类型String
updated: '2024-08-06T15:52:21.903+08:00'
---
想学习更多Redis相关知识，请点击右侧链接查看Redis学习笔记：[点我查看](https://www.icode504.com/posts/90.html)

# 一、Redis字符串类型介绍

Redis字符串类型官网介绍（英文）

![](https://source.icode504.com/images/image-20240724223009996.png)

Redis的字符串（string）存储字节序列，包含文本、序列化对象和二进制数组。字符串类型是Redis的key对应的值中最简单的类型。字符串类型通常用于缓存，但是它们也可以实现计数和位运算等功能。

Redis字符串类型特性：**单个键（key）对应单个值（value）**。

![](https://source.icode504.com/images/image-f1474adb7a4a9785602de95d07b7154f.png)

默认情况下，一个字符串类型的值（value）最大可以存储**512MB**数据。

![](https://source.icode504.com/images/image-20240724223651330.png)

应用场景：

1\. 视频/文章点赞功能；

2\. 统计视频播放量、文章阅读量等。

# 二、Redis字符串常用命令

1\. 添加和修改Key：

```bash
SET key value
```

![](https://source.icode504.com/images/image-2a901b0690611a7031359aae33788a63.png)

如果对应的value存在空格等特殊符号，需要使用双引号：

![](https://source.icode504.com/images/image-77fbf8e4d87a87b69d254175fecc9b3c.png)

- 为当前的key设置过期时间（单位：秒）：

```bash
SET key value EX seconds
```

其中ex（expire）值的是当前的key-value存在过期时间，seconds就是我们自定义的过期时间（秒）：

![](https://source.icode504.com/images/image-02b57f88cac1a9974ae8fad0599f60a1.png)

- 为当前的key设置过期时间（单位：毫秒）

```bash
SET key value PX milliseconds
```

![](https://source.icode504.com/images/image-705784c2a1f19ec632ec1db11eeaf33e.png)

- 当前key如果不存在时，创建key，否则不创建，相当于后续学习的SETNX命令：

```bash
SET key value NX
```

![](https://source.icode504.com/images/image-3e89873a762343855f4b2036fa932fc7.png)

- 当前key如果存在时，对当前的value进行覆盖：

```bash
SET key value XX
```

![](https://source.icode504.com/images/image-41cf5e3aae6b4e89b75a712179e30ed9.png)

2\. 获取当前key对应的value：

```bash
GET key
```

这里我们顺便验证一下上述set命令是否由修改key的功能（数据覆盖）：

![](https://source.icode504.com/images/image-28cea7af55609ec0792a4ebe2d608691.png)

3\. 批量设置多个key-value：

```
MSET key value [key value ...]
```

![](https://source.icode504.com/images/image-e2536ace26340d57f76adef48331f83b.png)

4\. 批量获取多个key对应的value：

```
MGET key [key ...]
```

获取前面设置的key对应的value：

![](https://source.icode504.com/images/image-9b58a9f114c3e1a30846ffff8cd8af5c.png)

5\. 批量设置一个或多个key-value对，**当前仅当所有给定的key都不存在**：

```bash
MSETNX key value [key value ...]
```

执行成功返回1，如果命令中的key已经存在，则执行失败，返回结果是0：

![](https://source.icode504.com/images/image-fb8b56760bf93b030a66d9c43b3b823f.png)

MSETNX具有原子性，所给的key-value要么执行成功，如果有一个key已经存在，那么这个命令就不会执行成功。

6\. 获取指定区间范围内的值：

```bash
GETRANGE key start end
```

假设key对应的value默认的长度是`value.length`。和Java的字符串类似，Redis字符串从左向有得出的范围是$[0,value.length)$。

Redis对于value的索引值范围也可以从当前字符串最末尾的字符索引值是-1，前一个字符索引值为-2，以此类推（从右向左）。由此我们也可以得出Redis字符串索引值范围是$[-value.length, -1]$。

假设当前有一个key，对应的value是iCode504，下图就是对正向索引值范围和逆向索引值范围的分析：

![](https://source.icode504.com/images/image-1076b561c2fa8becf4dd98d60323243f.png)

我们在使用上述GETRANGE命令时，start和end的索引值范围是$[0, value.length)$或者$[-value.length, -1]$，两个范围的值可以混用。例如：value的开始位置0，末尾是-1，如果想通过GETRANGE获取整个字符串，那么执行命令就是`GETRANGE 0 -1`。

以下是GETRANGE命令的使用：

![](https://source.icode504.com/images/image-dcf603c77dbe6061d0dba8512660118f.png)

7\. 将当前key对应的value某个偏移量覆盖新值（overwriteValue），

```
SETRANGE key offset value
```

其中offset是偏移量，它本质上就是一个索引值，这个命令是将当前offset及之后覆盖新值value，覆盖区间：$[offset, offset + value.length)$

以下是SETRANGE实现数据覆盖的原理图：

![](https://source.icode504.com/images/image-9ad4794848618a4e0784890300a8d998.png)

以下是SETRANGE命令的使用：

![](https://source.icode504.com/images/image-7e6e141d7031ea51939d41eb4f442f6c.png)

8\. 数值加减操作：必须保证key对应的value是数字才可以进行加减操作。

下面命令的返回值都是数值增加/减少的结果：

递增数值，每次自增1：

```bash
INCR key
```

![](https://source.icode504.com/images/image-e6c32a793ccd237c80cd561489f6b26a.png)

增加指定的整数：

```bash
INCRBY key increment
```

![](https://source.icode504.com/images/image-575a722e1c570676e93783735291f1cb.png)

递减数值，每次自减1：

```bash
DECR key
```

![](https://source.icode504.com/images/image-fe3517bfd85889618543507b47d496c8.png)

减少指定的整数：

```bash
DECR key decrement
```

![](https://source.icode504.com/images/image-b27415726001c043d5860c790317574a.png)

9\. 获取字符串长度：

```bash
STRLEN key
```

![](https://source.icode504.com/images/image-3aa4ff5e2541e511d9cb20648b5c6e4c.png)

10\. 内容追加（在字符串末尾添加内容）：

```bash
APPEND key value
```

![](https://source.icode504.com/images/image-32754c3500385b5f25a6238f2f9468b9.png)

11\. 当前key不存在时，创建key；存在则不执行上述操作（该命令可用于分布式锁）：

```bash
SETNX key value
```

如果执行成功，返回结果是1；如果失败，返回结果是0

![](https://source.icode504.com/images/image-4dae23cd2ea1dd158f9773bc134dd903.png)

12\. 为当前key设置过期时间（单位：秒，该命令可用于分布式锁）：

```bash
SETEX key seconds value
```

![](https://source.icode504.com/images/image-a5d91ddff5c5b28557b761e191b798e9.png)

13. GETSET命令：先执行GET命令并返回当前key对应的value，然后对key**立即执行**GET操作：

```bash
GETSET key value
```

![](https://source.icode504.com/images/image-94033a91a726b3d72b0526a089dbb90b.png)

# 三、Redis字符串命令的注意事项

大多数字符串命令的时间复杂度是$O(1)$，这也就意味着执行这些命令效率非常高。需要注意的是，如下几个命令的时间复杂度是$O(n)$：

- SUBSTR
- GETRANGE
- SETRANGE

这几个随机访问的字符串命令在处理超大字符串的时候可能会出现性能问题。
