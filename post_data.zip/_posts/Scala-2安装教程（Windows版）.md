---
title: Scala 2安装教程（Windows版）
date: 2023-12-10 22:35:26
tags: [Scala 2, Windows]
category: 
  - 软件安装
  - Windows
  - 编程语言
  - Scala
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Scala 2安装与配置教程（Windows版）-封面.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Scala 2安装与配置教程（Windows版）-封面.png
description: 本教程提供了Scala安装的详细步骤，包括前期准备、下载Scala安装包、配置环境变量以及验证安装是否成功。遵循本教程，用户可以在自己的计算机上轻松安装Scala，为后续的Scala编程和开发打下基础。
abbrlink: 13
---

[Scala官网](https://scala-lang.org/)介绍：Scala是一门现代多范式编程语言，旨在以简洁、优雅和类型安全的方式表达常见的编程模式。它无缝衔接了面向对象语言和函数式语言的特性。

Scala是一门纯粹的面向对象语言，因为每个值都是一个对象。对象的类型和行为是通过类和特征来描述的。类可以通过子类化进行扩展，并使用灵活的基于mixin的组合机制作为多重继承的干净替代。

Scala 也是一门函数式语言，因为每个函数都是一个值。Scala 提供了定义匿名函数的轻量级语法，支持高阶函数，允许嵌套函数，并支持柯里化。Scala 的大小写类及其对模式匹配的内置支持提供了代数类型的功能，这在许多函数式语言中都有应用。单例对象为分组非类成员的函数提供了一种便捷的方式。

接下来就讲解一下Scala的下载与安装。

# 安装前检查

请确保电脑本机安装了JDK，如果没有安装，请点击右侧链接查看JDK安装教程：[点我查看](https://www.icode504.com/posts/1.html)

安装完成后，按<kbd>Win</kbd>+<kbd>R</kbd>键，输入`cmd`，进入控制台，输入`java -version`，如果出现如下内容，就说明JDK已经安装成功了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314140629530.png)

> 如果后续在官网下载Scala安装包比较慢，我个人推荐使用NDM（Neat Download Manager）下载器来下载，可以加快下载速度。
>
> 如果不需要或者已安装的朋友请忽略。没有安装的小伙伴可以点击右侧链接查看安装教程：[《NDM下载器安装配置教程》](https://www.icode504.com/posts/24.html)

注意：下文一共提供了两种方式安装Scala，第三种方式是在线体验Scala。**方式一、方式二任选其一安装**即可。

# 方式一：MSI方式安装Scala

## 一、Scala安装包下载

1\. 点击右侧链接，进入下载页面：[点我查看](https://www.scala-lang.org/download/all.html)

2\. 这里我选择的是`2.12.18`版本的，在下方找到版本号后点击进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231209211237501.png)

3\. 进入下载页面后，向下找到各个版本的下载链接，我使用的是Windows操作系统，这里我就点击Windows系统版本的Scala进行下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231209211413991.png)

## 二、安装Scala

1\. 双击打开Scala安装包，会出现欢迎界面，然后点击`Next`：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231012103003352.png)

2\. 勾选下面的协议，然后点击`Next`：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231012103048983.png)

3\. 选择安装路径，推荐安装在除C盘外的其他路径，并且路径中只包含英文，这里我安装在了D盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231012103459245.png)

4\. 点击`Install`:

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231012103526813.png)

5\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231012103553892.png)

6\. 点击Finish，Scala安装完成

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231012103625099.png)

7\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，进入命令提示行页面，输入`scala -version`，如果出现下图所示信息，说明Scala安装配置成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231012105320529.png)

## 三、卸载Scala（可选）

1\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`appwiz.cpl`，然后点击确定：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228090817000.png)

2\. 调出程序与功能的界面以后，找到`Scala Programming Language Distribution`，鼠标右键，点击卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228091109617.png)

3\. 选择“是”：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228091144885.png)

4\. Scala卸载中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228091227059.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228091232179.png)

5\. Scala卸载完成！此时在控制台上输入`scala -version`无反应：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228091352622.png)

# 方式二：压缩包方式安装Scala

## 一、Scala安装包下载

1\. 点击右侧链接，进入下载页面：[点我查看](https://www.scala-lang.org/download/all.html)

2\. 这里我选择的是`2.12.18`版本的，在下方找到版本号后点击进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231209211237501.png)

3\. 进入下载页面后，向下找到各个版本的下载链接，我使用的是Windows操作系统，这里我就点击Windows系统版本的Scala进行下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228092026444.png)

## 二、安装配置Scala

1\. 将下载好的压缩包解压到一个你熟悉的位置（为了避免后续出现各种奇奇怪怪问题，建议文件路径选择英文路径），这里我安装在了D盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228092238561.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228092350172.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228092413901.png)

2\. 找到Scala安装路径，并复制：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228093714744.png)

3\. 打开文件夹，在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314133908963.png)

4\. 点击高级系统设置

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314134201936.png)

> Windows 10的高级系统设置在右侧：
>
> ![](https://icode504.oss-cn-beijing.aliyuncs.com/Snipaste_2023-03-14_13-44-54.png)

5\. 点击环境变量

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314134716166.png)

6\. 点击新建

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314134919881.png)

7\. 配置系统变量，按照图示操作即可

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228094023984.png)

8\. 双击Path进入

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228094502229.png)

9\. 按照图示操作即可，然后一路点击确定。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228094240240.png)

10\. 验证Scala环境变量是否配置成功：按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，打开命令行窗口，输入`scala -version`，出现Scala版本信息就说明Scala环境变量配置成功了！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228094810283.png)

## 三、移除Scala（可选）

1\. 找到Scala的安装目录，鼠标右键删除即可（如果不走回收站彻底删除，就直接按<kbd>Shift</kbd>和<kbd>Delete</kbd>键）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228095440509.png)

2\. 删除环境变量：按照前面配置步骤，打开环境变量。找到前面我们配置的`SCALA_HOME`，点击右下角**删除**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228095642032.png)

3\. 双击进入Path：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228100153183.png)

4\. 找到并选中`%SCALA_HOME%\bin`，然后一路点击确定即可。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228100351079.png)

至此，Scala就从本机成功移除了。

# 方式三：免安装，直接在线体验Scala

我们可以使用Scala官网为我们提供了在线编程页面，这种方式最大的优点是你不需要安装Scala，直接编程运行体验。但是缺点也很明显，后续使用Scala及大数据相关框架我们使用的最多的还是本地安装Scala，在Intellij IDEA中编写代码。

这种方式非常适合新手，省去安装配置Scala的各种繁琐步骤。

1\. 浏览器打开Scala官网在线编程界面：[点我查看](https://scastie.scala-lang.org/)

2\. 以下是我在编辑器中写的一段Scala代码（演示用，感兴趣的可以敲一敲）：

```scala
var greeting: String = "你好，我是iCode504，程序猿一枚，请多指教！"
println(greeting)

var a: Int = 20
var b: Int = 40
println("a + b = " + (a + b))
```

3\. 点击左上角的`Run`即可运行：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228105809379.png)

4\. 在下方的控制台即可看到内容的输出：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231228105819934.png)

