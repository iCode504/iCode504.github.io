---
title: VS Code查看Git提交记录
tags:
  - VS Code
  - Git
category_bar: true
abbrlink: 43
description: VS Code默认不显示项目的Git提交历史，需要安装插件才能实现效果
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/VS Code查看Git提交记录.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/VS Code查看Git提交记录.png
category:
  - VS Code
  - Git
date: 2024-02-05 14:34:10
---


在IDEA中，我们可以看到项目中Git的提交记录，但是VS Code中默认没有Git历史记录。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205141727113.png)

我们可以到VS Code插件商店中搜索`Git Graph`插件并安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205142106021.png)

安装完成，点击左侧**Git图标**，选择**Git分支图标**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205142400893.png)

此时我们就可以看到这个项目的Git提交历史了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205142643306.png)
