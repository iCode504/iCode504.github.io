---
title: Vue的数据代理
tags:
  - Vue
category_bar: true
archive: true
author: iCode504
category:
  - Vue
  - Vue基础知识
password: 123456
abbrlink: 2506480934
date: 2024-02-11 16:06:00
description:
banner_img:
index_img:
---

# 一、Object.defineproperty方法

`Object.defineproperty`方法一共有三个参数：第一个是要操作的对象，第二个是向这个对象添加的属性名称，第三个是向这个对象属性要配置的内容。用法如下：

假设现在我要定义一个person对象，有姓名和职业两个属性，并对该对象输出，代码如下：

```javascript
let person = {
  name: 'iCode504',
  work: '程序员'
};
console.log(person);
```

输出效果如下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213114648909.png)

此时我还想在这个对象添加`age`属性，并将这个属性赋值为22。在person对象中再添加一个`age`属性是一种办法，虽然可以实现预期效果，但是这样就显得不灵活。此时我们可以使用`Object.defineProperty`方法为对象再添加一个属性：

```javascript
let person = {
  name: 'iCode504',
  work: '程序员'
};
// 为person对象添加一个age属性，并赋值为22
Object.defineProperty(person, 'age', {
  value: 22
})
console.log(person);
```

其中第三个参数的`value`属性作用是给当前对象的新属性`age`赋值。此时我们再来看一下输出内容，`age`属性添加到了`person`对象中：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213115334814.png)

## 1.1 enumerable属性

`age`属性确实添加到了`person`对象，但是貌似和原生的属性有一点点不同（例如：在上面的结果中，原生的属性颜色更深，新添加的`age`属性颜色较浅）。

二者区别在于原生的属性可以遍历，新添加的属性无法参与到遍历中，这一点我们可以使用`foreach`遍历所有属性来验证：

```javascript
let person = {
  name: 'iCode504',
  work: '程序员'
}
Object.defineProperty(person, 'age', {
  value: 22
});
for (const key in person) {
  console.log(person[key])
}
```

从控制台的输出结果可以看出，属性`age`的值并没有输出。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213133651951.png)

要想让`age`属性对应的值也可以输出，需要对`Object.defineProperty`的第三个参数添加一个配置：**enumerable属性设置为true**。`enumerable`属性就是**控制当前对象属性是否可以参与枚举遍历**，默认值是`false`。修改后代码如下：

```javascript
let person = {
  name: 'iCode504',
  work: '程序员'
}
Object.defineProperty(person, 'age', {
  value: 22,
  enumerable: true    // 控制当前对象属性是否可以枚举遍历
});
for (const key in person) {
  console.log(person[key])
}
```

此时控制台就可以输出`age`属性了。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213134214895.png)

## 1.2 writable属性

如果我在控制台修改`age`属性值，然后再输出对象内容，并没达到预期效果，`age`在对象中对应的值并没有改变：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213134654448.png)

`Object.defineProperty`第三个参数添加一个配置，**writable属性**，它能**控制当前对象属性是否可以被修改**，默认值是`false`。如果我们将其设置成`true`时，就能达到预期效果了：

```javascript
Object.defineProperty(person, 'age', {
    value: 22,
    enumerable: true,    // 控制当前对象属性是否可以枚举遍历
    writable: true      // 控制当前对象属性值是否可以修改
});
```

运行效果如下所示，此时修改`age`属性值成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213135157761.png)

## 1.3 configuable属性

如果我想删除`age`属性，控制台提示`false`，说明这个属性并没有删除成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213141551640.png)

我们只需要对`Object.defineProperty`的配置列表中添加`configurable`属性：**控制当前对象属性是否可以被删除**，默认值是`false`。代码如下：

```javascript
Object.defineProperty(person, 'age', {
  value: 22,
  enumerable: true,    // 控制当前对象属性是否可以枚举遍历，默认是false
  writable: true,      // 控制当前对象属性值是否可以修改，默认是false
  configurable: true     // 控制当前对象属性是否可以删除，默认是false
});
```

运行结果符合我们预期，`age`属性删除成功：

![image-20231213141818284](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213141818284.png)

## 1.4 getter和setter

如果要读取这个对象属性，`get`函数（getter）就会被调用，且返回值就是age的值。

> 已知我们存在一个person对象，在代码中创建一个变量number，让person的age属性的值随着number改变而改变。

此时使用getter就是一个非常好的解决方案：

```javascript
let person = {
  name: 'iCode504',
  work: '程序员'
}

let number = 23;	// 外部变量
Object.defineProperty(person, 'age', {
  get() {
    console.log('获取age属性时调用了get函数');  // 输出提示语
    return number;
  }
});
```

此时我们可以到控制台测试一下：

![image-20231213143741848](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213143741848.png)

**value属性和getter不能共存，只能留一个**。

如果要修改这个对象属性，`set`函数（setter）就会被调用，且会收到修改的具体值。

```javascript
Object.defineProperty(person, 'age', {
  get() {
    console.log('获取age属性值调用了get函数');  // 输出提示语
    return number;
  },
  
  set(value) {
    console.log('修改age属性值调用set函数');    // 输出提示语
    number = value;
  }
});
```

此时我们修改`age`属性值是就会调用setter：

![image-20231213144724503](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213144724503.png)

# 二、Vue的数据代理

1\. 数据代理：通过一个对象代理对另一个对象中的属性的操作（读/写）。

2\. Vue中的数据代理：通过vm对象来处理data对象中属性的操作（读/写）。

- 通过`Object.defineProperty()`把data对象中所有的属性添加到`vm`上。
- 为每一个添加到`vm`上的属性，都指定一个`getter/setter`。
- 在getter/setter内部去操作（读/写）data中对应的属性。

![](https://icode504.oss-cn-beijing.aliyuncs.com/231213dp1.drawio.svg)

3\. Vue中数据代理的好处：更加方便地操作data中的数据。

4\. 基本原理：

```html
<div id="app">
  你好，我是{{name}}，今年{{age}}岁了
</div>

<script>
  const vm = new Vue({
    el: '#app',
    data: {
      name: 'iCode504',
      age: 23
    }
  });
</script>
```

首先，实例`vm`本身会创建一个属性`_data`，这个属性存储是源代码中的`data`的值，并为原来`data`对象中的每个属性创建getter/setter。但是Vue本身为了做到响应式页面，对`data`中的内容做了数据劫持操作，此时`_data`中存储内容既包含源代码中`data`中的内容，也包含数据劫持后的信息：

在控制台输入`vm`并回车，找到 `_data`属性，内容如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213155739277.png)

如何验证`_data`和`data`二者是相等的。我们可以把data中的值单独抽取出来：

```javascript
let data = {
  name: "iCode504",
  age: 23,
};

const vm = new Vue({
  el: "#app",
  data
});
```

此时我们在控制台中使用严格等于`===`对`vm._data`和`data`进行比较，发现结果是`true`，符合上述要求。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213160527049.png)

实例`vm`中之所以存在`name`和`age`两个属性，是因为这两个属性是通过`Object.defineProperty`实现的，并为这两个属性添加了getter/setter：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213160031134.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231213160056705.png)



如果我们在控制台修改`vm`中的`name`和`age`属性，也会导致`data`（`_data`）中属性发生改变，从而页面内容发生改变。接下来我们就来验证一下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240212133821825.png)