---
title: >-
  Vue项目启动报错 Component name xxx should always be multi-word
  vue/multi-word-component-names
tags:
  - Vue
  - Vue Bug
category_bar: true
archive: false
description: >-
  创建并通过npm run命令启动Vue项目报错Component name xxx should always be multi-word
  vue/multi-word-component-names的解决办法
category:
  - Vue
  - Bug
date: 2024-02-29 15:15:29
abbrlink: 53
banner_img:
index_img:
password:
---




# 一、问题复现

今天在写Vue代码时，启动时出现了报错信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240229143247782.png)

# 二、问题分析

出现上述错误的主要原因就是我们的Vue文件名不符合Vue官方的命名规范

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240229143710857.png)

[Vue官方文档](https://cn.vuejs.org/style-guide/rules-essential)提供了详细的说明：

<font color="FF0000">除了App组件以外，其他所有的组件都应该以多个单词组合命名</font>。这样做的目的是避免和HTML自带的标签冲突（因为所有HTML标签都是用单个单词命名）。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240229143934337.png)

# 三、解决方案

共有两种解决方案任选其一：

## 方案一：修改文件名（虽然麻烦，但是推荐）

将所有组件中出现的单个单词都修改成多个单词命名（大驼峰命名法或者单词之间使用`-`做分隔），这里我将我的组件都命名成`My`+`xxx`的形式，例如：`MySchool`、`MyStudent`：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240229150105631.png)

需要注意的是，文件名修改后，文件中出现和文件名相关的内容也需要修改：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240229150407355.png)

## 方案二：修改vue.config.js文件（简单，但只推荐在学习中使用）

打开`vue.config.js`文件，添加如下内容

```text
lintOnSave: true
```

添加效果如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240229150713246.png)

通过`npm run`命令也可以运行：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240229150916373.png)

虽然这样改确实很方便，但是文件命名方式有可能违背了Vue组件命名规范，仅限制在学习过程中使用！

# 四、参考

https://www.cnblogs.com/XYH-Learning/p/16305348.html

https://vuejs.org/style-guide/rules-essential
