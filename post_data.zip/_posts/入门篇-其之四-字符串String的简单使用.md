---
description: 字符串的定义与简单使用、转义字符、类和对象的简介、引用数据类型变量的默认值null
abbrlink: 5
date: 2023-12-07 16:30:47
title: 入门篇-其之四-字符串String的简单使用
tag: Java
category: iCode504的Java学习空间
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/3183310-20230925112204369-1852040063.png
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/3183310-20230925112204369-1852040063.png
---
> 本文中使用到的工具是JDK 8，需要安装的小伙伴请点击右侧连接查看教程：[点我查看安装JDK8教程](https://www.icode504.com/posts/1.html)。

# 一、什么是字符串？

在Java编程语言中，字符串用于表示文本数据。

字符串（`String`）属于引用数据类型，根据`String`的源码，其头部使用`class`进行修饰，属于类，即引用数据类型。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230909092329429.png)

# 二、字符串的表示

**字符串使用双引号`""`表示**，在双引号中你可以写任意字符。

和前面定义并初始化基本数据类型的变量一样，定义最简单的字符串可以用如下方式：

```java
String 变量名 = "任意字符";
```

以下是示例代码：

```java
/**
 * 字符串最简单的定义
 *
 * @author iCode504
 * @date 2023-09-09 09:30:37
 */
public class MyFirstString {
    public static void main(String[] args) {
        // 定义并初始化String类型的变量
        String myString = "浔阳江头夜送客，枫叶荻花秋瑟瑟。";
        System.out.println(myString);
        myString = "主人下马客在船，举酒欲饮无管弦。";
        System.out.println(myString);
        // 当然，你也可以不在双引号中写任意内容，即“空字符串”
        myString = "";
        System.out.println(myString);
        // 直接输出字符串
        System.out.println("醉不成欢惨将别，别时茫茫江浸月。");
    }
}
```

输出结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230909093742973.png)

# 三、转义字符

使用`\`和某个特定字符可以更改其原有的字符含义。

例如：

- **`\n`能够换行**（相当于按了一下<kbd>Enter</kbd>键）；

- **`\t`具有制表符效果**（相当于按了一下<kbd>Tab</kbd>键）；

```java
/**
 * 转义字符--换行符\n和制表符\t的使用
 *
 * @author iCode504
 * @date 2023-09-09 11:49:18
 */
public class EscapeCharacters {
    public static void main(String[] args) {
        // 换行符
        String myString1 = "窈窕淑女\n寤寐求之";
        // 制表符
        String myString2 = "求之不得\t寤寐思服";
        System.out.println(myString1);
        System.out.println(myString2);
    }
}
```

运行结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230909115309017.png)

前面我们说过，字符串是使用英文的双引号表示，如果我想在双引号内直接输出双引号会报错，例如：

```java
// 错误写法，因为最左侧的双引号只能识别到最近的双引号，其他双引号会导致无法识别而无法通过编译
String myString = ""悠哉游哉，辗转反侧"是《诗经》中经典名句";
```

那么，如果我们需要在双引号内部表示出字符串怎么办？使用`\"`表示双引号，如果想要表示反斜杠（Windows的文件路径会使用到），要写成`\\`。

以下是示例代码：

```java
/**
 * 转义字符--双引号和反斜杠的输出
 *
 * @author iCode504
 * @date 2023-09-09 16:23:48
 */
public class EscapeCharacters1 {
    public static void main(String[] args) {
        // 使用\"表示双引号
        String myString1 = "\"悠哉游哉，辗转反侧\"是《诗经》中经典名句";
        System.out.println(myString1);
        // \\表示反斜杠
        String myString2 = "参差荇菜\\左右采之";
        System.out.println(myString2);
    }
}
```

运行结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230909163649777.png)

# 四、字符串的简单应用

## 4.1 获取字符串的长度

字符串的长度取决于字符串中写了多少个字符（转义字符算一个字符），如果是空字符串，那么字符串的长度为0。

可以使用**`length()`方法获取当前字符串的长度**。

```java
/**
 * 字符串长度获取
 *
 * @author iCode504
 * @date 2023-09-09 09:44:37
 */
public class StringLength {
    public static void main(String[] args) {
        String myString = "关关雎鸠，在河之洲。";
        // 获取字符串的长度（双引号内所有字符的数量）
        int length = myString.length();
        System.out.println(length);
        myString = "";
        // 获取空字符串的长度
        length = myString.length();
        System.out.println(length);
        // 转义字符算一个字符
        myString = "E:\\Code";
        length = myString.length();
        System.out.println(length);
    }
}
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230925095455512.png)

## 4.2 字符串的简单拼接

假设当前有两个字符串`str1`和`str2`，二者的值分别是`"窈窕淑女"`和`"君子好逑"`，如果我想将二者拼接成一个字符串该怎么办？

可以使用`+`拼接两个字符串。注意：**这里的`+`并不是算术意义上的加号，它在字符串中只负责拼接的作用**。**只要`+`一侧有字符串，那么这个`+`就会将另一侧的数据类型变为字符串类型**。

```java
/**
 * 使用+拼接字符串
 *
 * @author iCode504
 * @date 2023-09-09 11:14:46
 */
public class StringSplicing1 {
    public static void main(String[] args) {
        String myString1 = "窈窕淑女";
        String myString2 = "君子好逑";
        // 两个字符串拼接，结果仍为字符串
        String result = myString1 + myString2;
        System.out.println(result);

        System.out.println("--------------------");
        // 字符串拼接基本数据类型的数据
        System.out.println(myString1 + 20);
        System.out.println(myString1 + 'A' + 20);
        System.out.println(myString1 + 20.34);
        System.out.println(myString1 + true);
    }
}
```

运行结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230909112428736.png)

后四个输出结果中我们可以得知：`+`右侧的基本数据类型自动转换成字符串，然后`+`对左右两侧的字符串进行拼接形成新的字符串进行输出。

但与此同时，我们也发现另外一种情况：`System.out.println(myString1 + 'A' + 20);`，它得到的结果是`窈窕淑女A20`，如果我想对后两者先计算后拼接，可以直接使用小括号对后两者优先计算：

```java
System.out.println(myString1 + ('A' + 20));
```

此时加上括号以后，会先计算`'A'`和`20`相加的结果，此时`'A'`会自动提升为`int`类型的值为`65`，`65`和`20`相加的结果就是`85`，输出结果就是`85`

前期学习过程中，使用`+`拼接字符串比较方便。当然，在后续深入学习字符串的过程中，我们会使用比`+`更加高效的方法。

# 五、类和对象简介

[前面](https://www.icode504.com/posts/4.html)我们提过，引用数据类型一共分为5种：类、接口、数组、枚举、注解。

类（Class）和对象（Object）是面向对象编程的两个核心概念。

类是对现实世界事物的抽象，它是一种定义了**属性**（Fields）和**方法**（Methods）的蓝图和模板，用于创建对象。

- 属性（Fields）是**类中的变量**，它们用于存储对象的状态和特征。

- 方法（Methods）是一种可重用的代码块，它用于**执行特定的任务操作**。方法是类和对象的一部分，它规定了如何执行特定的操作和计算。一个方法包含如下部分：
    - **方法名**：用于描述方法的功能。
    - **返回类型**：指定方法的返回值的数据类型。如果方法没有任何返回值，返回类型为`void`。
    - **参数列表**：包含方法需要的输入值，如果有多个参数，它们使用逗号进行分隔。
    - **方法体**：包括方法执行代码，通常包含一系列的语句。

我们可以定义一个`Keyboard`（键盘）类，这个类具有如下属性：键盘的宽度`width`、高度`height`、重量`weight`、颜色`color`、轴体数量`count`（87键、108键等）。方法有：开启键盘背景灯`turnOnBackLight`、敲击某个键`click`

创建一个键盘类`Keyboard`，类是由`class`修饰的，类名要符合标识符命名规范：

```java
public class Keyboard {
    
}
```

在这个类中，我们可以定义上述属性，轴体数量`count`为`int`类型、键盘宽度、高度、重量为`double`类型，其他的都为`String`类型。在类中定义如下属性：

```java
public class Keyboard {
    // 键盘宽度
    double width;
    // 键盘高度
    double height;
    // 键盘重量
    double weight;
    // 键盘颜色
    String color;
    // 按键数量
    int count;
}
```

键盘有如下功能：敲击`click`、开背景灯`turnOnBackLight`，这两项功能可以写进类，在类中作为方法存在：

```java
/**
 * 键盘类--包含属性和方法
 *
 * @author iCode504
 * @date 2023-09-10 10:44:25
 */
public class KeyBoard {
    // 键盘宽度
    double width;
    // 键盘高度
    double height;
    // 键盘重量
    double weight;
    // 键盘颜色
    String color;
    // 键盘数量
    int count;

    /**
     * 开启键盘背景灯的方法
     */
    public void turnOnBackLight() {
        System.out.println("开启键盘灯");
    }

    /**
     * 敲击键盘某个键的方法
     *
     * @param key 传入敲击的单个字符
     */
    public void click(char key) {
        System.out.println("敲击了" + key + "键");
    }
}
```

至此，“键盘”这张图纸（模板）就创建好了。

在这个类中，我们发现两个方法的返回值类型都为`void`，方法体的功能都是输出一句话。其中`click`方法传入了一个`char`类型的值。在方法上建议编写注释，便于了解这个方法的功能。

对象（Object）是类的实例。创建对象的过程称为**实例化**。每个对象都有其自身的属性和方法，这些属性和方法定义在类中。在Java中，每个对象都有一个引用变量，该变量存储对象的内存地址。通过引用变量，可以访问和修改对象的属性和方法。

我们可以利用上述图纸来打造一款键盘（创建对象）了，使用**`new`**关键字来创建对象：

```java
/**
 * 创建键盘类对象，并为属性赋值
 *
 * @author iCode504
 * @date 2023-09-10 10:48:45
 */
public class MyKeyBoardTest1 {
    public static void main(String[] args) {
        KeyBoard keyBoard = new KeyBoard();
        System.out.println(keyBoard.width);
        System.out.println(keyBoard.height);
        System.out.println(keyBoard.weight);
        System.out.println(keyBoard.color);
        System.out.println(keyBoard.count);
        System.out.println("----------分割线----------");

        keyBoard.width = 35.55;
        keyBoard.height = 12.22;
        // 重量按公斤算
        keyBoard.weight = 2.02;
        keyBoard.color = "天蓝色";
        keyBoard.count = 87;
        System.out.println("键盘的宽度是: " + keyBoard.width + "cm");
        System.out.println("键盘的高度是: " + keyBoard.height + "cm");
        System.out.println("键盘的重量是: " + keyBoard.weight + "kg");
        System.out.println("键盘的颜色是: " + keyBoard.color);
        System.out.println("键盘一共有" + keyBoard.count + "个键");
        keyBoard.turnOnBackLight();     // 调用开启键盘背景灯的方法
        keyBoard.click('D');        // 调用按下某个键的方法
    }
}
```

运行结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230925092021916.png)

创建对象以后，依照目前编写的代码来看，我们可以直接使用**`对象名.属性名`**获取到属性值。

在分割线之前的输出中，我们并没有给每一个属性进行赋值，因此在分割线之前输出的是各种类型的默认值：**整数类型默认值是0，浮点类型默认值为0.0，字符类型默认值是Unicode字符表的第一个字符，布尔类型默认值是`false`，引用数据类型的默认值为`null`（`null`在后面会讲到）**。

因此：前三个属性在类中是`double`类型，所以输出的值都是0.0，`String`为引用数据类型，输出结果为`null`，最后一个为`int`类型，输出默认值为0。

分割线后五行我们为属性进行赋值，此时分割线后五行的内容就是我们赋值后的结果。

对象在调用方法时使用**`对象名.方法名`**，**如果方法在定义时有相应类型的参数，则传入参数值的顺序、数量、类型必须和类中定义的方法保持一致**。在上述测试代码中，调用了无参的`turnOnBackLight`方法和一个参数的`click`方法，在类中定义的`click`方法有一个`char`类型的参数，因此传入的值必须是`char`类型，因此将字符`'D'`传入`click`方法是正确的。

当然，这一部分只是类和对象的冰山一角，更具体的内容需要到后续的文章中继续学习。

# 六、引用数据类型默认值：null

## 6.1 null的定义与使用

`null`是Java的关键字，只能小写，不可随意更改。对于Java程序员来说，`null`是一个令人反感（咬牙切齿）的存在。

`null`主要是用在引用对象无法确定的情况。比如说，我在`main`方法中定义一个字符串，但是这个字符串具体值是什么无法确定，但是在方法中只定义变量而不赋值是不能通过编译的，此时我们可以使用`null`赋值给字符串对象。

**`null`是引用数据类型的默认值**。以`String`类为例，`String`就是一个引用数据类型，因此将`null`赋值给`String`类型的变量是合法的：

```java
String str = "iCode504";
// 将null赋值给String
str = null;
```

`null`并不是一个有效的对象实例，如果给一个对象赋值为`null`，那么当前对象引用当前不引用对象。

`"iCode504"`是在内存中实际存在的字符串，它在内存表现形式如下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230925101945789.png)

如果将`str`赋值为`null`，那么它不会指向堆内存中的对象。也就是说，在堆内存中原有的字符串对象会等待JVM（Java虚拟机）垃圾回收机制进行回收。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230925102249365.png)

`null`不可以赋值给基本数据类型的变量。以下的写法都是错误的：

```java
// 以下写法都是错误的，因为null只能赋值给引用数据类型
byte byteValue = null;
short shortValue = null;
int intValue = null;
long longValue = null;
float floatValue = null;
double doubleValue = null;
char charValue = null;
boolean booleanValue = null;
```

如果引用数据类型的变量值为`null`，直接调用引用数据类型的方法会产生空指针（NullPointerException，~~臭名昭著~~）异常：

```java
/**
 * 引用数据类型的默认值--null
 *
 * @author iCode504
 * @date 2023-09-10 09:37:32
 */
public class NullValue {
    public static void main(String[] args) {
        // 引用数据类型的默认值，赋值给String是合法的
        String str = null;
        System.out.println(str);
        // 间接调用null会出现NullPointerException空指针异常，开发过程中要尽量避免这种情况的发生
        int length = str.length();
        System.out.println(length);
    }
}
```

运行结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230910094330303.png)

## 6.2 空字符串与null的区别

在Java中，空字符串`""`和`null`是两种不同概念，它们在内存中表示和处理方式有很大区别。

空字符串`""`：在Java中，空字符串是一个包含0个字符的字符串示例。当我们创建一个空字符串变量时，它会在内存中占用空间，并且这个对象是分配给`String`对象的。例如：

```java
String str = "";
```

上面代码中，`str`是指向`String`对象的引用，而这个`String`对象在内存中会占用一定的空间，只是它包含的字符数为0。以下是`String str = "";`在JDK 8版本中，内存简要存储情况图：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230922235045584.png)

`null`：在Java中，`null`和`0~9`一样都是字面值，表示对象引用不指向任何对象，`null`是一个特殊值，表示一个引用类型变量没有实际值，声明一个引用类型变量但是不给变量赋值，它的默认值就是`null`。例如：

```java
public class Cat {
	String name;	// 不给name属性赋值，创建Cat对象并调用这个属性，默认输出为null
}

class CatTest {
	public static void main(String[] args) {
    	Cat cat = new Cat();
        System.out.println(cat.name);		// 输出结果为null
    }
}
```

运行结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230923073448725.png)

总结：空字符串`""`是一个包含0个字符的字符串实例，它在内存中占用空间。而`null`是一个字面值，表示对象引用不指向任何对象。

## 6.3 null的其他作用

1\. 可以使用比较运算符`==`来判断一个引用数据类型是否为`null`，例如：

```java
String str = null;
System.out.println(null == str);	// 判断引用数据类型String是否为null
```

2\. `null`本身不是对象，也不是任何类型的实例。我们可以使用`instanceof`运算符判断引用数据类型变量或值是否属于当前类型，此时我们使用`null`来判断它是否属于`Object`类型：

```java
/**
 * null是否属于Object类型
 *
 * @author ZhaoCong
 * @date 2023-09-10 10:39:02
 */
public class NullTypeCheck {
    public static void main(String[] args) {
        if (null instanceof Object) {
            System.out.println("null属于Object类型");
        } else {
            System.out.println("null不属于Object类型");
        }
    }
}
```

运行结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230925104106704.png)

Object类是所有类的父类，而输出结果中我们也可以判断出`null`不属于`Object`类型，它不属于任何类型的实例。

关于null的更多知识，详见如下文章：[深入关键字null](https://blog.51cto.com/lavasoft/79243)、[java中的null类型---有关null的9件事](https://blog.csdn.net/qq_25077777/article/details/80174763)