---
title: 软件包管理器Homebrew安装教程（适用于macOS系统）
tags:
  - Homebrew
  - macOS
category_bar: true
archive: false
abbrlink: 82
description: >-
  本文介绍了在 macOS 系统上安装 Homebrew 的详细步骤。内容包括在终端使用简单命令进行安装，配置路径以确保正确使用，以及如何通过
  Homebrew 安装和管理各种软件包。教程简单易懂，适合新手用户快速上手。
banner_img: https://source.icode504.com/images/软件包管理器Homwbrew安装、配置教程（适用于macOS系统）.png
index_img: https://source.icode504.com/images/软件包管理器Homwbrew安装、配置教程（适用于macOS系统）.png
category:
  - 软件安装
  - macOS
  - 软件包管理工具
date: 2024-07-21 21:26:03
password:
---


Homebrew 是一个面向 macOS 和 Linux 的包管理系统，可以轻松地安装、更新和管理软件包。它通过简单的命令行接口，让用户可以快速获取并安装各种开源软件和工具，而不需要复杂的配置过程。Homebrew 的核心理念是让用户能够轻松地管理软件环境，并保持系统的整洁和高效。它的主要优点是使用方便、社区活跃以及广泛的包支持，使其成为开发者和技术爱好者的理想选择。

以下是 macOS 环境下 Homebrew 的安装教程。本文参考自此文章：[点我查看原文章](https://zhuanlan.zhihu.com/p/111014448)

# 一、安装Homebrew

1\. 执行如下命令同意许可协议：

```bash
sudo xcodebuild -license
```

需要输入密码（默认不在命令行显示）

查看许可协议后，输入`agree`，按一下回车<kbd>Return</kbd>：

![](https://source.icode504.com/images/image-20240721001448428.png)

2\. 安装Homebrew，执行如下命令：

```bash
/bin/zsh -c "$(curl -fsSL https://gitee.com/cunkai/HomebrewCN/raw/master/Homebrew.sh)"
```

3\. 进入安装界面，输入**1**，通过清华大学下载Homebrew：

![](https://source.icode504.com/images/image-20240721001800397.png)

4\. 初次安装的小伙伴输入本机密码（默认不在命令行显示）：

![](https://source.icode504.com/images/image-20240721001856160.png)

5\. 此时会有一个检测本机是否安装Homebrew，这里输入**Y**，按一下回车<kbd>Return</kbd>：

![](https://source.icode504.com/images/image-20240721002054581.png)

6\. 等待一段时间后，出现下面的提示后，按一下回车键<kbd>Return</kbd>：

![](https://source.icode504.com/images/image-20240721002253336.png)

7\. 安装中，请耐心等待：

![](https://source.icode504.com/images/image-20240721002415491.png)

8\. 等待一段时间后，Homebrew安装完成，接下来我们需要配置国内软件下载源，这里输入**5**，使用阿里国内镜像源下载软件包，并按一下回车<kbd>Return</kbd>：

![](https://source.icode504.com/images/image-20240721002617846.png)

9\. 配置中，请耐心等待：

![](https://source.icode504.com/images/image-20240721002728440.png)

10\. 出现下面的提示后，说明Homebrew安装配置成功，重启终端：

![](https://source.icode504.com/images/image-20240721002838422.png)

# 二、卸载Homebrew（可选）

卸载Homebrew十分简单，只需要执行如下命令即可：

```bash
/bin/zsh -c "$(curl -fsSL https://gitee.com/cunkai/HomebrewCN/raw/master/HomebrewUninstall.sh)"
```

