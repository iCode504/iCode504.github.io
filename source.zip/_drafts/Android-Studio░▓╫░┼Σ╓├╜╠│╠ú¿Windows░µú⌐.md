---
title: Android Studio安装配置教程（Windows版）
tags:
  - Android
  - 安卓
  - Android Studio
category_bar: true
archive: false
abbrlink: 942332900
date: 2024-03-13 22:52:08
description:
banner_img:
index_img:
category:
password:
---


# 一、安装前检查

| 检查内容     | 操作                                                         |
| ------------ | ------------------------------------------------------------ |
| 安装JDK      | [点我查看JDK 8安装教程](https://www.icode504.com/posts/1.html) |
| 操作系统版本 | Windows 10及以上，点我检查电脑版本                           |
| 内存         | 最低8GB，建议是16GB，点我检查内存信息                        |
| 磁盘存储空间 | 最低8GB，建议是16GB，点我检查磁盘存储空间                    |
| 屏幕分辨率   | 最低1280 x 800分辨率，建议是1920 x 1080分辨率，点我检查屏幕分辨率 |

# 二、下载Android Studio安装包

1\. 点击进入官网下载页面：[点我查看](https://developer.android.google.cn/studio?hl=zh-cn)

2\. 点击下载最新稳定版安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313230720531.png)

3\. 此时会弹出一个许可协议，向下翻勾选**我已阅读并同意上述条款及条件**，然后点击下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313230829037.png)

4\. 安装包有1G左右，请耐心等待。

# 三、安装Android Studio

1\. 双击打开安装包，进入安装界面，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313231807106.png)

2\. 组件选择按照默认即可，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313231834371.png)

3\. 选择安装路径，这里我安装在了D盘，路径选择完成后，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232048610.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232222259.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232335329.png)

4\. 点击**Install**，开始安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232422547.png)

5\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232437152.png)

6\. 安装成功，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232511782.png)

7\. 安装完成，点击**Finish**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232544130.png)

# 四、配置Android Studio SDK

>   请保证电脑连接网络，因为这一部分需要下载SDK文件。
>

这里我们选择第二个**Do not import settings**（不导入配置），然后点击**OK**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232718177.png)

这里我们点击**Don't send**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232817378.png)

进入Android Studio欢迎界面，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240313232904291.png)

安装类型我们勾选第二个Custom，然后点击Next：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314151744977.png)

选择SDK安装位置，建议安装路径是全英文，这里我安装在了D盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314151947428.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314152410811.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314152506113.png)

模拟器内存按照系统设置即可，这里我设置成了2GB（你也可以点击右下角的Use recommand size自动调整推荐内存大小）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314152847502.png)

安装Android模拟器管理驱动程序，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314152917268.png)

确认所需设置，如果没有问题，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314153037975.png)

许可协议，需要挨个勾选，然后点击Finish

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314153209236.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314153252836.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314153356771.png)

下载组件中，请耐心等待（预计需要10分钟左右）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240314153431939.png)

下载完成，点击**Finish**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240315230808180.png)

# 五、创建一个Android项目

1\. 点击New Project，创建项目：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240315231042748.png)

2\. 创建一个空视图项目（如下图所示）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240315231307952.png)

3\. 

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240315231741645.png)

4\. 

