---
title: C语言介绍
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

# 一、C语言介绍

1\. 1972年，丹尼斯·里奇（*Dennis Ritch*）和肯·汤普森（*Ken Thompson*）与贝尔实验室在开发UNIX操作系统时设计了C语言。

>   这两位大佬在1983年同时获得[图灵奖](https://baike.baidu.com/item/%E5%9B%BE%E7%81%B5%E5%A5%96)（计算机最高荣誉奖，截止到2024年，国内也只有姚期智获得了此殊荣）

|                丹尼斯·里奇（*Dennis Ritch*）                 |                 肯·汤普森（*Ken Thompson*）                  |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| ![](https://icode504.oss-cn-beijing.aliyuncs.com/220px-Dennis_Ritchie_2011.jpg) | ![](https://icode504.oss-cn-beijing.aliyuncs.com/5fdf8db1cb134954092307f5fb198558d109b3dedc50.webp) |

# 二、C语言的特点

1\. 高效性：和汇编语言不同的是，C语言有很多快捷记忆的关键字，程序员可以通过人类语法编写C语言程序。并且C语言直接运行在内存上，可以获取最大的运行速度或最有效地使用内存。

2\. 可移植性：如果你在一个操作系统中编写了一个C程序文件，需要在另一个操作系统中执行这个C程序文件，可以对源文件稍作修改甚至不需要修改就可以在另一个程序上运行。

安装Linux（例如：CentOS、Ubuntu等）时，通常会安装C编译器。对于个人计算机操作系统（例如：Windows、macOS）也可以对应的C编译器运行C程序；

3\. 强大而灵活：其他语言（例如：Python、Perl）的编译器和解释器使用C语言编写的，C语言主要用于系统编程、游戏编程、嵌入式开发和网络编程等。

