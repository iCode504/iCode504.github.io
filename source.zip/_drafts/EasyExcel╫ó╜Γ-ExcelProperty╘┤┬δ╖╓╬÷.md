---
title: EasyExcel注解@ExcelProperty源码分析
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

上一节我们在实体类的属性上使用了`@ExcelProperty`，<kbd>Ctrl</kbd>+<kbd>鼠标左键</kbd>点击这个注解可以查看到源码：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240320103810437.png)

观察这个注解头上分别由三个元注解组成：`@Target(ElementType.FIELD)`、`@Retention(RetentionPolicy.RUNTIME)`、`@Inherited`

- `@Target`注解设定的范围是`ElementType.FIELD`，限定了注解`@ExcelProperty`只能标记在实体类的属性上。
- `@ExcelProperty`可以在运行过程中通过反射获取到信息，因为`@Rentention`设定的保留策略是`RetentionPolicy.RUNTIME`。
- `@Inherited`注解的作用是被它修饰的注解具有继承性（如果当前类头上添加了这个注解，那么这个类的子类也自动有该注解）。不过`@ExcelProperty`修饰在类的属性上吗，使用这个这个注解的意义是什么？

在这个注解中，一共有五个属性：value、index、order、converter、format（该属性已过时）。

- 第一个属性`value`的作用是给表格当前列起名字，由于这个属性是字符串数组类型，因此我们可以给当前列起多个名字，从而实现复杂表头操作。
- 如果没有配置`value`属性（例如，直接在类属性上直接标注`@ExcelProperty`注解；`value`对应的值是空字符串、空数组、空数组中包含一个空字符串），那么在导出Excel时，默认使用属性名作为表头的名称。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240320111040116.png)

