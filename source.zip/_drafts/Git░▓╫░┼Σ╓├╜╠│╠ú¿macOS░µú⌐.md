---
title: Git安装配置教程（macOS版）
tags: [Git, Windows]
category_bar: true
archive: false
abbrlink: 
description: macOS环境下安装版本控制工具Git
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Git安装配置教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Git安装配置教程（Windows版）.png
category: [软件安装, macOS, 版本控制工具]
password:
---

Git是一种分布式版本控制系统，用于跟踪文件和文件夹的变化，并协调多人在同一个项目中的工作。它允许开发者在不同的分支上并行开发，轻松地将更改合并到主分支中，并提供了强大的版本控制和协作功能。

以下是macOS环境下Git的安装教程。

# 一、下载Git

1\. 点击右侧链接进入Git官网下载地址：[点我查看](https://git-scm.com/downloads)

2\. 选择macOS操作系统系统安装包下载：

![](https://source.icode504.com/images/image-20240714031910036.png)

3\. 选择64位安装包下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240205161003502.png)
