---
title: Intellij IDEA创建Gradle项目时一直在官网下载Gradle安装包的解决办法
tags: [Intellij IDEA, Gradle]
category_bar: true
archive: false
abbrlink: 65
description: 解决Intellij IDEA创建Gradle项目时一直卡在官网下载Gradle安装包的办法
banner_img:
index_img:
category: [Intellij IDEA, Gradle]
password: 
---

# 一、问题复现

笔者使用的是Intellij IDEA 2021版本（以下简称IDEA），Gradle都已经在IDEA中配置好，但是每次创建Gradle项目时，IDEA都会去官网下载Gradle安装包，由于Gradle官网服务器在国外，每次下载的速度都很慢：



那么有什么办法解决每次创建项目时下载Gradle问题呢？

# 二、解决办法

