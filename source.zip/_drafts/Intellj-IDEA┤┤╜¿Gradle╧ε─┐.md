---
title: Intellj IDEA创建Groovy项目
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

# 一、使用前检查

请确保电脑中已经安装了Intellj IDEA、JDK、Groovy，没有安装小伙伴点击下方链接查看安装教程。

|               |                      Windows                       |  macOS   |  Linux   |
| :-----------: | :------------------------------------------------: | :------: | :------: |
|     JDK 8     | [点我查看](https://www.icode504.com/posts/1.html)  | 敬请期待 | 点我查看 |
|    Groovy     | [点我查看](https://www.icode504.com/posts/34.html) | 敬请期待 | 敬请期待 |
| Intellij IDEA | [点我查看](https://www.icode504.com/posts/10.html) | 敬请期待 |   暂无   |

# 二、使用Intellij IDEA创建Groovy项目

1\. 打开Intellij IDEA，点击左上角**File**，再点击**New**，然后点击**Project**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240411161738044.png)

2\. 在左侧选择**Groovy**项目，然后点击**Create**创建Groovy库：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240411162128352.png)

3\. 找到本地Groovy的安装路径并选中，然后点击**OK**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240411173113359.png)

4\. Groovy库成功添加，完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240411173347871.png)

5\. 填写项目名称，选择项目所在路径（建议只包含英文字符），然后点击**Finish**完成创建：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240411173833117.png)

# 三、创建一个Groovy文件并运行

1\. 鼠标右键点击左侧`src`目录下创建一个Groovy文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240412110704291.png)

2\. 自定义Groovy文件名，命名须符合[标识符命名规范](https://www.icode504.com/posts/3.html#%E6%A0%87%E8%AF%86%E7%AC%A6)：



3\. 编写一段测试代码，大家可以直接复制到自己的IDEA中：

```groovy
println("你好，我是iCode504，程序猿一枚，请多指教！")
def num1 = 20
def num2 = 30
println("num1 + num2 = " + (num1 + num2))

class Person {
    def name;
    def age;

    Person(name, age) {
        this.name = name
        this.age = age
    }

    void showMessage() {
        println("姓名: " + this.name)
        println("年龄: " + this.age)
    }
}

def person = new Person("iCode504", 23)
person.showMessage()
```

4\. 鼠标右键点击`Run xxx`（或者按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>F10</kbd>）运行上述Groovy程序：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240412111753247.png)

5\. 此时控制台输出了源代码中输出语句中的相关内容：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240412112213471.png)
