---
title: Maven安装和配置教程（macOS版）
tags: [Maven, Windows]
category_bar: true
archive: false
abbrlink:
description: Maven是一款项目管理和构建工具，适用于Java开发。本教程提供macOS环境下的Maven安装和配置方法，包括下载和安装Maven，配置环境变量和镜像仓库设置。
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Maven安装与配置教程（Windows版）-封面.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Maven安装与配置教程（Windows版）-封面.png
category:
  - 软件安装
  - Windows
  - 项目构建工具
password:
---

# 一、安装前检查

1\. 检查电脑上是否安装JDK，如果没有安装，请查看JDK安装教程：[点我查看](https://www.icode504.com/posts/78.html)

2\. 如果你已经安装了JDK，打开终端，输入`java -version`，按一下回车，查看JDK安装信息，如果有下面提示信息，说明JDK安装成功

![](https://source.icode504.com/images/image-20240714133339950.png)

# 二、下载Maven

以下两种方式二选一：

方式一：网盘下载（强烈推荐，下载速度较快！）

打开此链接：[点击下载，密码:1024]()，选择任意一个文件下载即可，这里我选择的是3.6.3版本的：

方式二：官网下载（不推荐，曾经同事和我吐槽由于官网是国外的，下载速度非常慢）

1\. 点击进入官网下载链接：[点击进入](https://archive.apache.org/dist/maven/maven-3/)，会出现如下界面

![](https://source.icode504.com/images/image-20240714232914206.png)

2\. 选择一个，点击进入，这里我以3.6.3版本的为例，按下图所示操作即可：

![](https://source.icode504.com/images/image-20240714233055613.png)

>   说明：source目录下的文件是Maven的源码文件，如果有查看的源码的小伙伴，也可以点击进入下载，这里就不过多赘述了。

3\. 使用macOS的小伙伴，点击`.tar.gz`文件下载（如下图）：

![](https://source.icode504.com/images/image-20240714233304292.png)

# 三、配置Maven

1\. 将下载下来的压缩包**解压到一个你知道的文件夹下**，为了避免后续可能出现问题，解压目录只包含英文字符的目录，