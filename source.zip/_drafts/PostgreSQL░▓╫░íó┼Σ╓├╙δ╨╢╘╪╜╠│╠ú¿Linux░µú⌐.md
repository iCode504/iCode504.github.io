---
title: PostgreSQL安装、配置与卸载教程（Linux版）
tags: [PostgreSQL, Linux]
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category: [软件安装]
password:
---

PostgreSQL是基于[POSTGRES 4.2](https://dsf.berkeley.edu/postgres.html)版本的对象-关系型数据库，由加州大学伯克利分校计算机系研发。POSTGRES开创了许多先进理念，这些概念后来才在一些数据库系统中出现（他们的[官网](https://www.postgresql.org/)标题宣传的是世界上最先进的开源关系型数据库）。

PostgreSQL是原伯克利代码的后代，它是开源的，支持大部分SQL标准并提供很多现代化特性：复杂查询、外键、触发器、更新视图等。

此外，用户能以多种方式扩展PostgreSQL，例如可以添加新数据类型、新函数、新操作符等。由于自由的许可，PostgreSQL可以被任何人使用、修改、发布。

以下是Linux环境下PostgreSQL的安装、配置与卸载教程：

# 一、安装前操作

1\. 安装gcc：

```bash
yum -y install gcc g++ libicu-devel
```

```bash
apt-get -y install gcc g++ zlib
```

# 二、下载PostgreSQL安装包

1\. 切换到`/usr/local`目录下，执行如下命令

```bash
cd /usr/local
```

2\. 根据前面选择的PostgreSQL的版本下载，使用`wget`命令下载：

```bash
wget https://mirrors.tuna.tsinghua.edu.cn/postgresql/source/v16.3/postgresql-16.3.tar.gz
```

3\. 下载完成后，执行`ls`命令，出现PostgreSQL安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240516143841974.png)

# 三、安装PostgreSQL

1\. 将下载好的安装解压，执行如下命令：

```bash
tar zxvf postgresql-16.3.tar.gz
```

2\. 进入解压后的文件夹，执行如下命令：

```bash
cd postgresql-16.3
```

3\. 检查

```bash
./configure
```

4\. 

```bash
make
```

