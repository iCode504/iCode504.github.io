SDKMAN!，全称The Software Development Kit Manager，中文翻译过来就是**软件开发工具包管理器**。以下是官网对这款工具的介绍（个人翻译）：

认识一下SDKMAN!——你的可靠伙伴，它可以高效管理Unix系统上众多的软件开发工具包。假设您的系统上存在不同版本的软件开发工具包（SDKs），需要以一种无压力的方式在他们之间切换，SDKMAN!以简单易用的命令行界面（CLI）和API能介入上述过程。以前称作GVM，Groovy enVironment Managener（Groovy环境管理器），SDKMAN!从类似工具apt、pip、RVM、rbenv甚至是Git上获取灵感。将其视为您的一个乐于助人的朋友，随时为您准备简化SDK管理。

- 源于开发者，为开发人员着想。简化SDK生命周期，不需要再寻找下载源，提取归档或添加修改`_HOME`和`PATH`等环境变量。
- 一站式直接搞定所有和Java相关工具下载安装。可以安装基于JVM的软件开发工具包，例如：Java、Scala、Kotlin和Groovy。Ant、Gradle、Grails、Maven、SBT、Spark、Spring Boot、Vert.x和其他框架工具也支持。
- 轻量级。SDKMAN!使用Rust和bash编写，并且系统上只需要有`curl`、`zip`和`unzip`三个依赖即可。甚至可以和ZSH一起工作。
- 多平台。跨各种基于UNIX平台无缝操作，包括**macOS、Linux、Windows下的Linux子系统**（WSL）。
- APIs。通过使用我们的开放的Broker API，可以轻松编写新的客户端。软件提供者可以通过安全的Vendor API来发布和声明自己的软件版本。
- 开源。SDKMAN!的研发离不开开源社区成员们的努力。Apache 2.0下的协议。

接下来就为大家介绍一下这款软件在macOS、Linux环境下安装和简单使用。

# 一、安装SDKMAN!

安装SDKMAN!非常简单，只需要在命令行（macOS请打开终端执行命令）界面运行几行代码就OK了。

1\. 请先确保电脑本机上已经安装了`curl`、`zip`、`unzip`、`axel`

- CentOS：

```shell
yum -y install curl zip unzip
```

- Ubantu/Debian：

```shell
apt -y install curl zip unzip axel
```

2\. 打开命令行窗口，在命令行中输入如下命令并执行：

```shell
curl -s "https://get.sdkman.io" | bash
```

因为这款软件是下载源在国外，下载速度较慢，请耐心等待！

3\. 出现下面提示即说明SDKMAN!安装成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227153819937.png)

如果安装失败，执行如下命令删除残留文件重新执行上一步命令：

```bash
rm -rf ./sdkman
```

4\. 我们在命令行再执行如下命令，方便后续我们使用SDKMAN!相关的命令：

```shell
source "$HOME/.sdkman/bin/sdkman-init.sh"
```

5\. 此时在命令行输入如下命令，就可以看到SDKMAN!的版本信息：

```shell
sdk version
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227154230369.png)

# 二、SDKMAN!的使用演示

这里我使用SDKMAN!来演示Maven的安装，感兴趣的小伙伴也可以试一试。

## 2.1 在线安装JDK

1\. 要想安装JDK 8，可以使用如下命令，查看当前所有的JDK的版本：

```bash
sdk list java
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227155427149.png)

按向下键可以查看更多厂商提供的JDK版本，按<kbd>Q</kbd>键即可退出查看。

2\. 这里我选择最后一个Zulu JDK，这也是一款优秀的JDK发布版，我们需要关注一下后面的版本号`8.0.392-zulu`：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227155749634.png)

3\. 使用如下命令安装对应厂商的JDK：

```bash
sdk install java x.y.z-厂商名
```

这里我安装的是Zulu JDK 8.0.392，可以使用下面的命令：

```bash
sdk install java 8.0.392-zulu
```

安装成功界面如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227160651934.png)

4\. 使用`java -version`命令发现我们成功安装Zulu JDK。运行`javac`和`java`也可以正常使用：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227160848203.png)

## 2.2 离线安装Maven

1\. 在安装Maven之前，我们先查看以下SDKMAN!给我们提供了那些版本的Maven供我们下载：

```shell
sdk list maven
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227161101273.png)

这里我选择3.6.3版本的Maven进行下载。但是由于Maven官网服务器在国外，下载速度很慢，如果使用SDKMAN!直接执行如下命令很有可能会由于网络原因下载失败：

```shell
sdk install maven 3.6.3
```

当然，我们可以自己去下载好Maven安装包并解压，其他的安装和环境配置过程交给SDKMAN!来完成。

2\. 执行如下命令多线程下载Maven 3.6.3版本的安装包：

```bash
axel -n 64 https://archive.apache.org/dist/maven/maven-3/3.6.3/binaries/apache-maven-3.6.3-bin.tar.gz
```

> 这里说明一下，axel是一款Linux端下载工具，它利用多线程下载的方式提高下载速度。

3\. 将当前下载好的安装包解压：

```bash
tar -zxvf apache-maven-3.6.3-bin.tar.gz
```

4\. 切换到Maven解压目录，直到执行`ls`命令可以看到`bin`、`conf`等文件夹：

```bash
cd apache-maven-3.6.3/
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240417105743075.png)

5\. 执行如下命令查看当前所在路径，并复制这个路径：

```bash
pwd
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240417105852039.png)

6\. 使用如下命令将解压的内容交由SDKMAN!来安装：

```bash
sdk install 软件名 版本号 当前文件所在路径
```

这里我们安装的是`maven 3.6.3`版本，路径我们也在上一步复制，因此执行如下命令：

```bash
sdk install maven 3.6.3-RELEASE /root/apache-maven-3.6.3
```

![image-20240417110334658](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240417110334658.png)

安装成功后界面：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227161423016.png)

9\. 此时我们使用`mvn -v`即可查看当前我们安装的Maven版本信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227161641067.png)

10\. 如果我们不需要Maven和JDK了，可以用以下两行命令就可以将上述两款工具卸载：

```shell
sdk uninstall maven 3.6.3 --force
sdk uninstall java 8.0.392-zulu --force
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231227163028768.png)

# 三、卸载SDKMAN!

卸载SDKMAN!也非常简单！只需要几步就可以完成：

1\. （可选）如果后续还想使用SDKMAN!，可以对当前`./sdkman`目录打包成tar文件：

```shell
tar zcvf ~/sdkman-backup_$(date +%F-%kh%M).tar.gz -C ~/ .sdkman
```

2\. 使用`rm -rf`命令强制删除：

```shell
rm -rf ~/.sdkman
```
