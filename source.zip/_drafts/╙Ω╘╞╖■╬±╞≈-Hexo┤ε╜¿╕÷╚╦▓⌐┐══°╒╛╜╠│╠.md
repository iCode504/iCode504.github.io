---
abbrlink: iCode504
archive: false
banner_img: null
categories: []
category: null
category_bar: true
date: ''
description: null
index_img: null
password: null
tags:
- 雨云
- 个人网站
- Hexo
title: 雨云服务器+Hexo搭建个人博客网站教程
updated: '2024-07-13T17:54:04.963+08:00'
---
# 一、准备工作

以下表格中所需要的内容是本文所使用到的软件

| 准备内容                                      | 教程                                            | 说明                                                                                                         |
| --------------------------------------------- | ----------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| 服务器                                        |                                                 | 本文使用的是 Linux CentOS 系统，如何购买、启动和简单使用服务器本文后面会讲到                                 |
| Git（Windows 版）                             | [点我查看](https://www.icode504.com/posts/69.html) |                                                                                                              |
| Git（Linux 版）                               | [点我查看](https://www.icode504.com/posts/72.html) | 本文使用的是 CentOS 版的 Git                                                                                 |
| Electerm（Windows 版）                        | [点我查看](https://www.icode504.com/posts/47.html) |                                                                                                              |
| Node.js（Windows 版）                         | [点我查看](https://www.icode504.com/posts/67.html) |                                                                                                              |
| Github 加速访问工具 Watt tookit（原 Steam++） | [点我查看](https://www.icode504.com/posts/25.html) | 我们后续会在 Github 拉取代码，但是 Github 服务器在国外，国内下载速度比较慢，使用这款工具可以访问 Github 页面 |
| 微信/支付宝                                   |                                                 | 准备 1 元，用于购买一天的服务器用于简单测试，如果你觉得使用 OK，再按月/季度/半年购买服务器                   |

# 二、注册登录账号

## 2.1 注册登录账号

1\. 点击右侧连接进入雨云服务器官网：[点我查看]()，点击左上角的 **登录/注册**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240604231303392.png)

2\. 进入登录/注册页面（背景居然是可爱的二次元小姐姐！），初次使用的小伙伴需要注册（已经有账号的小伙伴请直接登录即可）

> 官方支持 QQ 和微信扫码登录/注册，其中微信扫码后需要关注雨云微信公众号方可完成登录/注册操作。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240604232210654.png)

3\. 在注册页面填写手机号或邮箱，输入两次密码，点击确定完成注册。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240604232549693.png)

4\. 此时会弹出一个图片验证码，验证后注册成功，进入登录页面输入自己的账号密码直接登录即可：

> 如果你记不住密码，建议将页面的 **7 天内免登录** 勾选上。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240604232843338.png)

## 2.2 完善个人信息

这一部分内容中某个步骤前面标记了“可选”的意思

1\. 初次登录的小伙伴，会看到工作台页面，鼠标点击右上角的头像，点击倒数第二个 **账户设置**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240604233320481.png)

2\. 我们可以通过左侧的菜单栏完善个人信息：

> 绑定邮箱和手机
>
> 在雨云上购买商品（例如云服务器），需要绑定支付宝账号（下图第 5 个菜单）和微信。使用支付宝 APP 扫码验证。
>
> 购买并使用国内的服务器，需要实名认证（下图第 6 个菜单）。填写完成后需要使用支付宝 APP 扫码验证。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605145152498.png)

## 2.3 账户充值

1\. 初次使用雨云的小伙伴，点击上方的费用中心，再进入充值中心，使用支付宝充值：

> 雨云官方购买服务器，每周可以享受一次 1 元使用一天服务器，这里我充值 1 元为大家演示。
>
> 如果大家在使用过程中比较满意，可以按月/季度/半年/年购买，买的时间越长越优惠！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605151634285.png)

2\. 在充值页面，输入你要充值金额，然后点击立即充值，使用支付宝 APP 扫码支付：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605152200279.png)

3\. （没有下图窗口的小伙伴请跳转到下一步）支付完成后，如果弹出此窗口，直接 **点击我已完成支付** 即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605152457129.png)

4\. 支付完成，此时余额有 1 元，接下来我们就可以购买服务器了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605152624192.png)

# 三、购买云服务器

接下来，我们就来购买一台云服务器使用：

1\. 点击左上角 **云产品**，找到 **云服务器**，点击 **立即购买**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605153047499.png)

2\. 以下是我选择的服务器配置信息：

- 服务器所在地域我选择的是江苏宿迁（国内）

> 选择国内的服务器是为了后续给大家演示域名备案相关的操作，如果你不需要备案的话，可以购买中国香港和美国的服务器，它们都是免备案的。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605154059519.png)

- 配置我选择的是 Xeon Gold（因为 Xeon E5v2 和 Xeon E5v3 配置的服务器卖没了呜呜呜~）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605154336640.png)

- 套餐是 KVM 入门版（初次使用的小伙伴建议选择低配置即可，当然高配置的使用体验更好，但是更贵）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605154534406.png)

- 这里操作系统我选择 CentOS 系统（7.9版本），下面的预安装 APP 根据自己的实际需要进行选择（这里我选择了宝塔面板，后续会用到）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627232911387.png)

- 公网 IP 按照系统默认勾选即可（如果你选择了第二个带高防的独立ip，价格会变得非常贵）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605155302379.png)

3\. 上面的配置完成后，点击**试用**（如果后续试用过程中比较满意，直接点击**立即购买**即可）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605155425727.png)

4\. 点击 **立即试用**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605155507275.png)

5\. 购买成功，服务器需要初始化，请耐心等待几分钟，如果右上角出现运行中，说明服务器创建成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627233310404.png)

# 四、远程连接服务器

1\. 点击服务器右上角的 **管理**，进入服务器管理界面：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605161302704.png)

2\. 进入服务器配置界面，我们可以查看到服务器相关信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627233359287.png)

3\. 打开 Electerm，点击左侧的书签，进入远程连接界面：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605162010307.png)

4\. 点击 **复制** 远程连接地址：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627233643532.png)

5\. 将冒号前面的内容粘贴到主机地址，冒号后面的内容粘贴到端口号中（如下图）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627233835004.png)

> （未购买独立IP的小伙伴可以跳过此部分内容）如果你购买的是独立的IP，那么填写形式如下：
>
> ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627233909739.png)

6\. 进入服务器配置界面，复制下方的密码：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627233953162.png)

7\. 按照下图所示操作，填写用户名（填写 root 即可）和密码（上一步复制的）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627234138936.png)

8\. 翻到页面的最下方，点击测试连接，如果上方弹出 connection ok，就说明上述配置没有问题：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605163033413.png)

9\. 如果上一步测试连接成功，点击 **保存并连接**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240605163144121.png)

10\. root 用户登录成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240627234220747.png)

# 五、安装宝塔面板

接下来我们来安装宝塔面板：

# 六、使用宝塔面板安装应用

用户名和密码修改完成后，我们就可以访问宝塔面板了

进入登录页以后，用户名输入修改过的用户名，密码使用前面我们更改过的密码，完成后点击 **登录**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240606103443677.png)

初次访问宝塔面板的小伙伴需要用手机号绑定宝塔账号，没有账号的小伙伴点击右下角的免费注册，注册完成的小伙伴直接按照下图所示操作即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240606103734518.png)

# 六、购买域名

# 七、域名备案（购买国内的服务器必看）
