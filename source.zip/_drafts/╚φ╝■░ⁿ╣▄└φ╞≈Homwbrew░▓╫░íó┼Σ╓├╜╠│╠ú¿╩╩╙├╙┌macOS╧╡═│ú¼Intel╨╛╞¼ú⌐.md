---
title: 软件包管理器Homwbrew安装、配置教程（适用于macOS系统，Intel芯片）
tags: []
category_bar: true
archive: false
abbrlink:
description:
banner_img:
index_img:
category:
password:
---

# 一、安装前操作

1\. 打开终端，在命令行执行如下命令安装CLT for XCode：

```bash
xcode-select --install
```

![](https://source.icode504.com/images/image-20240714101111316.png)

2\. 在终端中依次执行如下命令设置环境变量：

```bash
export HOMEBREW_INSTALL_FROM_API=1
export HOMEBREW_API_DOMAIN="https://mirrors.tuna.tsinghua.edu.cn/homebrew-bottles/api"
export HOMEBREW_BOTTLE_DOMAIN="https://mirrors.tuna.tsinghua.edu.cn/homebrew-bottles"
export HOMEBREW_BREW_GIT_REMOTE="https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/brew.git"
export HOMEBREW_CORE_GIT_REMOTE="https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/homebrew-core.git"
```

![](https://source.icode504.com/images/image-20240714102258538.png)

3\. 执行如下命令同意XCode许可协议：

```bash
sudo xcodebuild -license
```

此时系统要求输入本机用户密码（密码默认不在终端显示），完成后按一下回车。

出现下图提示时，按一下回车键，查看许可协议：

![](https://source.icode504.com/images/image-20240714103339390.png)

按空格键查看更多内容。如果出现下图内容提示，请输入`agree`同意许可协议：

![](https://source.icode504.com/images/image-20240714103047096.png)

3\. 执行如下命令，试用Git将远程代码克隆到本地（macOS系统自带Git，不需要额外安装）：

```bash
git clone --depth=1 https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/install.git brew-install
```

代码成功克隆到本地：

![](https://source.icode504.com/images/image-20240714103614890.png)

4\. 执行如下命令安装Homebrew：

```bash
/bin/bash brew-install/install.sh
rm -rf brew-install
```

执行此命令时，首先需要输入本机密码（密码不在终端显示），出现**Press RETURN/ENTER to continue or any other key to abort**提示时，按一下回车键：

![](https://source.icode504.com/images/image-20240714104139475.png)

安装过程较长，请耐心等待（或者刷个视频\^_\^）