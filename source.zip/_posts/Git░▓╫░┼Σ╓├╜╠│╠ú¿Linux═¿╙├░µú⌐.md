---
title: Git安装配置教程（Linux通用版）
tags:
  - Git
  - Linux
  - CentOS
  - Ubuntu
  - Debian
category_bar: true
archive: false
abbrlink: 72
description: Linux环境（包含CentOS/Ubuntu/Debian）下安装Git
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Git安装配置教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Git安装配置教程（Windows版）.png
category:
  - 软件安装
  - Linux
  - 版本控制工具
date: 2024-05-31 11:04:27
password:
---


Git是一种分布式版本控制系统，用于跟踪文件和文件夹的变化，并协调多人在同一个项目中的工作。它允许开发者在不同的分支上并行开发，轻松地将更改合并到主分支中，并提供了强大的版本控制和协作功能。

以下是Linux环境下Git的安装教程。

有需要在虚拟机安装Linux系统的小伙伴，请点击下方任意一个链接查看安装配置教程：

|          |                       CentOS                       |                       Ubuntu                       |                       Debian                       |
| :------: | :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: |
| 安装教程 | [点我查看](https://www.icode504.com/posts/48.html) | [点我查看](https://www.icode504.com/posts/51.html) | [点我查看](https://www.icode504.com/posts/52.html) |

# 一、安装前检查

执行如下命令查看当前Linux发行版本信息：

```bash
uname -a
```

这里我使用的Debian操作系统：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240430090546557.png)

# 二、安装Git

1\. 请根据当前操作系统，执行如下命令安装Git：

- Ubuntu/Debian

```bash
apt -y install git
```

- CentOS

```bash
yum -y install git
```

2\. 安装完成后，执行如下命令查看当前Git的版本信息：

```bash
git --version
```

如果出现下图版本信息提示说明Git安装成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240430085355974.png)

# 三、卸载Git（可选）

根据自己的操作系统，执行如下命令卸载Git：

- Ubuntu/Debian

```bash
apt -y remove git
```

- CentOS

```bash
yum -y uninstall git
```

