---
title: Gradle安装配置教程（Linux通用版）
tags:
  - Linux
  - Gradle
category_bar: true
archive: false
abbrlink: 57
description: >-
  本文详细介绍了在Linux系统上安装和配置Gradle的步骤。通过本教程，用户可以轻松掌握Gradle在Linux端的安装配置方法，完成下载源的配置，为后续的项目构建和管理提供便利。
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Gradle安装配置教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Gradle安装配置教程（Windows版）.png
category:
  - 软件安装
  - Linux
date: 2024-03-10 22:42:40
password:
---

有需要安装Linux系统的小伙伴，可以点击下面任意一个链接查看安装教程：

|          |                       CentOS                       |                       Ubuntu                       |                       Debian                       |
| :------: | :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: |
| 安装教程 | [点我查看](https://www.icode504.com/posts/48.html) | [点我查看](https://www.icode504.com/posts/51.html) | [点我查看](https://www.icode504.com/posts/52.html) |

# 一、安装前检查（Linux端）

1\. 检查电脑上是否安装JDK，如果没有安装，请查看JDK安装教程：[点我查看](https://www.icode504.com/posts/55.html)

2\. 已经安装JDK的小伙伴，请在命令行执行如下命令，如果出现下图的版本信息，就说明JDK环境变量配置成功：

```bash
java -version
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240225121013682.png)

3\. 检查Ubuntu发行版本信息，执行如下命令：

```bash
uname -a
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310222707920.png)

# 二、下载Gradle安装包（Windows端）

1\. 点击右侧链接打开官网页面：[https://gradle.org/releases/](https://gradle.org/releases/)

>   如果你使用的SpringBoot项目，建议使用6.8及以上的版本。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240307110337332.png)

2\. 这里我选择8.0.2版本下载。点击**complete**下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240307110441377.png)

# 三、安装并配置Gradle环境变量

1\. 将前面下载好的Gradle安装包使用SFTP工具（这里我使用的是Eleterm）由Windows端传输到Linux端（请先确保Windows本身已经通过SSH方式连接到Linux）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224172925751.png)

2\. 在左侧Windows端找到下载好的安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310214142976.png)

3\. 在右侧Linux端设置安装包存放路径，这里我将安装包存放在`/opt`下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224173503187.png)

4\. 按照下图所示操作，将Maven安装包传到Linux端的`/opt`目录下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/24010310001.gif)

5\. 等待一段时间后，此时Linux端的`/opt`目录下已经存放了刚才我们传输的文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310214339373.png)

6\. 此时我们切换回命令行，执行如下命令切换到`/opt`目录下：

```bash
cd /opt
```

7\. 在Linux端下载安装unzip（解压缩工具）：

-   Ubuntu/Debian

```bash
sudo apt -y install unzip
```

-   CentOS

```bash
sudo yum -y install unzip
```

7\. 解压刚刚传输过来的安装包，执行如下命令：

>   小技巧：在命令行中输入文件名时，我们可以只写文件的前一部分，然后按一下<kbd>Tab</kbd>键补齐文件名。

```bash
unzip gradle-8.0.2-all.zip
```

8\. 等待一段时间后，解压完成，执行如下命令，进入解压后的文件夹名称：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310214538214.png)

使用`cd`命令进入解压后的文件夹：

```bash
cd gradle-8.0.2
```

9\. 安装vim编辑器，根据自己的操作系统执行如下命令来安装：

-   CentOS

```bash
sudo yum -y install vim
```

-   Ubuntu/Debian

```bash
sudo apt -y install vim
```

10\. 在`/etc/profile.d`目录下创建`gradle_env.sh`文件，执行如下命令：

```shell
vim /etc/profile.d/gradle_env.sh
```

11\. 复制如下代码

```shell
#GRADLE_HOME  
GRADLE_HOME=
PATH=$PATH:$GRADLE_HOME/bin
export PATH GRADLE_HOME
```

12\. 按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴第十步的代码，效果如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310220804783.png)

13\. 完成后按一下<kbd>Esc</kbd>键，然后输入`:wq`保存并退出。

14\. 输入如下命令，查看当前文件路径，选中这个路径并复制：

```bash
pwd
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310220307085.png)

15\. 再次打开`gradle_env.sh`文件：

```bash
vim /etc/profile.d/gradle_env.sh
```

16\. 将光标移动到第2行，按<kbd>i</kbd>进入编辑模式，将`GRADLE_HOME`对应的值替换成第14步复制的路径，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴，最终效果如下图：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310220723840.png)

17\. 完成后按一下<kbd>Esc</kbd>键，然后输入`:wq`保存并退出。

18\. 执行如下命令，让环境变量配置生效：

```bash
source /etc/profile.d/gradle_env.sh
```

19\. 执行如下命令可以查看Gradle版本，如果出现如下提示信息，说明Gradle环境变量配置成功：

```bash
gradle -v
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310221119015.png)

# 四、配置Gradle下载源

由于Gradle自带Maven下载源是国外的，在后续下载依赖的过程中会比较慢。这里我们需要将下载源换成国内镜像。

1\. 找一个你熟悉的位置存放Gradle依赖，这里我创建一个目录专门存放Gradle依赖：

```bash
mkdir -p /home/gradle/repository
```

2\. 进入Gradle安装目录，执行如下命令：

```bash
cd /opt/gradle-8.0.2
```

3\. 执行如下命令，查看当前目录下的所有文件和文件夹：

```bash
ls
```

4\. 执行如下命令，查看当前目录下的所有文件和文件夹：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310221640106.png)

5\. 进入`init.d`文件夹，执行如下命令：

```bash
cd init.d/
```

6\. 执行`ls`命令，我们发现这个目录下有一个`readme.txt`文件。执行`cat readme.txt`命令可以查看文件内容：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310221945889.png)

```text
You can add .gradle (e.g. test.gradle) init scripts to this directory. Each one is executed at the start of the build.
```

简单翻译一下就是在`init.d`目录下创建一个初始化文件，这里我们需要新建一个`init.gradle`文件。

3\. 新建一个`init.gradle`文件，执行如下命令：

```bash
vim init.gradle
```

4\. 复制如下代码：

```bash
allprojects {
    repositories { 
        mavenLocal() 
        maven { name "Alibaba" ; url "https://maven.aliyun.com/repository/public" } 
        maven { name "Bstek" ; url "https://nexus.bsdn.org/content/groups/public/" } 
        mavenCentral()
    }
    buildscript {
        repositories { 
            maven { name "Alibaba" ; url 'https://maven.aliyun.com/repository/public' } 
            maven { name "Bstek" ; url 'https://nexus.bsdn.org/content/groups/public/' } 
            maven { name "M2" ; url 'https://plugins.gradle.org/m2/' }
        }
    }
}
```

5\. 按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴第十步的代码，效果如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240310222300304.png)

6\. 完成后按一下<kbd>Esc</kbd>键，然后输入`:wq`保存并退出。至此，Gradle下载源配置完成。
