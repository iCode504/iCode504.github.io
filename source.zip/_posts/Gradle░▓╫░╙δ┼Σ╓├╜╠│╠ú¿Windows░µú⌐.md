---
title: Gradle安装与配置教程（Windows版）
date: 2023-12-11 11:55:00
tags: [Gradle, Windows]
description: 本教程介绍Windows下安装配置Gradle的方法，包括下载、安装、配置环境变量等步骤。
category: 
  - 软件安装
  - Windows
  - 项目构建工具
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Gradle安装配置教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Gradle安装配置教程（Windows版）.png
abbrlink: 20 
---

# 一、安装前检查

1\. 检查电脑上是否安装JDK，如果没有安装，请点击下方**任意一个**链接查看安装教程（这里我使用的是JDK 8）。

| [JDK 8安装教程](https://www.icode504.com/posts/1.html) | [JDK 11安装教程](https://www.icode504.com/posts/28.html) | [JDK 17安装教程](https://www.icode504.com/posts/26.html) | [JDK 21安装教程](https://www.icode504.com/posts/27.html) |
| :----------------------------------------------------: | :------------------------------------------------------: | :------------------------------------------------------: | :------------------------------------------------------: |

2\. 如果电脑上已经安装JDK，按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，然后点击**确定**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502204142586.png)

3\. 输入`java -version`，按一下回车键，查看JDK安装信息，如果有下面提示信息，说明JDK安装成功：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502204421939.png)

# 二、Gradle下载

>   如果你使用的SpringBoot项目，建议使用6.8及以上版本的Gradle。

以下两种下载方式任选其一：

## 方式一：百度网盘下载

请点击下方任意一个链接，进入下载页面：

| [点击下载](https://pan.baidu.com/s/1Nc0-DKvcxBylkSLV99LtPA?pwd=1024) | [备用下载1](https://pan.baidu.com/s/1P8IYEwPfooZea2VdsDq5fg?pwd=1024) | [备用下载2](https://pan.baidu.com/s/1FjpGp7ijBCwMeyPqJdmYuA?pwd=1024) |
| :----------------------------------------------------------: | :----------------------------------------------------------: | :----------------------------------------------------------: |

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240311121145684.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240311121311976.png)

## 方式二：官网下载

1\. 打开官网下载界面：https://gradle.org/releases/

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502205326073.png)

2\. 这里我选择8.0.2版本下载。点击`complete`下载

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502205503786.png)

# 三、Gradle配置环境变量

1\. 将下载的压缩包进行解压，**建议解压目录只包含英文路径**，这里我解压到了E盘：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502210254031.png)

2\. 双击打开`gradle-8.0.2`目录，鼠标右键复制路径：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502210539866.png)

3\. 在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502210816983.png)

4\. 点击**高级系统设置**：

|   Windows 11   | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101010932039.png) |
| :------------: | ------------------------------------------------------------ |
| **Windows 10** | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101011132186.png) |

5\. 点击**环境变量**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502211011177.png)

6\. 在下方系统变量点击**新建**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502211128115.png)

7\. 如下图，变量名输入`GRADLE_HOME`，变量值是前面第2步复制的路径粘贴即可，完成后点击**确定**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502211311867.png)

8\. 在系统变量中**双击打开Path**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502211541532.png)

9\. 在右上角点击**新建**，输入`%GRADLE_HOME%\bin`，完成后**一路点击确定**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502211824581.png)

10\. 验证Gradle是否安装成功：按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`打开命令提示行。输入`gradle -v`，如果有下面的版本说明Gradle环境变量配置成功：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502212143948.png)

# 四、配置下载源

由于Gradle自带Maven下载源是国外的，在后续下载依赖的过程中会比较慢。这里我们需要将下载源换成国内镜像。

1\. 需要保证能看到文件的后缀名：在文件夹上方点击**查看**，在右侧勾选**文件扩展名**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502213529133.png)

2\. 打开Gradle目录，进入init.d文件夹，会发现里面有一个`readme.txt`文件，打开后会有如下信息

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502212534100.png)

```
You can add .gradle (e.g. test.gradle) init scripts to this directory. Each one is executed at the start of the build.
```

简单翻译一下就是需要在init.d目录下配置一个初始文件，这里我们需要新建一个`init.gradle`文件。

3\. 鼠标右键新建并打开init.txt文件，将下面的内容粘贴到文件中，然后点击`保存`

```groovy
allprojects {
    repositories { 
        mavenLocal() 
        maven { name "Alibaba" ; url "https://maven.aliyun.com/repository/public" } 
        maven { name "Bstek" ; url "https://nexus.bsdn.org/content/groups/public/" } 
        mavenCentral()
    }
    buildscript {
        repositories { 
            maven { name "Alibaba" ; url 'https://maven.aliyun.com/repository/public' } 
            maven { name "Bstek" ; url 'https://nexus.bsdn.org/content/groups/public/' } 
            maven { name "M2" ; url 'https://plugins.gradle.org/m2/' }
        }
    }
}
```

4\. 将文件命名为`init.gradle`，对下面弹窗提示点击确定。至此，Gradle下载源配置成功：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502213047150.png)

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502213101741.png)

# 五、Intellij IDEA创建Gradle项目

>   需要安装Intellij IDEA的小伙伴点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/10.html)

1\. 新建Gradle项目或模块：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502214558267.png)

2\. 创建完成后，按`Ctrl + Alt + S`打开设置，找到Gradle并按下图设置

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502233947436.png)

3\. 使用JUnit4进行测试：在IDEA左侧目录打开`build.gradle`文件，在`dependencies`中添加一条依赖：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502234132500.png)

```groovy
dependencies {
	testImplementation 'junit:junit:4.12'
}
```

4\. 在src目录下，创建`test\java`目录：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502234439914.png)

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230502234512693.png)

5\. 创建一个测试类MyTest01

```java
import org.junit.Test;

/**
 * @author iCode504
 * @className MyTest01
 * @time 2023/5/2 23:45
 * @description TODO
 */
public class MyTest01 {

    @Test
    public void test() throws Exception {
        System.out.println("Hello, world");
    }
}
```

6\. 点击运行，即可看到控制台输出内容：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503000018947.png)

# 六、Eclipse创建Gradle项目

>   需要安装Eclipse的小伙伴点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/30.html)

1\. 在Eclipse上方打开`Windows --> Preferences`，按照下图所示配置。

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503001217049.png)

2\. 重启Eclipse，新建一个Gradle项目：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503001422253.png)

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503001512591.png)

3\. 进入到欢迎页后，取消勾选，点击**Next**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503001638406.png)

4\. 自定义项目名称，然后点击**Next**：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503001843790.png)

5\. 点击**Finish**，Gradle项目创建完成：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503002819037.png)

6\. 在左侧目录打开`lib --> build.gradle`文件，导入如下依赖：

```groovy
dependencies {
	testImplementation 'junit:junit:4.12'
}
```

7\. 在`src\test\java`目录下创建一个Java文件：

```java
package com.icode504;

import org.junit.Test;

public class MyTest02 {
	
	@Test
	public void testName() throws Exception {
		System.out.println("Hello, world");
	}
}
```

8\. 双击方法名，鼠标右键点击运行，即可看到控制台输出：

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503003314114.png)

![](https://mypicture0706.oss-cn-beijing.aliyuncs.com/image-20230503003356473.png)

