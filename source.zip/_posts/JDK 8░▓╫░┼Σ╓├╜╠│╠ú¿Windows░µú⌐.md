---
title: JDK 8安装配置教程（Windows版）
description: Windows环境下安装配置JDK 8教程
category: 
  - 软件安装
  - Windows
  - 编程语言
  - Java/JDK
tags: [Java, Windows]
abbrlink: 1
date: 2023-12-06 09:36:00
---

> JDK，全称Java Development Kit，即Java开发工具包，它是整个Java开发的核心，包含了Java运行环境（JVM+Java系统类库）和Java工具。目前JDK 8、11、17、21是长期稳定支持的版本。

接下来为大家讲解一下JDK 8如何安装与使用。

# 一、下载JDK

以下两种方式二选一下载即可：

## 方式一：网盘下载

请选择任意一个链接，选择任意一个安装包下载即可：

| [点击下载](https://pan.baidu.com/s/1FjQlCUulceJWOQP96qQvjQ?pwd=mclj) | [备用下载1](https://pan.baidu.com/s/1K4gR2k152JWimdxEADvp2g?pwd=1024) | [备用下载2](https://pan.baidu.com/s/1-KFO-_GQOsF2M-PVzKt24w?pwd=1024) |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101131122731.png)

## 方式二：官网下载（需要注册账号登录，不推荐）

1\. 点击此链接到官网下载页面：[点击进入](https://www.oracle.com/java/technologies/downloads/archive/)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101131317529.png)

2\. 找到以Java SE Development Kit开头的下载列表，找到64位的版本版本下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101132604565.png)

3\. 按图所示点击下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101133458956.png)

4\. 需要登录Oracle账号，没有账号的可以注册一个。登陆后即可下载：

![](https://source.icode504.com/images/image-20240714131003147.png)

# 二、安装JDK（这里我使用的版本是JDK 8）

1\. 双击文件，开始安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101134018241.png)

2\. 点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314125453675.png)

3\. 修改安装路径（如果你是新手小白，可以不执行这一步操作，直接跳转到第5步），点击**更改**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314130028313.png)

4\. 在新建一个路径。为了避免后续出现问题，创建路径时，请不要JDK安装位置放在有中文字符的路径中。选择当前路径，点击确定：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101134722779.png)

5\. 点击下一步：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101134758455.png)

6\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314131058441.png)

7\. 安装过程中，出现了一个JRE安装（前面我们安装的JDK已经包含了JRE，可以选择不安装，如果不需要安装，出现下图窗口后直接点击右上角关闭即可，直接跳到第11步）。点击**更改路径**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314131446348.png)

8\. 新建一个路径，建议不要出现中文字符，然后选中此文件夹，点击确定：

![](https://icode504.oss-cn-beijing.aliyuncs.com/240101001.gif)

9\. 点击下一步：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101140732789.png)

10\. 安装中，安装完成以后此窗口会自动消失：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314132647334.png)

11\. 点击关闭，JDK安装完成。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314132930503.png)

> 对于首次安装的新手小白，请继续往下看；如果是老手或者已经安装了其他版本的JDK，可以选择性往下看。

# 三、配置JDK

1\. 找到JDK的安装路径，出现bin、conf等文件夹，点击上方路径，**鼠标右键**点击**复制**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101141148295.png)

2\. 打开文件夹，在左侧**鼠标右键**点击此电脑，点击**属性**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/Snipaste_2024-01-01_01-07-23.png)

3\. 点击高级系统设置：

|   Windows 11   | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101010932039.png) |
| :------------: | ------------------------------------------------------------ |
| **Windows 10** | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101011132186.png) |

4\. 点击**环境变量**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314134716166.png)

5\. 在下方系统变量中，点击**新建**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314134919881.png)

6\. 配置安装路径，按照图示操作即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101141636264.png)

7\. 双击Path进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314135756989.png)

8\. 按照图示操作即可，然后一路点击确定。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101141809160.png)

# 四、检查JDK是否安装成功

1\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，点击确定：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314140351859.png)

2\. 输入`javac`和`java`，会出现下图内容：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314140519091.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314141144190.png)

3\. 输入`java -version`，出现下图信息表示JDK安装成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20230314140629530.png)

