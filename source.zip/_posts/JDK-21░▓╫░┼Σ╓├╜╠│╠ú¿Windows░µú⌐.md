---
title: JDK 21安装配置教程（Windows版）
date: 2024-01-02 14:24:28
tags: [Java, Windows]
category: 
  - 软件安装
  - Windows
  - 编程语言
  - Java/JDK
abbrlink: 27
description: Windows环境下安装JDK 21教程
---

> 本文下载文件使用的是NDM（Neat Download Manager），如需使用此款软件的小伙伴，可以查看这篇教程：[下载神器NDM（Neat Download Manager）安装配置教程（适用于Windows和MacOS）](https://www.icode504.com/posts/24.html)

JDK，全称Java Development Kit，即Java开发工具包，它是整个Java开发的核心，包含了Java运行环境（JVM+Java系统类库）和Java工具。目前JDK 8、11、17、21是长期稳定支持的版本。

接下来为大家讲解一下JDK 21如何安装与使用。

# 一、下载JDK

1\. 打开Oracle JDK官网：[点我查看](https://www.oracle.com/java/technologies/javase/jdk21-archive-downloads.html)

2\. 在下载页面，选择一个版本的JDK下载，这里我选择的是21.0.1版本的JDK。在下面找到Windows版本，这里我选择的是exe文件下载。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231231234124976.png)

# 二、安装JDK

1\. 双击打开JDK安装包，进入安装界面，点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101000342542.png)

2\. 更改JDK的安装路径，这里我安装在了D盘（为了避免后续使用过程中出现各种各样的问题，建议安装路径是全英文的）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101000606080.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101000829197.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101000948438.png)

3\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101001012592.png)

4\. 安装完成，点击**关闭**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101001101762.png)

> 对于首次安装的新手小白，请继续往下看；如果是老手，可以选择性往下看。

# 三、配置JDK

1\. 找到JDK的安装路径，出现bin、conf等文件夹，点击上方路径，**鼠标右键**点击**复制**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101001823379.png)

2\. 打开文件夹，在左侧此电脑**鼠标右键**点击此电脑，点击**属性**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/Snipaste_2024-01-01_01-07-23.png)

3\. 点击**高级系统设置**：

|   Windows 11   | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101010932039.png) |
| :------------: | ------------------------------------------------------------ |
| **Windows 10** | ![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101011132186.png) |

4\. 点击**环境变量**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002218161.png)

5\. 在下方系统变量，点击**新建**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002302057.png)

6\. 配置系统变量，按照图示操作即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002611204.png)

7\. 双击Path进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002655185.png)

8\. 按照图示操作即可，然后一路点击确定。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101002812677.png)

9\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`，点击确定，进入命令行：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101003131968.png)

10\. 在命令行中，分别输入`javac`、`java`、`java -version`，如果有如下提示就说明JDK 21安装成功了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101003211769.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101003254767.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101003343061.png)

