---
title: JDK 8安装配置教程（Linux通用版）
tags:
  - Java
  - Linux
category_bar: true
archive: false
abbrlink: 55
description: Linux（适用于CentOS、Ubuntu、Debian等主流版本）环境下安装与配置JDK 8教程
date: 2024-03-05 21:56:21
banner_img:
index_img:
category: [软件安装, Linux]
password:
---


> JDK，全称Java Development Kit，即Java开发工具包，它是整个Java开发的核心，包含了Java运行环境（JVM+Java系统类库）和Java工具。目前JDK 8、11、17、21是长期稳定支持的版本。

接下来为大家讲解一下Linux环境下JDK 8如何安装与配置。

有需要在虚拟机安装Linux系统的小伙伴，请点击下方任意一个链接查看安装配置教程：

|          |                       CentOS                       |                       Ubuntu                       |                       Debian                       |
| :------: | :------------------------------------------------: | :------------------------------------------------: | :------------------------------------------------: |
| 安装教程 | [点我查看](https://www.icode504.com/posts/48.html) | [点我查看](https://www.icode504.com/posts/51.html) | [点我查看](https://www.icode504.com/posts/52.html) |

# 一、安装前检查（Linux端）

执行如下命令，查看当前系统的指令集：

```bash
uname -m
```

我的电脑是`x86_64`系统：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224090038508.png)

# 二、下载JDK（Windows端）

提供了两种下载方式：百度网盘下载和官网下载。以下两种方式二选一**下载到本地**即可：

## 方式一：百度网盘下载（推荐）

点击下方任意一个链接（百度网盘）进入下载页面：

| [点击下载](https://pan.baidu.com/s/12sU6r_YTYpkXF28IiiTayw?pwd=1024) | [备用下载1](https://pan.baidu.com/s/14zMAuIRLSpHU-PHrGw672Q?pwd=1024) | [备用下载2](https://pan.baidu.com/s/1XqxmHf5fRXl0ovz5zK-xbw?pwd=1024) |
| :----------------------------------------------------------: | :----------------------------------------------------------: | :----------------------------------------------------------: |

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224171106909.png)

根据上面检查的指令集，进入相应的文件夹：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224171230465.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224171648598.png)

## 方式二：官网下载（需要注册账号登录，不推荐）

1\. 点击此链接到官网下载页面：[点击进入](https://www.oracle.com/java/technologies/downloads/archive/)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224171904465.png)

2\. 找到以Java SE Development Kit开头的下载列表，找到64位的版本版本下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224172241466.png)

3\. 按图所示点击下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224172411350.png)

4\. 需要登录Oracle账号，没有账号的可以注册一个。登陆后即可下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240101133536759.png)

# 三、安装并配置JDK

1\. 将前面下载好的JDK安装包使用SFTP工具（这里我使用的是Eleterm）由Windows端传输到Linux端（请先确保Windows本身已经通过SSH方式连接到Linux）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224172925751.png)

2\. 在左侧Windows端找到下载好的安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224173324597.png)

3\. 在右侧Linux端设置安装包存放路径，这里我将安装包存放在`/opt`下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224173503187.png)

4\. 按照下图所示操作，将JDK安装包传到Linux端的`/opt`目录下：

![](https://icode504.oss-cn-beijing.aliyuncs.com/24010224004.gif)

5\. 等待一段时间后，此时Linux端的`/opt`目录下已经存放了刚才我们传输的文件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224173926690.png)

6\. 此时我们切换回命令行，执行如下命令切换到`/opt`目录下：

```bash
cd /opt
```

7\. 解压刚刚传入过来的压缩包，执行如下命令：

```bash
tar -zxvf jdk-8u331-linux-x64.tar.gz
```

>   小技巧：在命令行中输入文件名时，我们可以只写文件的前一部分，然后按一下<kbd>Tab</kbd>键补齐文件名。
>

8\. 等待一段时间后，解压完成，执行如下命令，进入解压后的文件夹名称：

```bash
ls
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224175030125.png)

使用`cd`命令进入解压后的文件夹：

```bash
cd jdk1.8.0_331
```

9\. 输入如下命令，查看并复制当前文件路径：

```bash
pwd
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240224175326821.png)

10\. 复制如下代码：

```shell
#JAVA_HOME  
JAVA_HOME=/opt/jdk1.8.0_331
PATH=$PATH:$JAVA_HOME/bin
export PATH JAVA_HOME 
```

11\. 在`/etc/profile.d`目录下创建`java_env.sh`文件，执行如下命令：

```bash
vim /etc/profile.d/java_env.sh
```

12\. 按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴第十步的代码，效果如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240225120311514.png)

13\. 将光标移动到第二行，将`JAVA_HOME`对应的值替换成第9步复制的路径。完成后按一下<kbd>Esc</kbd>键，然后输入`:wq`保存并退出。

14\. 执行如下命令，让环境变量配置生效：

```bash
source /etc/profile.d/java_env.sh
```

15\. 执行`java`、`javac`命令，可以看到如下内容：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240225120919666.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240225120949167.png)

16\. 输入`java -version`，出现下图信息表示JDK安装成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240225121013682.png)
