---
title: Linux CentOS安装教程
tags:
  - CentOS
category_bar: true
archive: false
abbrlink: 48
description: >-
  本文提供了在VMware
  Workstation上安装和配置CentOS虚拟机的详细步骤，指导用户完成从下载镜像到系统初始化等各个环节，帮助用户快速搭建CentOS环境。
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Linux CentOS安装教程.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Linux CentOS安装教程.png
category:
  - 系统安装
  - CentOS
date: 2024-02-21 14:39:56
password:
---


CentOS是一种基于Linux的免费、开源的操作系统，它是Red Hat Enterprise Linux（RHEL）源代码的重建版本。CentOS致力于提供稳定、可靠的服务器操作系统，广泛应用于企业级服务器和Web服务器。它具有强大的安全性和稳定性，并且提供长期支持（LTS）版本，使其成为企业级应用程序和服务的首选。CentOS还拥有庞大的软件包仓库，用户可以方便地安装和管理各种应用程序和工具。

接下来为大家介绍一下CentOS的安装和配置：

# 一、安装前准备

请确保电脑中已经安装了VMware和Electerm，如果没有安装的小伙伴可以点击下面的链接查看安装教程：

| 需要安装的软件名称                                        | 链接                                               |
| --------------------------------------------------------- | -------------------------------------------------- |
| 虚拟机软件VMware Workstation                              | [点我查看](https://www.icode504.com/posts/41.html) |
| 远程连接软件Electerm                                      | [点我查看](https://www.icode504.com/posts/47.html) |
| 下载器Neat Download Manager（推荐安装，可以加快下载速度） | [点我查看](https://www.icode504.com/posts/24.html) |

建议电脑预留50G的存储空间。

# 二、下载CentOS镜像

1\. 点击右侧连接进入清华大学镜像站：[点我查看](https://mirrors.tuna.tsinghua.edu.cn/centos/7.9.2009/isos/x86_64/)

2\. 选择第一个ISO镜像下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213123735767.png)

# 三、创建CentOS虚拟机

1\. 打开VMware，按<kbd>Ctrl</kbd>和<kbd>N</kbd>键，新建虚拟机。

2\. 进入新建虚拟机向导以后，选择第二个**自定义(高级)**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213123956847.png)

3\. 点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213124330853.png)

4\. 安装客户机操作系统选择**稍后安装操作系统**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213134527045.png)

5\. 客户机操作系统选择**Linux**，版本选择**CentOS 7 64位**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213134720664.png)

6\. 自定义虚拟机名称和安装位置。安装位置建议安装在一个空间比较大的盘，这里我安装在了J盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135011029.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135141593.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135218720.png)

7\. 处理器配置时处理器数量和内核数量不能超过电脑自身的数量，否则虚拟机无法运行。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135358478.png)

如何检查电脑本机的CPU信息：按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，即可查看到CPU信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135636008.png)

8\. 设置虚拟机内存，内存大小按照VMware的要求设置在一定范围之内。这里我设置内存大小为2GB（2048M），完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153034658.png)

9\. 网络类型选择**网络地址转换(NAT)**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153239112.png)

10\. I/O控制器类型按照系统默认选择即可，然后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153335558.png)

11\. 虚拟磁盘类型按照默认选择即可，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153449643.png)

12\. 选择磁盘按照系统默认选择即可，然后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153601825.png)

13\. 最大磁盘大小建议设置在20GB及以上，这里我设置了50GB，磁盘分配按照默认勾选即可。完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153741099.png)

14\. 指定磁盘文件位置可以自定义。这里需要设置的小伙伴点击**浏览**可以更改。不需要更改的小伙伴点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213154004431.png)

15\. 点击**完成**，虚拟机创建完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213154042917.png)

16\. 点击**编辑虚拟机设置**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213155240997.png)

17\. 进入虚拟机设置后，左侧设备选择**CD/DVD**，设备状态勾选**启动时连接**，连接选择**使用ISO映像文件**，点击**浏览**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213160808035.png)

18\. 找到前面我们下载的CentOS镜像并选中，完成后点击右下角**打开**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213155803316.png)

19\. 镜像配置成功，点击**确定**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213155857614.png)

# 四、开启虚拟化

1\. 开启刚刚创建好的虚拟机，此时VMware会弹出一个错误信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214629072.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113330696.png)

2\. 此时按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，虚拟化并未开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113646198.png)

3\. 重新启动电脑，具体进入BIOS可以根据自身电脑品牌型号进入。这里我的电脑使用的是华硕，开机过程中一直按<kbd>F2</kbd>键即可进入BIOS，再点击右下角**Advanced Mode**，进入高级模式：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227133747848.png)

4\. 按照下图所示操作，点击**高级**，将**Intel Virtualization Technology**配置项开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134148071.png)

5\. 按<kbd>F10</kbd>键保存上述配置并重启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134402192.png)

6\. 按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，左上角找到**性能**，发现虚拟化成功开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227114535913.png)

# 五、安装CentOS操作系统

1\. 开启刚刚创建好的虚拟机：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213154149205.png)

2\. 进入安装界面，选择**Install CentOS 7**并按回车键：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213162009857.png)

3\. 安装语言选择**中文**，**简体中文（中国）**，完成后点击**继续**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213162405815.png)

4\. 在下方系统中，点击**安装位置**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213162624440.png)

5\. 进入安装目标位置，点击左上角**完成**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213162739441.png)

6\. 点击**网络和主机名**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213162826207.png)

7\. 开启**以太网（ens33）**，确保虚拟机能连接网络。然后点击**完成**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213162956766.png)

8\. 点击**软件选择**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213163100879.png)

9\. 选择**最小安装**，然后点击左上角**完成**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213163228777.png)

10\. 点击右下角**开始安装**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213165505273.png)

11\. 安装中，此时我们为最高权限用户——root用户设置密码：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213165542509.png)

12\. 设置密码，如果你记不住密码，请将密码设置为123456，然后连续按两次**完成**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213165717743.png)

13\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213165922454.png)

14\. 安装完成，点击右下角的**重启**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213170233895.png)

15\. 重启后，进入CentOS命令行界面，用户名输入`root`，输入前面我们设置的密码（密码不会在命令行中显示），完成后按回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213170559674.png)

16\. CentOS登录成功：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213170629407.png)

# 六、使用SSH工具（Electerm）远程连接CentOS

1\. 在CentOS命令行中查看防火墙状态，在命令行中输入如下命令：

```bash
sudo systemctl status firewalld
```

防火墙正常运行：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213171051245.png)

2\. 开放22号端口（确保Electerm通过SSH方式连接到CentOS），执行如下命令：

```bash
sudo firewall-cmd --permanent --add-port=22/tcp
```

22号端口开启成功！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213171417549.png)

3\. 重新加载防火墙，执行如下命令：

```bash
sudo firewall-cmd --reload
```

4\. 输入下面的命令，查看虚拟机的ip地址：

```bash
ip addr
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221133557223.png)

5\. 打开Electerm，点击左侧的书签：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213171858078.png)

6\. 按照下图操作填写连接信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221134323586.png)

7\. 向下找，点击**测试连接**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221134731866.png)

等待一段时间后，如果上方出现一个`connection is ok`，说明前面填写内容没有问题：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221134841255.png)

如果出现的时`connection is failed`，说明填写的内容有问题，需要更改后再次测试连接。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221135000261.png)

8\. 测试连接成功后，点击**保存并连接**后，此时我们就可以在Electerm中登录root用户并执行命令了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221135129497.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221135430687.png)
