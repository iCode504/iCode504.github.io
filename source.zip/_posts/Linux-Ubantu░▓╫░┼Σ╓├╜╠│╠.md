---
title: Linux Ubuntu安装配置教程
tags:
  - Ubuntu
category_bar: true
archive: false
abbrlink: 51
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Linux Ubuntu安装配置教程.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Linux Ubuntu安装配置教程.png
category:
  - 系统安装
  - Ubuntu
date: 2024-02-27 11:01:31
description: 本教程详细介绍Linux Ubuntu的安装配置步骤，包括虚拟机创建、系统安装、网络配置、用户权限设置等关键内容，帮助用户快速搭建稳定、高效的Ubuntu系统环境。
password:
---


Ubuntu是一个基于Linux的开源操作系统，它遵循GNU通用公共许可证，用户可以自由使用、复制、分发和修改。它提供直观易用的桌面环境，适合新手和有经验用户。Ubuntu有强大的软件中心，支持多硬件架构，注重安全和稳定，并有庞大的用户社区提供支持。它适用于桌面、笔记本和服务器等多种设备，被广泛应用于教育、开发和科学等领域。

接下来就为大家介绍一下Ubuntu操作系统的安装与配置

# 一、安装前准备

请确保电脑中已经安装了VMware和Electerm，如果没有安装的小伙伴可以点击下面的链接查看安装教程：

| 需要安装的软件名称                                        | 链接                                               |
| --------------------------------------------------------- | -------------------------------------------------- |
| 虚拟机软件VMware Workstation                              | [点我查看](https://www.icode504.com/posts/41.html) |
| 远程连接软件Electerm                                      | [点我查看](https://www.icode504.com/posts/47.html) |
| 下载器Neat Download Manager（推荐安装，可以加快下载速度） | [点我查看](https://www.icode504.com/posts/24.html) |

建议电脑预留50G的存储空间。

# 二、下载Ubuntu镜像

截止到2024年2月，Ubuntu有两个长期支持的版本：22.04版本和20.04版本。这里我选择安装的是22.04版本的Ubuntu服务器。

1\. 点击右侧连接进入清华大学镜像站：[点我查看](https://mirrors.tuna.tsinghua.edu.cn/ubuntu-releases/)

2\. 这里我选择的是22.04版本下载，点击进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221212521251.png)

3\. 下载服务器端的Ubuntu，如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221215234033.png)

# 三、创建Ubuntu虚拟机

1\. 打开VMware，按<kbd>Ctrl</kbd>和<kbd>N</kbd>键，新建虚拟机。

2\. 进入新建虚拟机向导以后，选择第二个**自定义(高级)**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213123956847.png)

3\. 点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213124330853.png)

4\. 安装客户机操作系统选择**稍后安装操作系统**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213134527045.png)

5\. 客户机操作系统选择**Linux**，版本选择**Ubuntu 64位**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221215406394.png)

6\. 自定义虚拟机名称和安装位置。安装位置建议安装在一个空间比较大的盘，这里我安装在了J盘：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221213314426.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221215802166.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221215842308.png)

7\. 处理器配置时处理器数量和内核数量不能超过电脑自身的数量，否则虚拟机无法正常运行，这里我设置的**处理器内核总数**为2：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135358478.png)

如何检查电脑本机的CPU信息：按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，即可查看到CPU信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213135636008.png)

8\. 设置虚拟机内存，内存大小按照VMware的要求设置在一定范围之内。这里我设置内存大小为4GB（4096M），完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221213933440.png)

9\. 网络类型选择**网络地址转换(NAT)**，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153239112.png)

10\. I/O控制器类型按照系统默认选择即可，然后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153335558.png)

11\. 虚拟磁盘类型按照默认选择即可，完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153449643.png)

12\. 选择磁盘按照系统默认选择即可，然后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153601825.png)

13\. 最大磁盘大小建议设置在20GB及以上，这里我设置了50GB，磁盘分配按照默认勾选即可。完成后点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213153741099.png)

14\. 指定磁盘文件位置可以自定义。这里需要设置的小伙伴点击**浏览**可以更改。不需要更改的小伙伴点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214019977.png)

15\. 点击**完成**，虚拟机创建完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221215930776.png)

16\. 点击**编辑虚拟机设置**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214109235.png)

17\. 进入虚拟机设置后，左侧设备选择**CD/DVD**，设备状态勾选**启动时连接**，连接选择**使用ISO映像文件**，点击**浏览**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213160808035.png)

18\. 找到前面我们下载的Ubuntu镜像并选中，完成后点击右下角**打开**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221215053525.png)

19\. 镜像配置成功，点击**确定**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214534533.png)

# 四、开启虚拟化

1\. 开启刚刚创建好的虚拟机，此时VMware会弹出一个错误信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214629072.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113330696.png)

2\. 此时按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，找到性能，虚拟化并未开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227113646198.png)

3\. 重新启动电脑，具体进入BIOS可以根据自身电脑品牌型号进入。这里我的电脑使用的是华硕，开机过程中一直按<kbd>F2</kbd>键即可进入BIOS，再点击右下角**Advanced Mode**，进入高级模式：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227133747848.png)

4\. 按照下图所示操作，点击**高级**，将**Intel Virtualization Technology**配置项开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134148071.png)

5\. 按<kbd>F10</kbd>键保存上述配置并重启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227134402192.png)

6\. 按<kbd>Ctrl</kbd><kbd>Shift</kbd><kbd>Esc</kbd>，打开任务管理器，左上角找到**性能**，发现虚拟化成功开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240227114535913.png)

# 五、安装Ubuntu操作系统

1\. 开启刚刚创建好的虚拟机：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221214629072.png)

2\. 进入安装界面，选择第一个**Try or Install Ubuntu Server**，然后按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221220105109.png)

3\. 此时会加载Ubuntu的安装界面，请耐心等待。

4\. 加载完成后 ，进入Ubuntu安装界面，安装语言选择**English**，完成后按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221220404108.png)

5\. （无下图内容可以跳转到下一步）此时弹出安装器可更新提示，下方选项选择第二个**Continue  without updating**（不更新，继续安装），完成后按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221220520438.png)

6\. 键盘布局按照系统默认使用英文（美国）布局即可，选择**Done**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221221207754.png)

7\. 安装类型选择第一个**Ubuntu Server**即可，完成后选择**Done**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221221446276.png)

8\. 网络连接：如果电脑本机已经连接网络，此时虚拟机为我们提供了一个IP地址，按照默认配置选择即可。选择**Done**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221221802787.png)

9\. 这里我们不需要配置代理。选择**Done**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221222005115.png)

10\. 配置镜像地址，这里我们将原有的镜像地址替换为清华大学镜像地址：

```
http://mirrors.tuna.tsinghua.edu.cn/ubuntu
```

完成后，选择Done，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221222454818.png)

11\. 配置存储位置，按照默认选择即可，按向上/下键可以选择，选择**Done**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221222633089.png)

12\. 存储大小配置，按照默认配置即可，选择**Done**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221222821884.png)

13\. 此时会弹出一个确认提示，选择Continue会开始安装，会替换掉原有的磁盘空间，这里我们选择**Continue**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221222939475.png)

14\. 配置用户名和密码，如下图所示，完成后选择**Done**，按一下回车：

个人名称、服务器名称、用户名可以自定义（要求是：英文小写或者英文小写+数字）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222085916366.png)

15\. 是否升级到Ubuntu Pro，这里我们选择**Skip for now**（不升级），完成后选择**Continue**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221223617619.png)

16\. 这里我们将光标移动到Install OpenSSH server，按空格键勾选安装OpenSSH。然后选择**Done**，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240410155303916.png)

17\. 上述组件不需要安装，选择Done，按一下回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221224049360.png)

18\. 安装完成，选择第二个**Cancel Update And Reboot**（取消更新并重启）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222090135758.png)

19\. 重启中，请耐心等待（预计需要5分钟以上）。出现下面界面以后，按一下回车，继续重启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222090759375.png)

20\. 等待了3~5分钟以后，会出现登录页面，输入以下用户名（这里我设置的是`icode504`）和密码（这里我设置的是`123456`，密码不会在命令行中显示）。输入完成后会出现欢迎界面，此时我们可以在命令行中输入命令了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222091618140.png)

# 六、为root用户分配密码

作为最高权限的root用户，我们在安装过程中并没有给root用户分配密码。

执行如下命令，为root用户分配密码：

```bash
sudo passwd
```

此时会输入两次密码（不会在控制台显示）。为了方便记忆，我将root密码设置成123456：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222092902842.png)

切换到root用户，执行如下命令：

```bash
su root
```

此时Ubuntu会提醒我们输入密码，完成后按一下回车，此时成功切换到root用户：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222093247305.png)

# 七、使用SSH工具（Electerm）远程连接Ubuntu

请保证当前宿主机（电脑本机）处于联网状态：

1\. 开启SSH服务：

```bash
service ssh start
```

2\. 检查SSH服务是否开启，执行如下命令：

```bash
systemctl status sshd
```

下图状态说明SSH服务已经成功开启：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240223163734033.png)

3\. 由于`root`用户默认是不能使用SSH的方式登录，因此我们需要更改一下对配置文件`/etc/ssh/sshd_config`进行修改。执行如下命令：

```bash
sudo vim /etc/ssh/sshd_config
```

4\. 此时会进入`sshd_config`配置文件中，我们依次执行如下命令：

```bash
:set nu
/PermitRootLogin
```

此时我们在33行可以看到如下信息`PermitRootLogin prohibit-password`，这段配置的含义是使用SSH方式登录root用户是禁止的，因此我们需要对这段代码进行修改：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240223164810399.png)

5\. 按<kbd>i</kbd>键进入编辑模式，需要对32-34行代码修改成下图所示的效果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240223165235024.png)

6\. 完成编辑后，先按一下<kbd>Esc</kbd>键，再输入`:wq`保存并退出编辑。

7\. 重启SSH服务，执行如下命令：

```bash
systemctl restart sshd
```

8\. 在Ubuntu命令行中查看防火墙状态，在命令行中输入如下命令：

```bash
sudo ufw status
```

此时会提示输入密码（这里我已经输入过了）后即可查看防火墙状态是`inactive`（未开启）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222092256776.png)

9\. 为了保障系统安全，我们需要开启防火墙，只开放特定的端口。输入如下命令开启防火墙：

```bash
sudo ufw enable
```

再次查看防火墙状态，此时防火墙已经开启：

```bash
sudo ufw status
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222092440839.png)

10\. SSH默认是22号端口，此时我们需要开启22号端口。执行如下命令：

```bash
sudo ufw allow 22/tcp
```

执行成功，规则已添加：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222093510263.png)

11\. 输入如下命令，查看Ubuntu的IP地址：

```bash
ip addr
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222094049603.png)

12\. 打开Electerm，点击左侧的书签：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240213171858078.png)

13\. 按照下图操作填写连接信息：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222094417131.png)

14\. 向下找，点击**测试连接**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221134731866.png)

等待一段时间后，如果上方出现一个`connection is ok`，说明前面填写内容没有问题：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221134841255.png)

如果出现的时`connection is failed`，说明填写的内容有问题，需要更改后再次测试连接。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221135000261.png)

15\. 测试连接成功后，点击**保存并连接**后，此时我们就可以在Electerm中登录root用户并执行命令了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240221135129497.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240223170311453.png)
