---
title: Node.js安装、配置和卸载教程（Windows版）
tags:
  - Node.js
  - npm
  - Windows
category_bar: true
archive: false
abbrlink: 67
description: >-
  这篇教程旨在为 Windows 用户提供 Node.js
  的安装指南，涵盖了安装、配置和卸载过程。此外，本文还提供了npm镜像源的修改，方便读者使用国内镜像源快速下载项目所需依赖。
banner_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/Node.js安装、配置和卸载教程（Windows版）-封面.png
index_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/Node.js安装、配置和卸载教程（Windows版）-封面.png
category:
  - 软件安装
  - Windows
  - 前端框架工具
date: 2024-04-28 09:08:59
password:
---


Node.js 是一个基于 Chrome V8 引擎的 JavaScript 运行时环境，使 JavaScript 能够在服务器端运行，它提供了一个事件驱动的非阻塞 I/O 模型，使得构建高效、可扩展的网络应用变得更加容易。而 npm（Node Package Manager）是 Node.js 的包管理工具，用于安装、分享、管理 JavaScript 代码包，使开发者能够轻松地将自己的代码与他人的代码集成，并且享受到社区共享的各种功能模块。Node.js 和 npm 的结合使得 JavaScript 开发者能够在服务器端和客户端都使用同一种语言，极大地提高了开发效率和跨平台能力。

以下是Windows环境下Node.js的安装教程：

# 一、准备操作

推荐安装如下软件（不强制要求）：

| 软件                         | 安装教程                                           | 说明                                                         |
| ---------------------------- | -------------------------------------------------- | ------------------------------------------------------------ |
| NDM（Neat Download Manager） | [点我查看](https://www.icode504.com/posts/24.html) | 推荐使用NDM（Neat Download Manager）下载文件，可以加快下载速度（推荐）。 |


# 二、下载Node.js

1\. 点击右侧链接下载Node.js：[点我查看](https://nodejs.org/dist/)

2\. 下载页面中有Node.js过去的各个发行版本，这里我选择的是最新的16版本的Node.js，如下图，点击进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240619232411366.png)

3\. Windows 64位操作系统的小伙伴推荐下载msi方式的安装包下载（如下图）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240619232609935.png)

# 三、安装Node.js

1\. 双击打开安装包，进入安装界面，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426110553409.png)

2\. **勾选**用户许可协议，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426110726211.png)

3\. 点击**Change**修改安装路径，这里我安装在了D盘（建议安装路径存放在一个你熟悉的位置，并且是英文路径），完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426110747764.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111024855.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111136195.png)

4\. 选择要安装的模块，不熟悉的小伙伴直接按照系统默认选择的模块即可，点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111203354.png)

5\. 本地模块工具，如果你使用Python或者Visual Studio的构建工具，就将下图内容勾选即可（这里我并没有用到上述内容，我选择**不勾选**），完成后点击Next：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111238393.png)

6\. 点击**Install**开始安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111249199.png)

7\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111304999.png)

8\. 点击**Finish**，Node.js安装完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111317567.png)

9\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`进入命令行，分别输入`node -v`和`npm -v`，如果能够查看到响应的版本信息就说明Node.js安装成功！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111504600.png)

# 四、npm更换镜像源

Node.js中包含一个重要模块：npm，它的作用是帮助我们下载项目中的依赖（你可以理解成下载对应的软件包），但是npm默认的下载地址在国外，如果使用了默认的下载地址，后续在使用npm的过程中下载依赖会非常慢，因此，我们需要将npm默认的下载地址改成国内镜像，这里我使用的是淘宝镜像源。

1\. 执行如下命令查看当前`npm`的下载源：

```shell
npm config get registry
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240428091353944.png)

2\. 将镜像源更改成淘宝镜像源，执行如下命令：

```shell
npm config set registry https://registry.npmmirror.com
```

3\. 再次执行如下命令，镜像源成功修改为淘宝镜像源：

```shell
npm config get registry
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426111933066.png)

# 五、Node.js的卸载

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴请继续往下看！

1\. 打开Geek Uninstalller，找到Node.js，鼠标右键点击卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426105703719.png)

2\. 选择是，卸载Node.js：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426105801702.png)

3\. 卸载中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426105842216.png)

4\. 卸载完成，此时Geek Uninstaller并没有卸载残留，点击关闭，Geek Uninstaller卸载完毕：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240426105948110.png)