---
title: Node.js安装、配置教程（Linux通用版）
tags:
  - Node.js
  - npm
  - Linux
category_bar: true
archive: false
abbrlink: 74
description: >-
  这篇教程旨在为 Linux 用户提供
  Node.js的安装指南，涵盖了安装、配置和卸载过程。此外，本文还提供了npm镜像源的修改，方便读者使用国内镜像源快速下载项目所需依赖。
banner_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/Node.js安装、配置和卸载教程（Windows版）-封面.png
index_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/Node.js安装、配置和卸载教程（Windows版）-封面.png
category:
  - 软件安装
  - Linux
  - 前端框架工具
date: 2024-06-12 07:36:52
password:
---

Node.js 是一个基于 Chrome V8 引擎的 JavaScript 运行时环境，使 JavaScript 能够在服务器端运行，它提供了一个事件驱动的非阻塞 I/O 模型，使得构建高效、可扩展的网络应用变得更加容易。而 npm（Node Package Manager）是 Node.js 的包管理工具，用于安装、分享、管理 JavaScript 代码包，使开发者能够轻松地将自己的代码与他人的代码集成，并且享受到社区共享的各种功能模块。Node.js 和 npm 的结合使得 JavaScript 开发者能够在服务器端和客户端都使用同一种语言，极大地提高了开发效率和跨平台能力。

以下是 Linux 环境下 Node.js 的安装教程：

# 一、安装前操作

1\. 执行如下命令查看当前操作系统信息：

```bash
uname -a
```

这里我使用的是 x86_64 的 Debian 操作系统：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611073052595.png)

2\. 下载并安装如下工具：wget、vim、tar

> wget 是 Linux 下载文件常用的命令。
>
> vim 是一款编辑器，里面包含编辑模式、查看模式和命令模式。
>
> tar 用来解压 tar 类型相关压缩包的命令。

- CentOS

```bash
yum -y install wget vim tar
```

- Ubuntu/Debian

```bash
apt -y install wget vim tar
```

# 二、下载 Node.js 安装包

1\. 打开右侧链接地址，进入 Node.js 官方下载链接列表页：[点我查看](https://nodejs.org/dist/)

2\. 这里我选择 v16.20.2 版本下载，找到这个文件夹，点击进入：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240610231104421.png)

3\. 根据前面的指令集下载对应的安装包，由于我的 Linux 是 x86_64 指令集，因此需要鼠标点击下图的红色框链接再点击复制链接：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611080533882.png)

4\. 在命令行中，执行如下命令：

```bash
wget 上一步复制的链接地址
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611080811017.png)

5\. 等待一段时间后，下载完成，执行`ls`文件就可以看到当前目录下存在一个 node.js 的安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611081213944.png)

6\. 这里我将压缩包解压到`/usr/local`目录下，执行如下命令：

```
tar -zxvf node-v16.20.2-linux-x64.tar.gz -C /usr/local
```

7\. 解压完成，切换到`/usr/local`目录，执行如下命令：

```bash
cd /usr/local
```

8\. 执行`ls`命令可以看到我们刚刚解压到的文件目录：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611081956844.png)

# 三、设置环境变量

1\. 鼠标**移到**上方的加号位置，找到你现在所连接的服务器，再开启一个窗口：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611091759323.png)

此时有弹出了一个命令行窗口，我们将这个窗口称作窗口 2，原来的窗口称作窗口 1：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611092026272.png)

2\. （当前位置：窗口 2）在当前目录下新建一个文件 node_env.sh，执行如下命令：

```bash
vim node_env.sh
```

3\. 复制如下代码：

```shell
#NODEJS_HOME
NODEJS_HOME=/usr/local/node-v16.20.2-linux-x64
PATH=$PATH:$NODEJS_HOME/bin
export PATH NODEJS_HOME
```

4\. （当前位置：窗口 2）按<kbd>i</kbd>键进入编辑模式，按<kbd>Shift</kbd>和<kbd>Insert</kbd>键粘贴第 4 步的代码，效果如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611085017634.png)

5\. 切换到窗口 1，进入解压后的文件目录，执行如下命令：

```bash
cd node-v16.20.2-linux-x64/
```

6\. （当前位置：窗口 1）输入`pwd`命令查看当前文件所在路径并复制：

> 说明：鼠标直接选中红色框中的内容，按<kbd>Ctrl</kbd><kbd>C</kbd>复制（或者鼠标右键点击复制也可以）。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611082219906.png)

7\. （当前位置：窗口 2）将光标移动到第二行，将`NODEJS_HOME`对应的值替换成第 6 步复制的路径。完成后按一下<kbd>Esc</kbd>键，然后输入`:wq`保存并退出。

8\. 执行如下命令，让环境变量配置生效：

```bash
source /etc/profile/node_env.sh
```

9\. 依次执行`node -v`和`npm -v`命令，如果能查看到对应的版本号，就说明上面的环境变量已生效：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611085516463.png)

# 四、npm 更换镜像源

Node.js 中包含一个重要模块：npm，它的作用是帮助我们下载项目中的依赖（你可以理解成下载对应的软件包），但是 npm 默认的下载地址在国外，如果使用了默认的下载地址，后续在使用 npm 的过程中下载依赖会非常慢，因此，我们需要将 npm 默认的下载地址改成国内镜像，这里我使用的是淘宝镜像源。

1\. 执行如下命令查看当前`npm`的下载源：

```bash
npm config get registry
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611085737362.png)

2\. 将镜像源更改成淘宝镜像源，执行如下命令：

```bash
npm config set registry https://registry.npmmirror.com
```

3\. 再次执行如下命令，镜像源成功修改为淘宝镜像源：

```bash
npm config get registry
```

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240611085952087.png)
