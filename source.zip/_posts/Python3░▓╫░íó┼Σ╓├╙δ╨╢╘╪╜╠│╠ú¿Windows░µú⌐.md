---
title: Python3安装、配置与卸载教程（Windows版）
tags:
  - Windows
  - Python
category_bar: true
archive: false
abbrlink: 49
description: >-
  本文提供了在Windows操作系统上安装、配置和卸载Python的详细步骤。该教程适合初学者和需要重新安装或更新Python的用户，帮助他们轻松完成Python环境的搭建。
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Python安装、配置与卸载教程（Windows版）.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Python安装、配置与卸载教程（Windows版）.png
category: 
  - 软件安装
  - Windows
  - 编程语言
  - Python
date: 2024-02-26 21:17:27
password:
---


Python 是一种高级编程语言，由 Guido van Rossum 在 1989 年创造，并于 1991 年第一次公开发布。Python 的设计哲学强调代码的可读性和简洁的语法（尤其是使用空格缩进划分代码块），这使得 Python 成为初学者和专家都喜欢的语言。

以下是 Python 的一些主要特点：

1. **易于学习**：Python 是一种解释型语言，语法简洁明了，代码结构清晰，易于上手。
2. **跨平台**：Python 是跨平台的，可以在多种操作系统上运行，包括 Windows、Linux、macOS 等。
3. **免费和开源**：Python 是开源的，任何人都可以获取源代码并修改。它也有一个庞大的社区和丰富的第三方库，这些库覆盖了各种任务，从 Web 开发到科学计算。
4. **动态类型**：Python 是动态类型的语言，这意味着你不需要在声明变量时指定其类型，Python 会在运行时确定类型。
5. **面向对象**：Python 支持面向对象编程，包括类和继承。
6. **强大的库**：Python 标准库包含了许多常用的功能，如文件处理、网络编程、数据库接口、图形界面开发、科学计算等。此外，还有大量的第三方库，如 NumPy、Pandas、Matplotlib 用于数据处理和可视化，Django、Flask 用于 Web 开发，以及 TensorFlow、PyTorch 用于机器学习。
7. **可扩展性**：Python 可以调用 C、C++ 等语言的代码，也可以将 Python 代码编译成 C 扩展模块，从而提高执行效率。
8. **脚本编写**：Python 常被用于编写脚本，自动化日常任务，如文件处理、数据转换等。
9. **科学计算和数据分析**：Python 在科学计算和数据分析领域非常受欢迎，特别是在数据科学、机器学习和人工智能领域。
10. **Web 开发**：Python 有多个 Web 框架，如 Django 和 Flask，使得 Python 成为 Web 开发的流行选择。

目前主要使用的版本是Python 3.x.x版本（Python 2.x.x版本）以下是Windows环境下Python的安装教程：

# 一、Python的下载

1\. 打开Python官网下载连接：[点我查看](https://www.python.org/downloads/windows/)（加载可能会比较慢，请耐心等待）

2\. 这里我下载的是Python 3.7.9，点击**Windows x86-64-executable installer**下载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226160327855.png)

# 二、Python的安装

1\. 双击打开Python安装包：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172043318.png)

2\. 进入安装界面后，将最下方**Add Python 3.7 to PATH**（将Python添加到环境变量），然后点击**Customize installation**（自定义安装）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172222002.png)

3\. 安装额外组件按照系统默认勾选即可，完成后点击**Next**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172312844.png)

4\. 点击**Browse**修改安装路径，这里我安装在了D盘，修改完成后，点击**Install**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172557771.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172718016.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172808930.png)

5\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172841392.png)

6\. 安装完成，点击**Close**关闭此窗口：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226172922054.png)

7\. 按<kbd>Win</kbd>和<kbd>R</kbd>键，输入`cmd`并按一下回车，进入命令行，输入`python --version`，出现如下信息就说明Python已经安装并配置成功了：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226110954813.png)

# 三、pip更换源

pip是官方提供的一款Python包下载安装工具，但是它的默认下载源在国外，下载速度比较慢，因此我们需要将下载源更改为国内的镜像源。

执行如下命令，既可以将下载源更换为国内镜像，这里我使用的是清华大学的镜像源：

```bash
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple/
```

（以下是演示内容）配置完成后，这里我想下载一个Python Web框架Django，直接在命令行执行如下命令即可安装：

```bash
pip install Django
```

下载过程中我们可以看到镜像源更换成功！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240628112818394.png)

# 四、Python的卸载（可选）

{%note danger%}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{%endnote%}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Installer，在程序列表中找到Python，鼠标右键，点击卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226174232044.png)

2\. 卸载中，请耐心等待。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226174249116.png)

3\. 卸载完成，点击Close关闭此窗口：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226174758587.png)

4\. 此时Geek会我们检测安装残留，这里我的电脑未检测出卸载残留，只需要点击**关闭**即可，卸载完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240226101538583.png)
