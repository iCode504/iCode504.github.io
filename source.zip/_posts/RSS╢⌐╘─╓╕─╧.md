---
title: RSS订阅指南
tags:
  - RSS
category_bar: true
archive: false
description: RSS订阅指南
category:
  - RSS
abbrlink: 59
date: 2024-03-18 21:04:42
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/RSS订阅指南-封面.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/RSS订阅指南-封面.png
password:
---


RSS是一种简易的网页内容聚合格式，其全称为“Really Simple Syndication”（简易消息聚合）。它允许用户获取网站更新的摘要或完整内容，而无需访问网站本身。RSS以XML格式发布，允许内容从一个源（网站）传送到另一个源（RSS阅读器）。

RSS的好处包括：

1. **便利的信息获取**: 用户可以通过RSS阅读器一次性获取多个网站的更新内容，无需逐个访问网站，节省时间和精力。

2. **定制化订阅**: 用户可以根据个人兴趣订阅特定网站或特定主题的内容，使其阅读体验更加个性化。

3. **实时更新**: RSS阅读器能够及时获取更新内容，使用户随时了解最新信息。

4. **减少信息干扰**: 通过RSS，用户可以将感兴趣的内容集中在一个平台上，减少了在各个网站间的跳转，避免了信息干扰。

5. **隐私保护**: RSS阅读器通常不需要用户提供个人信息，因此能够保护用户的隐私。

以下是RSS相关插件安装及在浏览器中使用教程：

# 一、下载插件

| 插件名称               | 下载链接                                            |
| ---------------------- | --------------------------------------------------- |
| RSS阅读器——Feedbro插件 | [点我下载](https://icode504.lanzn.com/inWah1p1vh6h) |
| 信息抓取——Rsshub插件   | [点我下载](https://icode504.lanzn.com/iXhFp1p1vhab) |

# 二、安装插件

1\. 打开谷歌浏览器，按照下图所示打开管理扩展程序：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127152259082.png)

2\. 在浏览器右上角打开开发者模式：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127152522395.png)

3\. 将下载好的两个插件**依次拖入**浏览器的扩展程序中，如果开关打开，就说明两个插件已经安装成功了。

![](https://icode504.oss-cn-beijing.aliyuncs.com/240222009.gif)

4\. 安装完成后，点击右上角的插件图标，将这两个插件置顶显示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240317211639175.png)

5\. 此时在搜索栏就会出现这两个图标：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240317211752012.png)

# 三、Feedbro插件汉化

1\. 按照下图所示打开Feedbro插件设置：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240317212017375.png)

2\. 复制下面的链接：

```
https://icode504.oss-cn-beijing.aliyuncs.com/feedbro-locale-zh_CN.json
```

3\. 找到Settings --> User interface language，点击**Import Locale**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222170611845.png)

4\. 将前面复制的链接粘贴到此处，完成后点击OK：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222171356676.png)

5\. 汉化完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240222171438729.png)

# 四、抓取RSS订阅源

1\. 以我的个人网站为例：https://www.icode504.com，此时RSSHub图标有一个数字，点击图标：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240318203343379.png)

2\. 点击Feedbro插件图标，然后点击**打开订阅源阅读器**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240318203509688.png)

3\. 进入到主页面以后，点击**添加新的源**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240318203630935.png)

4\. 将第一步复制的链接粘贴到订阅源URL，然后点击**加载**，此时会显示标题内容，然后点击**保存**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240318203911654.png)

5\. 此时点击左侧标题，界面会显示最近抓取的内容，点击任意一个链接可以跳转到网站查看对应的内容：

>   说明：以本网站为例，后续文章更新都可以在Feedbro中可以查看阅读

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240318204226290.png)
