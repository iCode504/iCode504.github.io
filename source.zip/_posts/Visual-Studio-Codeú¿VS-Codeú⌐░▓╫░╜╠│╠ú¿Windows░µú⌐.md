---
title: Visual Studio Code安装配置教程（Windows版）
tags:
  - Visual Studio Code
  - Windows
category_bar: true
abbrlink: 38
description: Windows环境下安装Visual Studio Code
banner_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/Visual Studo
  Code安装配置教程（Windows版）-封面.png
index_img: >-
  https://icode504.oss-cn-beijing.aliyuncs.com/Visual Studo
  Code安装配置教程（Windows版）-封面.png
category: 
  - 软件安装
  - Windows
  - 集成开发环境
date: 2024-01-31 17:21:13
---


# 一、下载Visual Studio Code（VS Code）

> 本文后续内容使用NDM（Neat Download Manager）下载文件，可以加快下载速度（推荐）。如需使用此款软件的小伙伴，可以查看这篇教程：[下载神器NDM（Neat Download Manager）安装配置教程（适用于Windows和MacOS）](https://www.icode504.com/posts/24.html)，已经安装的小伙伴接着往下看。

1\. 打开官网下载地址：[点我查看](https://code.visualstudio.com/Download)

2\. 根据自己的操作系统，选择下载安装包。这里我使用的是Windows，只需要点击第一个即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222155257752.png)

3\. 如果浏览器没有下载，就点击页面中的这个链接下载（浏览器已下载的请忽略这条）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222155506749.png)

# 二、安装Visual Studio Code（VS Code）

1\. 双击打开安装包。按照下图所示**勾选协议**，点击下一步：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222160359382.png)

2\. 点击**浏览**选择安装路径，这里我安装在了D盘（如不需要更改安装路径的请跳转至下一步）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222160520232.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222160616103.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222160650958.png)

3\. 点击下一步

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222160715044.png)

4\. 附加服务页面建议全部勾选，然后点击下一步：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222160944031.png)

5\. 上述内容确认无误后，点击安装：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222161027142.png)

6\. 安装中，请耐心等待：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222161056793.png)

7\. 安装完成，勾选**运行Visual Studio Code**

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231222161130731.png)

# 三、Visual Studio Code（VS Code）的简单配置

## 3.1 页面汉化（可选）

VS Code默认是英文界面，对于一些英文不太好的小伙伴可能不太友好，好在官方为我们提供了VS Code的汉化包。

1\. 在左侧菜单找到插件商店：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131170427487.png)

2\. 在搜索框中搜索`Chinese Simplified`，搜索结果第一个就是我们要安装插件，点击Install安装插件：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131170733135.png)

3\. 安装完成后，右下角会弹出一个窗口提示，点击`Change Language and Restart`，重新加载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131170831058.png)

4\. 汉化成功！页面如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131170910022.png)

## 3.2 开启文件自动保存（可选）

在VS Code中写代码，默认是需要按<kbd>Ctrl</kbd>+<kbd>S</kbd>键保存文件。但是如果出现意外状况（例如电脑突然断电），你编写的代码如果没保存，绝对能搞炸你的心态。因此，我们需要开启文件自动保存功能

1\. 点击左下角的齿轮（或者按快捷键<kbd>Ctrl</kbd>和<kbd>,</kbd>），进入设置：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131213903209.png)

2\. 在上方搜索框中输入`auto save`，常用设置中改为`afterDelay`：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131171830424.png)

3\. 左侧菜单选择**文件**，将保存方式更改成**afterDelay**，保存时间间隔自定义（以毫秒为单位）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131172107593.png)

## 3.3 主题风格配置（可选）

VS Code支持多种主题风格配置。例如：暗黑风格、纯白风格等等。

> 说明：如果系统自带的风格都不符合，可以到插件商店自行下载其他风格的主题。

1\. 点击左下角的齿轮，选择主题：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131214819974.png)

2\. 此时浏览器上方会弹出系统自带的颜色主题。2024是龙年，也是我的本命年，这里我选个红色，图个喜庆！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131214912974.png)

3\. 修改后的颜色风格如下图所示：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240131215053668.png)