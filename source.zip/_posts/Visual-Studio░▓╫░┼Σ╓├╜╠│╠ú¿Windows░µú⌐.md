---
title: Visual Studio安装配置教程（Windows版）
tags: [Visual Studio, Windows]
category_bar: true
archive: false
description: 本文将指导您在Windows操作系统上安装、配置和卸载Visual Studio，并在IDE上运行一个简单的C++程序。
category:
  - 软件安装
  - Windows
  - 集成开发环境
abbrlink: 66
date: 2024-04-16 17:23:25
banner_img: https://icode504.oss-cn-beijing.aliyuncs.com/Visual Studio安装配置教程（Windows版）-封面.png
index_img: https://icode504.oss-cn-beijing.aliyuncs.com/Visual Studio安装配置教程（Windows版）-封面.png
password:
---


Visual Studio是由微软开发的集成开发环境（IDE），用于软件开发和应用程序编程。它支持多种编程语言，包括C#、C++、Python、JavaScript等，因此广泛应用于各种软件开发项目中，包括桌面应用程序、网站、移动应用程序等。

Visual Studio拥有丰富的功能和工具，使开发人员能够高效地编写、调试和测试代码。其中一些主要特性包括：

1. **代码编辑器**：提供了强大的代码编辑功能，包括语法高亮、自动补全、代码片段等，以提高编码效率。

2. **调试工具**：支持在代码中设置断点，逐步执行代码并观察变量的值，以便定位和修复程序中的错误。

3. **图形化设计工具**：包括界面设计器、数据库设计器等，用于快速创建用户界面和数据库结构。

4. **版本控制集成**：与版本控制系统（如Git、SVN）集成，方便团队协作开发，管理代码版本。

5. **扩展性**：Visual Studio支持各种插件和扩展，可以根据需要添加新的功能和工具，以满足特定项目的需求。

6. **跨平台开发**：Visual Studio支持开发各种平台的应用程序，包括Windows、Linux、iOS和Android等。

以下是Windows环境下安装Visual Studio教程：

# 一、下载Visual Studio安装器

1\. 下载地址：[点我查看](https://visualstudio.microsoft.com/zh-hans/downloads/)

2\. 对于个人学习开发，选择社区版的Visual Studio即可。点击左下角的下载按钮，开始下载VS的安装器

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229160920246.png)

# 二、安装前准备——网络设置

1\. 在右下角**鼠标右键点击**网络，这里我使用的是宽带连接，**打开“网络和Internet”设置**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229161633822.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229161658718.png)

2\. 在状态设置中，下方有一个高级网络设置，点击**更改适配器选项**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229161755127.png)

3\. **鼠标右键**点击网络，菜单倒数第二个，选择**属性**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229161958376.png)

4\. **取消勾选**Internet 协议版本 6（TCP/IPv6）

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229162117601.png)

5\. 选择**Internet协议版本 4（TCP/IPv4）**，然后点击**属性**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229162316539.png)

6\. DNS服务器服务器地址选择**使用下面的DNS服务器地址**（下方第二个），首选DNS服务器设置为`8.8.8.8`，完成后点击确定：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229162617811.png)

# 三、安装Visual Studio

1\. 双击打开刚刚下载好的VS安装器，弹出一个小窗口，点击**继续**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229161128976.png)

2\. 准备VS安装程序中，请耐心等待（预计需要等待2~5分钟）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229161150347.png)

3\. 进入安装界面后（页面加载预计需要3~5分钟，请耐心等待），左上角菜单选择第四个**安装位置**，推荐安装在除C盘以外的位置（这里我安装了D盘），并且路径中建议只包含英文字符：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229163505725.png)

4\. 点击左上角第三个菜单**语言包**，按照默认勾选的就可以（中文简体和英文）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229163823319.png)

5\. 点击左上角**工作负荷**，根据自己使用场景来安装，这里我要学习C++开发，只需要**勾选使用C++的桌面开发**，完成后点击右下角的**安装**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229164719742.png)

6\. 安装中，请耐心等待（预计需要等待20~30分钟）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229164837515.png)

7\. 安装完毕，点击**确定**（没有此窗口的小伙伴请跳转到下一步）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229171425937.png)

8\. 点击启动，启动Visual Studio Community 2022：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229175937840.png)

9\. 推荐登录，没有账号可以创建账户：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229180039421.png)

10\. 登录成功，此时出现了创建项目界面：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229180253254.png)

# 四、创建C++项目

1\. 点击**创建新项目**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229180329093.png)

2\. 选择**控制台应用**，点击**下一步**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229180424885.png)

3\. 按照下图所示修改项目信息，完成后点击**创建**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229180700557.png)

4\. 进入编辑器界面以后，右侧解决方案资源管理器中已经为我们创建了一个实例文件：`MyWorkspace231229.cpp`，这个`cpp`文件我们点击上方的开始执行按钮（或者按<kbd>Ctrl</kbd><kbd>F5</kbd>）运行一下这个程序：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229181024875.png)

5\. 此时会弹出一个`Hello, world`控制台窗口就说明程序运行成功！

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231229181107515.png)

# 五、卸载Visual Studio（可选）

{% note danger %}

这一部分会将软件卸载，请谨慎操作！如果不需要卸载，请直接跳过这一部分的内容！

{% endnote %}

> 注意：本文使用到Geek Uninstaller卸载软件，如果有需要的小伙伴请点击右侧链接查看安装教程：[点我查看](https://www.icode504.com/posts/31.html)
>
> 已经安装的小伙伴可以接着往下看！

1\. 打开Geek Installer，在程序列表中找到Visual Studio，鼠标右键，点击卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416160607127.png)

2\. 此时会加载安装器，加载完成后会弹出一个是否卸载的窗口，选择**是**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416160729270.png)

3\. 卸载中，请耐心等待（预计需要等待5分钟以上）：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416160754932.png)

4\. 卸载完成，点击关闭即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416161511251.png)

5\. 此时Geek扫描无残留文件，直接点击关闭即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416161554587.png)

6\. 将Visual Studio的安装器也卸载：找到Visual Studio Installer，鼠标右键点击卸载：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416162636148.png)

7\. 此时弹窗一个卸载窗口，点击**卸载**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416162738912.png)

8\. 卸载完成，点击**确定**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416162831757.png)

9\. 此时Geek扫描到残留文件，直接点击完成就会清理卸载残留：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416162917310.png)

10\. 点击完成，至此Visual Studio卸载完成：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240416163020699.png)