---
title: 浏览器下载安装Vue2开发者工具插件
tags:
  - Vue
  - Vue开发者工具
category_bar: true
archive: true
category:
  - Vue
  - Vue2
  - Vue开发者工具
password: 123456
abbrlink: 925751481
date: 2024-02-06 09:25:34
description:
banner_img:
index_img:
---


以下是谷歌浏览器、Edge浏览器、火狐浏览器Vue 2开发者工具插件的安装配置操作，大家根据自身具体情况安装即可：

# 一、谷歌（Chrome）浏览器下载安装Vue开发者工具

1\. 下载Vue开发者工具插件：[点我下载](https://icode504.lanzouw.com/iq4kZ1g3qveh)

2\. 打开谷歌浏览器，按照下图所示打开管理扩展程序：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127152259082.png)

3\. 在浏览器右上角打开开发者模式：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127152522395.png)

4\. 将下载好的Vue开发者工具拖入浏览器的扩展程序中，如果开关打开，就说明Vue开发者工具已经安装成功了。

![](https://icode504.oss-cn-beijing.aliyuncs.com/231127002.gif)

# 二、Edge浏览器下载安装Vue开发者工具

1\. 按照下图所示操作，打开插件商店：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240206091431073.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240206091525131.png)

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240206091640189.png)

2\. 在插件商店搜索`Vue Developer Tools`并回车，搜索结果第一个就是我们要下载安装的插件，点击**获取**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240206091851687.png)

3\. 点击**添加扩展**：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240206091949626.png)

4\. 添加成功，点击右上角关闭即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20240206092026560.png)

# 三、火狐浏览器（Firefox）下载Vue开发者

1\. 点击火狐右上角图标，找到**扩展和主题**并打开：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127154244197.png)

2\. 在上方搜索框中输入`Vue.js devtools`，然后点击回车：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127154546914.png)

3\. 点击第一个搜索结果：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127154636382.png)

4\. 点击**添加到Firefox**

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127154711306.png)

5\. 此时右上角会弹出一个提示，此时点击**添加**即可：

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127154756802.png)

6\. 此时点击**好的**即可，Vue开发者工具插件就添加成功了。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127154840283.png)

7\. 此时我们再次打开扩展页面，发现Vue开发者工具插件已经打开了。

![](https://icode504.oss-cn-beijing.aliyuncs.com/image-20231127154957294.png)